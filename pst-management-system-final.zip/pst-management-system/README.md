# PST Department Management System — Full Stack

React.js Frontend + Node.js/Express Backend + MySQL Database (as in the architecture diagram).

```
pst-management-system/
├── frontend/     React app (existing UI — currently still uses mock data, see note below)
├── backend/      Express REST API
└── database/     MySQL schema + seed data
```

## Stage 1 (done): Database + Backend API
This stage delivers a real, working backend that replaces the app's mock data:
- MySQL schema covering all 3 portals — students, lecturers, courses, semester
  registration, exam applications (normal/medical/repeat), attendance, results,
  payments (card + bank slip), notices, wellbeing check-ins, counseling sessions.
- Express REST API with JWT auth, role-based access (student/lecturer/admin),
  and file uploads for medical documents & bank slips.
- Tested end-to-end (login for all 3 roles, semester registration + payment
  auto-confirm, notices, wellbeing check-ins, lecturer course assignment).

## Stage 2 (not done yet): Wiring the frontend to the API
`frontend/src/App.jsx` is one large file (~3,300 lines) where every screen
currently keeps its data in local React state / hardcoded arrays — there are
no `fetch` calls at all yet. Connecting it to this backend (real login,
replacing hardcoded arrays with `fetch("/api/...")` calls, handling loading/
error states) is a separate, sizeable pass through that file. Say the word
and I'll start on it — happy to do it screen by screen (e.g. start with
Login + Student Dashboard) so you can test as we go.

---

## Setup

### 1. Database
```bash
mysql -u root -p < database/schema.sql
mysql -u root -p pst_management < database/seed_courses.sql
```
This creates the `pst_management` database with all tables and seeds the 164
official PST courses (Years 1–4, all specializations) from the Faculty of
Applied Sciences' PST Curriculum page, each tagged with which
combination(s) — C1 (Physics/Applied Physics), C2 (Chemical Technology), C3
(Computer Science & Technology) — it belongs to. Year 1 & 2 courses are
common to everyone. `seed_courses.sql` is safe to re-run any time the
curriculum changes; it updates existing rows instead of erroring on
duplicates.

**Already have the database set up from an older version?** Run the
migration first to add the new `combination` column, then re-seed:
```bash
mysql -u root -p pst_management < database/migrations/001_add_course_combination.sql
mysql -u root -p pst_management < database/seed_courses.sql
```

### 2. Backend
```bash
cd backend
cp .env.example .env      # then edit DB_PASSWORD and JWT_SECRET
npm install
node database/seed-demo-users.js   # creates one demo login per portal
npm start                          # runs on http://localhost:5000
```

Demo logins created by the seed script:
| Portal   | Username    | Password     |
|----------|-------------|--------------|
| Student  | 21APP5710   | student123   |
| Lecturer | L001        | lecturer123  |
| Admin    | admin       | admin123     |

Health check: `GET http://localhost:5000/api/health`

### 3. Frontend (unchanged for now)
```bash
cd frontend
npm install
npm start        # http://localhost:3000
```

## API Overview
All routes are under `/api`. Protected routes need `Authorization: Bearer <token>`
(returned from `POST /api/auth/login`).

| Area | Routes |
|---|---|
| Auth | `POST /auth/register/student`, `POST /auth/login`, `GET /auth/me` |
| Courses | `GET /courses`, `POST/PUT/DELETE /courses` (admin) |
| Attendance | `GET /attendance/me` (student), `GET/POST /attendance/mark` (lecturer), `GET /attendance/reports` (admin) |
| Results | `GET /results/me`, `GET /results/course/:id`, `POST /results/enter`, `GET /results/overview` |
| Semester Registration | `POST/GET /semreg`, `GET /semreg/me`, `PUT /semreg/:id/status` |
| Exam Applications | `POST/GET /exams`, `GET /exams/me`, `PUT /exams/:id/status` |
| Payments | `POST /payments` (card or `multipart/form-data` with `slip` file for bank transfer), `GET /payments/me`, `GET /payments`, `PUT /payments/:id/verify` |
| Notices | `GET/POST/DELETE /notices` |
| Wellbeing | `POST /wellbeing`, `GET /wellbeing/me`, `GET /wellbeing/reports`, `GET/PUT /wellbeing/counseling` |
| Admin | `GET /admin/students`, `GET /admin/students/pending`, `PUT /admin/students/:id/activate`, `POST /admin/lecturers`, `GET /admin/dashboard`, `POST /admin/lecturer-courses`, `GET /admin/lecturer/classes` |

Fees are pulled from `system_settings` / hardcoded to match the original app:
semester registration LKR 300/subject, medical exam LKR 1,500/subject, repeat
exam LKR 25/subject.

## Note on the source data
`database/seed_courses.sql` now contains the official PST course list (Year 1
to Year 4, all four specialization tracks — General Physical Sciences,
Applied Physics, Chemical Technology, and Computer Science & Technology),
transcribed from the Faculty of Applied Sciences' PST Curriculum page
(https://www.sab.ac.lk/app/index.php/pst-curriculum). One small note: the
source lists "Special Relativity" under two different codes (PST 31205 in
the General track, PST 31105 in the Applied Physics track) with the same
credit value — almost certainly a transcription slip upstream, so it's
seeded once as PST 31205. Worth double-checking with your department if this
matters for official records.

The `courses` table has no "specialization" column, so Year 3/4 courses from
all four tracks are seeded together; a given student will only register for
the subset matching their own combination.
