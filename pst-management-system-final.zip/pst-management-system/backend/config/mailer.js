const nodemailer = require("nodemailer");
require("dotenv").config();

// Lazily-created singleton transporter. If SMTP_HOST isn't set (e.g. during
// local development with no mail account handy), we fall back to an
// auto-generated Ethereal test inbox — emails aren't really delivered, but
// nodemailer gives back a preview URL that's logged to the console so you
// can still see exactly what would have been sent.
let transporterPromise = null;
let usingEthereal = false;

function getTransporter() {
  if (transporterPromise) return transporterPromise;

  if (process.env.SMTP_HOST) {
    transporterPromise = Promise.resolve(
      nodemailer.createTransport({
        host: process.env.SMTP_HOST,
        port: parseInt(process.env.SMTP_PORT || "587", 10),
        secure: process.env.SMTP_SECURE === "true",
        auth: process.env.SMTP_USER
          ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS }
          : undefined,
      })
    );
  } else {
    usingEthereal = true;
    transporterPromise = nodemailer.createTestAccount().then((testAccount) =>
      nodemailer.createTransport({
        host: "smtp.ethereal.email",
        port: 587,
        secure: false,
        auth: { user: testAccount.user, pass: testAccount.pass },
      })
    );
    console.log(
      "[mailer] No SMTP_HOST configured — using a temporary Ethereal test inbox. " +
      "Emails won't really be delivered; a preview link will be logged instead. " +
      "Set SMTP_HOST/SMTP_USER/SMTP_PASS in .env to send real emails."
    );
  }
  return transporterPromise;
}

async function sendMail({ to, subject, html, text }) {
  const transporter = await getTransporter();
  const info = await transporter.sendMail({
    from: process.env.SMTP_FROM || '"PST Department" <no-reply@pst.susl.ac.lk>',
    to,
    subject,
    text,
    html,
  });
  if (usingEthereal) {
    const previewUrl = nodemailer.getTestMessageUrl(info);
    if (previewUrl) console.log(`[mailer] Preview email at: ${previewUrl}`);
  }
  return info;
}

module.exports = { sendMail };
