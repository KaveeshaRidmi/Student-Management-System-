const bcrypt = require("bcryptjs");
const pool = require("../config/db");

// GET /api/admin/students -> All Students
async function listStudents(req, res) {
  try {
    const [rows] = await pool.query(
      `SELECT s.*, u.username, u.full_name, u.email, u.phone, u.status
       FROM students s JOIN users u ON s.user_id = u.id
       ORDER BY s.index_number`
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to load students", error: err.message });
  }
}

// GET /api/admin/students/pending -> New Registrations awaiting activation
async function pendingRegistrations(req, res) {
  try {
    const [rows] = await pool.query(
      `SELECT s.*, u.username, u.full_name, u.email, u.phone, u.status
       FROM students s JOIN users u ON s.user_id = u.id
       WHERE u.status = 'pending' ORDER BY s.id DESC`
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to load pending registrations", error: err.message });
  }
}

// PUT /api/admin/students/:userId/activate  (approve a new registration)
async function activateStudent(req, res) {
  try {
    await pool.query("UPDATE users SET status='active' WHERE id=?", [req.params.userId]);
    res.json({ message: "Student activated" });
  } catch (err) {
    res.status(500).json({ message: "Failed to activate student", error: err.message });
  }
}

// PUT /api/admin/students/:userId/suspend
async function suspendStudent(req, res) {
  try {
    await pool.query("UPDATE users SET status='suspended' WHERE id=?", [req.params.userId]);
    res.json({ message: "Student suspended" });
  } catch (err) {
    res.status(500).json({ message: "Failed to suspend student", error: err.message });
  }
}

// POST /api/admin/lecturers  -> Admin creates a lecturer account directly (System Settings)
async function createLecturer(req, res) {
  const { username, password, full_name, email, phone, staff_id, designation, department } = req.body;
  if (!username || !password || !full_name) {
    return res.status(400).json({ message: "username, password and full_name are required" });
  }
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    const hash = await bcrypt.hash(password, 10);
    const [userResult] = await conn.query(
      "INSERT INTO users (username, password_hash, role, full_name, email, phone, status) VALUES (?, ?, 'lecturer', ?, ?, ?, 'active')",
      [username, hash, full_name, email || null, phone || null]
    );
    await conn.query(
      "INSERT INTO lecturers (user_id, staff_id, designation, department) VALUES (?, ?, ?, ?)",
      [userResult.insertId, staff_id || null, designation || "Lecturer", department || "PST Dept."]
    );
    await conn.commit();
    res.status(201).json({ message: "Lecturer account created" });
  } catch (err) {
    await conn.rollback();
    res.status(500).json({ message: "Failed to create lecturer", error: err.message });
  } finally {
    conn.release();
  }
}

// GET /api/admin/dashboard -> aggregate stats for the admin dashboard cards
async function dashboardStats(req, res) {
  try {
    const [[{ totalStudents }]] = await pool.query(
      "SELECT COUNT(*) AS totalStudents FROM students s JOIN users u ON s.user_id=u.id WHERE u.status='active'"
    );
    const [[{ pendingRegs }]] = await pool.query(
      "SELECT COUNT(*) AS pendingRegs FROM users WHERE role='student' AND status='pending'"
    );
    const [[{ pendingPayments }]] = await pool.query(
      "SELECT COUNT(*) AS pendingPayments FROM payments WHERE status='pending'"
    );
    const [[{ openCounseling }]] = await pool.query(
      "SELECT COUNT(*) AS openCounseling FROM counseling_sessions WHERE status IN ('requested','scheduled')"
    );
    const [[{ totalLecturers }]] = await pool.query(
      "SELECT COUNT(*) AS totalLecturers FROM lecturers l JOIN users u ON l.user_id=u.id WHERE u.status='active'"
    );
    const [[{ totalCourses }]] = await pool.query("SELECT COUNT(*) AS totalCourses FROM courses");
    const [[{ totalBatches }]] = await pool.query(
      "SELECT COUNT(DISTINCT batch) AS totalBatches FROM students WHERE batch IS NOT NULL AND batch <> ''"
    );
    const [[{ activeSemesters }]] = await pool.query(
      "SELECT COUNT(DISTINCT CONCAT(year, '-', semester)) AS activeSemesters FROM semester_registrations WHERE status <> 'rejected'"
    );

    // Attendance statistics — overall present rate across every recorded session.
    const [[attendanceRow]] = await pool.query(
      `SELECT COUNT(*) AS total, SUM(status = 'present') AS present FROM attendance`
    );
    const attendancePct = attendanceRow.total ? Math.round((attendanceRow.present / attendanceRow.total) * 100) : 0;

    // Result statistics — overall pass rate across every graded result.
    const [[resultRow]] = await pool.query(
      `SELECT COUNT(*) AS total, SUM(grade IS NOT NULL AND grade <> 'F') AS passed FROM results WHERE grade IS NOT NULL`
    );
    const passRate = resultRow.total ? Math.round((resultRow.passed / resultRow.total) * 100) : 0;

    // Recent activity — a genuine feed built from the latest rows across
    // several timestamped tables (no separate audit-log table exists).
    const [regActivity] = await pool.query(
      `SELECT 'registration' AS type, sr.created_at AS at, u.full_name AS who, CONCAT('registered for Year ', sr.year, ' Semester ', sr.semester) AS detail
       FROM semester_registrations sr JOIN students s ON sr.student_id=s.id JOIN users u ON s.user_id=u.id
       ORDER BY sr.created_at DESC LIMIT 5`
    );
    const [paymentActivity] = await pool.query(
      `SELECT 'payment' AS type, p.created_at AS at, u.full_name AS who, CONCAT('made a payment of LKR ', p.amount, ' (', p.purpose, ')') AS detail
       FROM payments p JOIN students s ON p.student_id=s.id JOIN users u ON s.user_id=u.id
       ORDER BY p.created_at DESC LIMIT 5`
    );
    const [noticeActivity] = await pool.query(
      `SELECT 'notice' AS type, n.created_at AS at, u.full_name AS who, CONCAT('posted a notice: ', n.title) AS detail
       FROM notices n JOIN users u ON n.posted_by=u.id
       ORDER BY n.created_at DESC LIMIT 5`
    );
    const [examActivity] = await pool.query(
      `SELECT 'exam' AS type, e.created_at AS at, u.full_name AS who, 'submitted an exam application' AS detail
       FROM exam_applications e JOIN students s ON e.student_id=s.id JOIN users u ON s.user_id=u.id
       ORDER BY e.created_at DESC LIMIT 5`
    );
    const recentActivity = [...regActivity, ...paymentActivity, ...noticeActivity, ...examActivity]
      .sort((a, b) => new Date(b.at) - new Date(a.at))
      .slice(0, 10);

    res.json({
      totalStudents, pendingRegs, pendingPayments, openCounseling,
      totalLecturers, totalCourses, totalBatches, activeSemesters,
      attendancePct, passRate,
      recentActivity,
    });
  } catch (err) {
    res.status(500).json({ message: "Failed to load dashboard stats", error: err.message });
  }
}

// ─── LECTURER "My Classes" ──────────────────────────────────────────────────
// GET /api/lecturer/classes
async function myClasses(req, res) {
  try {
    const [lect] = await pool.query("SELECT id FROM lecturers WHERE user_id = ?", [req.user.id]);
    if (!lect.length) return res.status(404).json({ message: "Lecturer profile not found" });

    const [rows] = await pool.query(
      `SELECT lc.id, lc.academic_year, c.id AS course_id, c.code, c.name, c.year, c.semester, c.credits
       FROM lecturer_courses lc JOIN courses c ON lc.course_id = c.id
       WHERE lc.lecturer_id = ? ORDER BY c.year, c.semester, c.code`,
      [lect[0].id]
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to load classes", error: err.message });
  }
}

// POST /api/admin/lecturer-courses (admin assigns a lecturer to a course)
async function assignLecturerCourse(req, res) {
  const { lecturerId, courseId, academicYear } = req.body;
  if (!lecturerId || !courseId || !academicYear) {
    return res.status(400).json({ message: "lecturerId, courseId and academicYear are required" });
  }
  try {
    await pool.query(
      "INSERT IGNORE INTO lecturer_courses (lecturer_id, course_id, academic_year) VALUES (?, ?, ?)",
      [lecturerId, courseId, academicYear]
    );
    res.status(201).json({ message: "Lecturer assigned to course" });
  } catch (err) {
    res.status(500).json({ message: "Failed to assign course", error: err.message });
  }
}

module.exports = {
  listStudents,
  pendingRegistrations,
  activateStudent,
  suspendStudent,
  createLecturer,
  dashboardStats,
  myClasses,
  assignLecturerCourse,
};
