const pool = require("../config/db");

// GET /api/assignments/me (student) — assignments for courses the student is
// currently registered in, with their own submission status.
async function myAssignments(req, res) {
  try {
    const [student] = await pool.query("SELECT id FROM students WHERE user_id = ?", [req.user.id]);
    if (!student.length) return res.status(404).json({ message: "Student profile not found" });

    const [rows] = await pool.query(
      `SELECT DISTINCT a.id, a.title, a.description, a.deadline, c.code, c.name AS course_name,
              sub.id AS submission_id, sub.submitted_at
       FROM assignments a
       JOIN courses c ON a.course_id = c.id
       JOIN semester_registration_courses src ON src.course_id = c.id
       JOIN semester_registrations sr ON src.registration_id = sr.id AND sr.student_id = ?
       LEFT JOIN assignment_submissions sub ON sub.assignment_id = a.id AND sub.student_id = ?
       ORDER BY a.deadline ASC`,
      [student[0].id, student[0].id]
    );

    const withStatus = rows.map((r) => {
      let status;
      if (r.submission_id) {
        status = new Date(r.submitted_at) > new Date(r.deadline) ? "submitted_late" : "submitted";
      } else {
        // No separate "overdue" state — an unsubmitted assignment always shows
        // as "pending" (with the deadline visible) so students can still submit.
        status = "pending";
      }
      return { ...r, status };
    });

    res.json(withStatus);
  } catch (err) {
    res.status(500).json({ message: "Failed to load assignments", error: err.message });
  }
}

// POST /api/assignments (lecturer) body: { courseId, title, description, deadline }
async function createAssignment(req, res) {
  const { courseId, title, description, deadline } = req.body;
  if (!courseId || !title || !deadline) {
    return res.status(400).json({ message: "courseId, title and deadline are required" });
  }
  try {
    const [lecturer] = await pool.query("SELECT id FROM lecturers WHERE user_id = ?", [req.user.id]);
    if (!lecturer.length) return res.status(404).json({ message: "Lecturer profile not found" });

    const [owns] = await pool.query(
      "SELECT 1 FROM lecturer_courses WHERE lecturer_id = ? AND course_id = ?",
      [lecturer[0].id, courseId]
    );
    if (!owns.length) return res.status(403).json({ message: "You are not assigned to this course" });

    const [result] = await pool.query(
      "INSERT INTO assignments (course_id, title, description, deadline, created_by) VALUES (?, ?, ?, ?, ?)",
      [courseId, title, description || null, deadline, lecturer[0].id]
    );
    res.status(201).json({ id: result.insertId, message: "Assignment posted" });
  } catch (err) {
    res.status(500).json({ message: "Failed to create assignment", error: err.message });
  }
}

// GET /api/assignments/course/:courseId (lecturer/admin) — assignments for a
// course with a submission count.
async function courseAssignments(req, res) {
  const { courseId } = req.params;
  try {
    const [rows] = await pool.query(
      `SELECT a.id, a.title, a.description, a.deadline, a.created_at,
              (SELECT COUNT(*) FROM assignment_submissions s WHERE s.assignment_id = a.id) AS submission_count
       FROM assignments a WHERE a.course_id = ? ORDER BY a.deadline DESC`,
      [courseId]
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to load assignments", error: err.message });
  }
}

// POST /api/assignments/:id/submit (student) — multipart form with `file`
async function submitAssignment(req, res) {
  const { id } = req.params;
  try {
    const [student] = await pool.query("SELECT id FROM students WHERE user_id = ?", [req.user.id]);
    if (!student.length) return res.status(404).json({ message: "Student profile not found" });

    const filePath = req.file ? `/uploads/assignment_submissions/${req.file.filename}` : null;

    await pool.query(
      `INSERT INTO assignment_submissions (assignment_id, student_id, file_path, submitted_at)
       VALUES (?, ?, ?, NOW())
       ON DUPLICATE KEY UPDATE file_path = VALUES(file_path), submitted_at = NOW()`,
      [id, student[0].id, filePath]
    );
    res.json({ message: "Assignment submitted" });
  } catch (err) {
    res.status(500).json({ message: "Failed to submit assignment", error: err.message });
  }
}

module.exports = { myAssignments, createAssignment, courseAssignments, submitAssignment };
