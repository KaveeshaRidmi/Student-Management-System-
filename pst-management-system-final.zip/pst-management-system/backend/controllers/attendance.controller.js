const pool = require("../config/db");

// GET /api/attendance/me  (student) -> their own attendance, grouped stats included
async function myAttendance(req, res) {
  try {
    const [student] = await pool.query("SELECT id FROM students WHERE user_id = ?", [req.user.id]);
    if (!student.length) return res.status(404).json({ message: "Student profile not found" });

    const [rows] = await pool.query(
      `SELECT a.id, a.session_date, a.status, c.code, c.name AS course_name
       FROM attendance a JOIN courses c ON a.course_id = c.id
       WHERE a.student_id = ? ORDER BY a.session_date DESC`,
      [student[0].id]
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to load attendance", error: err.message });
  }
}

// GET /api/attendance/course/:courseId  (lecturer/admin) -> roster for marking
async function courseAttendance(req, res) {
  const { courseId } = req.params;
  const { date } = req.query;
  try {
    const [rows] = await pool.query(
      `SELECT s.id AS student_id, s.index_number, u.full_name,
              a.status, a.session_date
       FROM students s
       JOIN users u ON s.user_id = u.id
       LEFT JOIN attendance a ON a.student_id = s.id AND a.course_id = ? AND a.session_date = ?
       ORDER BY s.index_number`,
      [courseId, date || new Date().toISOString().slice(0, 10)]
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to load class roster", error: err.message });
  }
}

// POST /api/attendance/mark  (lecturer) body: { courseId, date, records: [{student_id, status}] }
async function markAttendance(req, res) {
  const { courseId, date, records } = req.body;
  if (!courseId || !date || !Array.isArray(records)) {
    return res.status(400).json({ message: "courseId, date and records[] are required" });
  }

  try {
    const [lect] = await pool.query("SELECT id FROM lecturers WHERE user_id = ?", [req.user.id]);
    const lecturerId = lect.length ? lect[0].id : null;

    const conn = await pool.getConnection();
    try {
      await conn.beginTransaction();
      for (const r of records) {
        await conn.query(
          `INSERT INTO attendance (student_id, course_id, session_date, status, marked_by)
           VALUES (?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE status = VALUES(status), marked_by = VALUES(marked_by)`,
          [r.student_id, courseId, date, r.status, lecturerId]
        );
      }
      await conn.commit();
      res.json({ message: "Attendance saved" });
    } catch (err) {
      await conn.rollback();
      throw err;
    } finally {
      conn.release();
    }
  } catch (err) {
    res.status(500).json({ message: "Failed to save attendance", error: err.message });
  }
}

// GET /api/attendance/reports (admin) -> summary per student/course
async function attendanceReports(req, res) {
  try {
    const [rows] = await pool.query(
      `SELECT s.index_number, u.full_name, c.code, c.name AS course_name,
              COUNT(*) AS total_sessions,
              SUM(a.status = 'present') AS present_count,
              ROUND(SUM(a.status='present') / COUNT(*) * 100, 1) AS attendance_pct
       FROM attendance a
       JOIN students s ON a.student_id = s.id
       JOIN users u ON s.user_id = u.id
       JOIN courses c ON a.course_id = c.id
       GROUP BY s.id, c.id
       ORDER BY u.full_name`
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to load attendance reports", error: err.message });
  }
}

module.exports = { myAttendance, courseAttendance, markAttendance, attendanceReports };
