const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const pool = require("../config/db");
const { sendMail } = require("../config/mailer");
require("dotenv").config();

// In-memory OTP store, keyed by email. Good enough for a single backend
// process during registration; codes expire after 5 minutes.
// { [email]: { code, expiresAt, attempts, verified } }
const otpStore = new Map();
const OTP_TTL_MS = 5 * 60 * 1000;
const MAX_ATTEMPTS = 5;

// POST /api/auth/send-otp  { email }
async function sendOtp(req, res) {
  const { email } = req.body;
  if (!email || !email.includes("@")) {
    return res.status(400).json({ message: "A valid email address is required" });
  }

  const code = Math.floor(100000 + Math.random() * 900000).toString();
  otpStore.set(email, { code, expiresAt: Date.now() + OTP_TTL_MS, attempts: 0, verified: false });

  try {
    await sendMail({
      to: email,
      subject: "Your PST Department verification code",
      text: `Your verification code is ${code}. It expires in 5 minutes.`,
      html: `
        <div style="font-family: sans-serif; max-width: 420px; margin: auto;">
          <h2 style="color:#122A44;">PST Department — Verify your email</h2>
          <p>Use the code below to continue your registration. It expires in 5 minutes.</p>
          <div style="font-size: 32px; font-weight: 800; letter-spacing: 0.3em; color: #122A44; background:#F7F5F1; padding: 16px 20px; border-radius: 10px; text-align:center;">${code}</div>
          <p style="color:#8B8C93; font-size: 12px; margin-top: 20px;">If you didn't request this, you can safely ignore this email.</p>
        </div>`,
    });
    res.json({ message: `A verification code was sent to ${email}.` });
  } catch (err) {
    otpStore.delete(email);
    console.error("Failed to send OTP email:", err);
    res.status(500).json({ message: "Couldn't send the verification email. Please try again." });
  }
}

// POST /api/auth/verify-otp  { email, otp }
async function verifyOtp(req, res) {
  const { email, otp } = req.body;
  if (!email || !otp) return res.status(400).json({ message: "email and otp are required" });

  const entry = otpStore.get(email);
  if (!entry) return res.status(400).json({ message: "No verification code was sent to this email. Please request a new one." });
  if (Date.now() > entry.expiresAt) {
    otpStore.delete(email);
    return res.status(400).json({ message: "This code has expired. Please request a new one." });
  }
  if (entry.attempts >= MAX_ATTEMPTS) {
    otpStore.delete(email);
    return res.status(429).json({ message: "Too many incorrect attempts. Please request a new code." });
  }

  if (otp !== entry.code) {
    entry.attempts += 1;
    return res.status(400).json({ message: "Incorrect code. Please try again." });
  }

  entry.verified = true;
  res.json({ message: "Email verified." });
}

function signToken(user) {
  return jwt.sign(
    { id: user.id, role: user.role, username: user.username, full_name: user.full_name },
    process.env.JWT_SECRET,
    { expiresIn: process.env.JWT_EXPIRES_IN || "7d" }
  );
}

// POST /api/auth/register/student
// Creates a users row + students row in one transaction.
async function registerStudent(req, res) {
  const {
    username, // index number e.g. 21APP5710
    password,
    full_name,
    email,
    phone,
    intake_year,
    program,
    batch,
    date_of_birth,
    gender,
    nic,
    address,
    profile_picture,
    guardian_name,
    guardian_phone,
  } = req.body;

  if (!username || !password || !full_name) {
    return res.status(400).json({ message: "username, password and full_name are required" });
  }

  // TEMP: OTP verification requirement disabled — remove this comment block
  // and uncomment the check below once the OTP step is re-enabled on the frontend.
  // if (email) {
  //   const otpEntry = otpStore.get(email);
  //   if (!otpEntry || !otpEntry.verified) {
  //     return res.status(403).json({ message: "Please verify your email with the code sent to it before completing registration." });
  //   }
  // }

  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();

    const [existing] = await conn.query("SELECT id FROM users WHERE username = ?", [username]);
    if (existing.length) {
      await conn.rollback();
      return res.status(409).json({ message: "Username / index number already registered" });
    }

    const hash = await bcrypt.hash(password, 10);
    const [userResult] = await conn.query(
      "INSERT INTO users (username, password_hash, role, full_name, email, phone, status) VALUES (?, ?, 'student', ?, ?, ?, 'pending')",
      [username, hash, full_name, email || null, phone || null]
    );

    const currentYear = 1; // new registrations start at year 1 by default
    await conn.query(
      `INSERT INTO students (user_id, index_number, intake_year, current_year, current_semester, program, batch, date_of_birth, gender, nic, address, profile_picture, guardian_name, guardian_phone)
       VALUES (?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        userResult.insertId,
        username,
        intake_year || new Date().getFullYear() % 100,
        currentYear,
        program || "B.Sc. Physical Sciences",
        batch || null,
        date_of_birth || null,
        gender || null,
        nic || null,
        address || null,
        profile_picture || null,
        guardian_name || null,
        guardian_phone || null,
      ]
    );

    await conn.commit();
    if (email) otpStore.delete(email);
    res.status(201).json({ message: "Registration submitted. Awaiting activation." });
  } catch (err) {
    await conn.rollback();
    console.error(err);
    res.status(500).json({ message: "Registration failed", error: err.message });
  } finally {
    conn.release();
  }
}

// POST /api/auth/login  { username, password, role }
async function login(req, res) {
  const { username, password, role } = req.body;
  if (!username || !password || !role) {
    return res.status(400).json({ message: "username, password and role are required" });
  }

  try {
    const [rows] = await pool.query("SELECT * FROM users WHERE username = ? AND role = ?", [username, role]);
    if (!rows.length) {
      return res.status(401).json({ message: "Invalid credentials" });
    }
    const user = rows[0];

    if (user.status !== "active") {
      return res.status(403).json({ message: `Account is ${user.status}. Contact admin.` });
    }

    // TEMP: exact password check disabled — remove this comment block and
    // uncomment the check below to require the correct password again.
    // const match = await bcrypt.compare(password, user.password_hash);
    // if (!match) {
    //   return res.status(401).json({ message: "Invalid credentials" });
    // }

    const token = signToken(user);
    delete user.password_hash;
    res.json({ token, user });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: "Login failed", error: err.message });
  }
}

// GET /api/auth/me
async function me(req, res) {
  try {
    const [rows] = await pool.query(
      "SELECT id, username, role, full_name, email, phone, status FROM users WHERE id = ?",
      [req.user.id]
    );
    if (!rows.length) return res.status(404).json({ message: "User not found" });
    const user = rows[0];

    if (user.role === "student") {
      const [student] = await pool.query(
        `SELECT index_number, intake_year, current_year, current_semester, program, batch,
                date_of_birth, gender, address, profile_picture
         FROM students WHERE user_id = ?`,
        [req.user.id]
      );
      if (student.length) Object.assign(user, student[0]);
    } else if (user.role === "lecturer") {
      const [lecturer] = await pool.query(
        "SELECT staff_id, designation, department FROM lecturers WHERE user_id = ?",
        [req.user.id]
      );
      if (lecturer.length) Object.assign(user, lecturer[0]);
    }

    res.json(user);
  } catch (err) {
    res.status(500).json({ message: "Failed to fetch profile", error: err.message });
  }
}

module.exports = { registerStudent, login, me, sendOtp, verifyOtp };
