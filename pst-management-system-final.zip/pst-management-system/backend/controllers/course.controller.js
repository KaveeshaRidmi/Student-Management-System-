const pool = require("../config/db");

// GET /api/courses  (optional ?year=1&semester=1&combination=C3)
// `combination` filters to courses that are either compulsory or elective
// for that combination, PLUS any common/foundation courses
// (compulsory_for = 'ALL') — e.g. Year 1/2 subjects. Each returned row also
// gets an `is_elective` flag (true/false) telling the frontend whether the
// student must take it or gets to choose, based on the requested combination.
async function listCourses(req, res) {
  const { year, semester, combination } = req.query;
  let sql = "SELECT * FROM courses WHERE 1=1";
  const params = [];
  if (year) {
    sql += " AND year = ?";
    params.push(year);
  }
  if (semester) {
    sql += " AND semester = ?";
    params.push(semester);
  }
  if (combination) {
    sql += " AND (compulsory_for = 'ALL' OR FIND_IN_SET(?, compulsory_for) OR FIND_IN_SET(?, elective_for))";
    params.push(combination, combination);
  }
  sql += " ORDER BY year, semester, code";

  try {
    const [rows] = await pool.query(sql, params);
    const withElectiveFlag = rows.map((r) => ({
      ...r,
      is_elective: combination
        ? r.compulsory_for !== "ALL" && !(r.compulsory_for || "").split(",").includes(combination) && (r.elective_for || "").split(",").includes(combination)
        : false,
    }));
    res.json(withElectiveFlag);
  } catch (err) {
    res.status(500).json({ message: "Failed to load courses", error: err.message });
  }
}

// POST /api/courses  (admin only)
async function createCourse(req, res) {
  const { code, name, credits, year, semester } = req.body;
  if (!code || !name || !credits || !year || !semester) {
    return res.status(400).json({ message: "code, name, credits, year, semester are required" });
  }
  try {
    const [result] = await pool.query(
      "INSERT INTO courses (code, name, credits, year, semester) VALUES (?, ?, ?, ?, ?)",
      [code, name, credits, year, semester]
    );
    res.status(201).json({ id: result.insertId });
  } catch (err) {
    res.status(500).json({ message: "Failed to create course", error: err.message });
  }
}

// PUT /api/courses/:id (admin only)
async function updateCourse(req, res) {
  const { code, name, credits, year, semester } = req.body;
  try {
    await pool.query(
      "UPDATE courses SET code=?, name=?, credits=?, year=?, semester=? WHERE id=?",
      [code, name, credits, year, semester, req.params.id]
    );
    res.json({ message: "Course updated" });
  } catch (err) {
    res.status(500).json({ message: "Failed to update course", error: err.message });
  }
}

// DELETE /api/courses/:id (admin only)
async function deleteCourse(req, res) {
  try {
    await pool.query("DELETE FROM courses WHERE id=?", [req.params.id]);
    res.json({ message: "Course deleted" });
  } catch (err) {
    res.status(500).json({ message: "Failed to delete course", error: err.message });
  }
}

module.exports = { listCourses, createCourse, updateCourse, deleteCourse };
