const pool = require("../config/db");

const FEES = { normal: 0, medical: 25, repeat: 25 };

// POST /api/exams  (student, multipart if medical: field "medicalDoc")
// body: { examType, year, semester, courseIds: [] }
async function createApplication(req, res) {
  const { examType, year, semester } = req.body;
  let courseIds = req.body.courseIds;
  if (typeof courseIds === "string") {
    try { courseIds = JSON.parse(courseIds); } catch { courseIds = [courseIds]; }
  }

  if (!examType || !FEES.hasOwnProperty(examType) || !year || !semester || !Array.isArray(courseIds) || !courseIds.length) {
    return res.status(400).json({ message: "examType, year, semester and courseIds[] are required" });
  }
  if (examType === "medical" && !req.file) {
    return res.status(400).json({ message: "Medical exams require a supporting document upload" });
  }

  try {
    const [student] = await pool.query("SELECT id FROM students WHERE user_id = ?", [req.user.id]);
    if (!student.length) return res.status(404).json({ message: "Student profile not found" });

    const totalFee = FEES[examType] * courseIds.length;
    const status = totalFee > 0 ? "payment_pending" : "submitted";
    const medicalDocPath = req.file ? `/uploads/medical_docs/${req.file.filename}` : null;

    const conn = await pool.getConnection();
    try {
      await conn.beginTransaction();
      const [result] = await conn.query(
        `INSERT INTO exam_applications (student_id, exam_type, year, semester, medical_doc_path, status, total_fee)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [student[0].id, examType, year, semester, medicalDocPath, status, totalFee]
      );
      for (const courseId of courseIds) {
        await conn.query(
          "INSERT INTO exam_application_subjects (application_id, course_id) VALUES (?, ?)",
          [result.insertId, courseId]
        );
      }
      await conn.commit();
      res.status(201).json({ id: result.insertId, total_fee: totalFee, status });
    } catch (err) {
      await conn.rollback();
      throw err;
    } finally {
      conn.release();
    }
  } catch (err) {
    res.status(500).json({ message: "Failed to submit exam application", error: err.message });
  }
}

// GET /api/exams/me (student)
async function myApplications(req, res) {
  try {
    const [student] = await pool.query("SELECT id FROM students WHERE user_id = ?", [req.user.id]);
    if (!student.length) return res.status(404).json({ message: "Student profile not found" });

    const [apps] = await pool.query(
      "SELECT * FROM exam_applications WHERE student_id = ? ORDER BY created_at DESC",
      [student[0].id]
    );
    for (const app of apps) {
      const [subjects] = await pool.query(
        `SELECT c.code, c.name FROM exam_application_subjects eas
         JOIN courses c ON eas.course_id = c.id WHERE eas.application_id = ?`,
        [app.id]
      );
      app.subjects = subjects;
    }
    res.json(apps);
  } catch (err) {
    res.status(500).json({ message: "Failed to load applications", error: err.message });
  }
}

// GET /api/exams (lecturer/admin)
async function allApplications(req, res) {
  try {
    const [rows] = await pool.query(
      `SELECT ea.*, s.index_number, u.full_name
       FROM exam_applications ea
       JOIN students s ON ea.student_id = s.id
       JOIN users u ON s.user_id = u.id
       ORDER BY ea.created_at DESC`
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to load applications", error: err.message });
  }
}

// PUT /api/exams/:id/status (admin/lecturer) body: { status }
async function updateStatus(req, res) {
  const { status } = req.body;
  if (!["submitted", "approved", "rejected", "payment_pending"].includes(status)) {
    return res.status(400).json({ message: "Invalid status" });
  }
  try {
    await pool.query("UPDATE exam_applications SET status=? WHERE id=?", [status, req.params.id]);
    res.json({ message: "Status updated" });
  } catch (err) {
    res.status(500).json({ message: "Failed to update status", error: err.message });
  }
}

module.exports = { createApplication, myApplications, allApplications, updateStatus };
