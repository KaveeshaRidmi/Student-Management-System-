const pool = require("../config/db");

// GET /api/exam-timetable/me (student) — timetable entries for courses the
// student is currently registered in.
async function myTimetable(req, res) {
  try {
    const [student] = await pool.query("SELECT id FROM students WHERE user_id = ?", [req.user.id]);
    if (!student.length) return res.status(404).json({ message: "Student profile not found" });

    const [rows] = await pool.query(
      `SELECT DISTINCT et.id, et.exam_date, et.start_time, et.end_time, et.venue, et.year, et.semester,
              c.code, c.name AS course_name
       FROM exam_timetable et
       JOIN courses c ON et.course_id = c.id
       JOIN semester_registration_courses src ON src.course_id = c.id
       JOIN semester_registrations sr ON src.registration_id = sr.id AND sr.student_id = ?
       ORDER BY et.exam_date ASC, et.start_time ASC`,
      [student[0].id]
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to load exam timetable", error: err.message });
  }
}

// GET /api/exam-timetable (admin/lecturer) — optional ?year=&semester= filter
async function allTimetable(req, res) {
  const { year, semester } = req.query;
  let sql = `SELECT et.*, c.code, c.name AS course_name FROM exam_timetable et JOIN courses c ON et.course_id = c.id WHERE 1=1`;
  const params = [];
  if (year) { sql += " AND et.year = ?"; params.push(year); }
  if (semester) { sql += " AND et.semester = ?"; params.push(semester); }
  sql += " ORDER BY et.exam_date ASC, et.start_time ASC";
  try {
    const [rows] = await pool.query(sql, params);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to load exam timetable", error: err.message });
  }
}

// POST /api/exam-timetable (admin) body: { courseId, year, semester, examDate, startTime, endTime, venue }
async function createEntry(req, res) {
  const { courseId, year, semester, examDate, startTime, endTime, venue } = req.body;
  if (!courseId || !year || !semester || !examDate || !startTime) {
    return res.status(400).json({ message: "courseId, year, semester, examDate and startTime are required" });
  }
  try {
    const [result] = await pool.query(
      `INSERT INTO exam_timetable (course_id, year, semester, exam_date, start_time, end_time, venue, created_by)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [courseId, year, semester, examDate, startTime, endTime || null, venue || null, req.user.id]
    );
    res.status(201).json({ id: result.insertId, message: "Exam timetable entry added" });
  } catch (err) {
    res.status(500).json({ message: "Failed to add timetable entry", error: err.message });
  }
}

// PUT /api/exam-timetable/:id (admin)
async function updateEntry(req, res) {
  const { id } = req.params;
  const { examDate, startTime, endTime, venue } = req.body;
  try {
    await pool.query(
      `UPDATE exam_timetable SET exam_date = COALESCE(?, exam_date), start_time = COALESCE(?, start_time),
              end_time = ?, venue = COALESCE(?, venue) WHERE id = ?`,
      [examDate || null, startTime || null, endTime || null, venue || null, id]
    );
    res.json({ message: "Timetable entry updated" });
  } catch (err) {
    res.status(500).json({ message: "Failed to update timetable entry", error: err.message });
  }
}

// DELETE /api/exam-timetable/:id (admin)
async function deleteEntry(req, res) {
  const { id } = req.params;
  try {
    await pool.query("DELETE FROM exam_timetable WHERE id = ?", [id]);
    res.json({ message: "Timetable entry deleted" });
  } catch (err) {
    res.status(500).json({ message: "Failed to delete timetable entry", error: err.message });
  }
}

// ─── Exam timetable as an uploaded document (PDF/image) ──────────────────────

// GET /api/exam-timetable/documents — optional ?year=&semester= filter.
// Open to any authenticated role (students need to read it too).
async function listDocuments(req, res) {
  const { year, semester } = req.query;
  let sql = "SELECT * FROM exam_timetable_documents WHERE 1=1";
  const params = [];
  if (year) { sql += " AND year = ?"; params.push(year); }
  if (semester) { sql += " AND semester = ?"; params.push(semester); }
  sql += " ORDER BY uploaded_at DESC";
  try {
    const [rows] = await pool.query(sql, params);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to load exam timetable documents", error: err.message });
  }
}

// POST /api/exam-timetable/documents (admin) — multipart form: file `document`
// plus fields year, semester, title.
async function uploadDocument(req, res) {
  const { year, semester, title } = req.body;
  if (!year || !semester || !req.file) {
    return res.status(400).json({ message: "year, semester and a document file are required" });
  }
  try {
    const filePath = `/uploads/exam_timetable_docs/${req.file.filename}`;
    const [result] = await pool.query(
      `INSERT INTO exam_timetable_documents (year, semester, title, file_path, original_name, uploaded_by)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [year, semester, title || `Year ${year} Semester ${semester} Exam Timetable`, filePath, req.file.originalname, req.user.id]
    );
    res.status(201).json({ id: result.insertId, message: "Exam timetable document uploaded" });
  } catch (err) {
    res.status(500).json({ message: "Failed to upload exam timetable document", error: err.message });
  }
}

// DELETE /api/exam-timetable/documents/:id (admin)
async function deleteDocument(req, res) {
  const { id } = req.params;
  try {
    const [rows] = await pool.query("SELECT file_path FROM exam_timetable_documents WHERE id = ?", [id]);
    await pool.query("DELETE FROM exam_timetable_documents WHERE id = ?", [id]);
    if (rows.length) {
      const fs = require("fs");
      const path = require("path");
      const abs = path.join(__dirname, "..", rows[0].file_path.replace(/^\/uploads\//, "uploads/"));
      fs.unlink(abs, () => {}); // best-effort cleanup, ignore errors
    }
    res.json({ message: "Exam timetable document deleted" });
  } catch (err) {
    res.status(500).json({ message: "Failed to delete exam timetable document", error: err.message });
  }
}

module.exports = { myTimetable, allTimetable, createEntry, updateEntry, deleteEntry, listDocuments, uploadDocument, deleteDocument };
