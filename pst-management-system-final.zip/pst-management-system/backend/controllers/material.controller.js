const pool = require("../config/db");

// GET /api/materials/me (student) — materials for courses the student is
// currently registered in.
async function myMaterials(req, res) {
  try {
    const [student] = await pool.query("SELECT id FROM students WHERE user_id = ?", [req.user.id]);
    if (!student.length) return res.status(404).json({ message: "Student profile not found" });

    const [rows] = await pool.query(
      `SELECT DISTINCT m.id, m.title, m.description, m.file_path, m.original_name, m.uploaded_at,
              c.code, c.name AS course_name, sr.year, sr.semester
       FROM course_materials m
       JOIN courses c ON m.course_id = c.id
       JOIN semester_registration_courses src ON src.course_id = c.id
       JOIN semester_registrations sr ON src.registration_id = sr.id AND sr.student_id = ?
       ORDER BY m.uploaded_at DESC`,
      [student[0].id]
    );

    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to load lecture materials", error: err.message });
  }
}

// POST /api/materials (lecturer) multipart form: courseId, title, description, file
async function uploadMaterial(req, res) {
  const { courseId, title, description } = req.body;
  if (!courseId || !title || !req.file) {
    return res.status(400).json({ message: "courseId, title and a file are required" });
  }
  try {
    const [lecturer] = await pool.query("SELECT id FROM lecturers WHERE user_id = ?", [req.user.id]);
    if (!lecturer.length) return res.status(404).json({ message: "Lecturer profile not found" });

    const [owns] = await pool.query(
      "SELECT 1 FROM lecturer_courses WHERE lecturer_id = ? AND course_id = ?",
      [lecturer[0].id, courseId]
    );
    if (!owns.length) return res.status(403).json({ message: "You are not assigned to this course" });

    const filePath = `/uploads/course_materials/${req.file.filename}`;

    const [result] = await pool.query(
      `INSERT INTO course_materials (course_id, title, description, file_path, original_name, uploaded_by)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [courseId, title, description || null, filePath, req.file.originalname, lecturer[0].id]
    );
    res.status(201).json({ id: result.insertId, message: "Material uploaded" });
  } catch (err) {
    res.status(500).json({ message: "Failed to upload material", error: err.message });
  }
}

// GET /api/materials/course/:courseId (lecturer/admin)
async function courseMaterials(req, res) {
  const { courseId } = req.params;
  try {
    const [rows] = await pool.query(
      `SELECT id, title, description, file_path, original_name, uploaded_at
       FROM course_materials WHERE course_id = ? ORDER BY uploaded_at DESC`,
      [courseId]
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to load materials", error: err.message });
  }
}

// DELETE /api/materials/:id (lecturer — only own upload)
async function deleteMaterial(req, res) {
  const { id } = req.params;
  try {
    const [lecturer] = await pool.query("SELECT id FROM lecturers WHERE user_id = ?", [req.user.id]);
    if (!lecturer.length) return res.status(404).json({ message: "Lecturer profile not found" });

    const [result] = await pool.query(
      "DELETE FROM course_materials WHERE id = ? AND uploaded_by = ?",
      [id, lecturer[0].id]
    );
    if (!result.affectedRows) return res.status(404).json({ message: "Material not found" });
    res.json({ message: "Material deleted" });
  } catch (err) {
    res.status(500).json({ message: "Failed to delete material", error: err.message });
  }
}

module.exports = { myMaterials, uploadMaterial, courseMaterials, deleteMaterial };
