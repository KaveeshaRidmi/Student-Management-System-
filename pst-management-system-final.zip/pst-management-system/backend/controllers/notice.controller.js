const pool = require("../config/db");

// GET /api/notices  -> filtered by the logged-in user's role automatically
async function listNotices(req, res) {
  try {
    const audience = req.user.role === "admin" ? null : req.user.role;
    let sql = `SELECT n.*, u.full_name AS posted_by_name FROM notices n
               JOIN users u ON n.posted_by = u.id`;
    const params = [];
    if (audience) {
      sql += " WHERE n.audience = ? OR n.audience = 'all'";
      params.push(audience);
    }
    sql += " ORDER BY n.created_at DESC";
    const [rows] = await pool.query(sql, params);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to load notices", error: err.message });
  }
}

// POST /api/notices (lecturer/admin) body: { title, content, audience }
async function createNotice(req, res) {
  const { title, content, audience } = req.body;
  if (!title || !content) {
    return res.status(400).json({ message: "title and content are required" });
  }
  try {
    const [result] = await pool.query(
      "INSERT INTO notices (title, content, audience, posted_by) VALUES (?, ?, ?, ?)",
      [title, content, audience || "all", req.user.id]
    );
    res.status(201).json({ id: result.insertId });
  } catch (err) {
    res.status(500).json({ message: "Failed to post notice", error: err.message });
  }
}

// DELETE /api/notices/:id (admin/lecturer, only their own or admin any)
async function deleteNotice(req, res) {
  try {
    if (req.user.role === "admin") {
      await pool.query("DELETE FROM notices WHERE id = ?", [req.params.id]);
    } else {
      await pool.query("DELETE FROM notices WHERE id = ? AND posted_by = ?", [req.params.id, req.user.id]);
    }
    res.json({ message: "Notice deleted" });
  } catch (err) {
    res.status(500).json({ message: "Failed to delete notice", error: err.message });
  }
}

module.exports = { listNotices, createNotice, deleteNotice };
