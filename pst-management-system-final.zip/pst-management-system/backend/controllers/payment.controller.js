const pool = require("../config/db");

// POST /api/payments  (student)
// Card payments: JSON body { purpose, referenceId, amount, method: 'card' }
// Bank slip: multipart form with field "slip" + body { purpose, referenceId, amount, method: 'bank_slip', bankRef }
async function createPayment(req, res) {
  const { purpose, referenceId, amount, method, bankRef } = req.body;
  if (!purpose || !amount || !method) {
    return res.status(400).json({ message: "purpose, amount and method are required" });
  }
  if (method === "bank_slip" && !req.file) {
    return res.status(400).json({ message: "Bank slip payments require a slip upload" });
  }

  try {
    const [student] = await pool.query("SELECT id FROM students WHERE user_id = ?", [req.user.id]);
    if (!student.length) return res.status(404).json({ message: "Student profile not found" });

    const slipPath = req.file ? `/uploads/payment_slips/${req.file.filename}` : null;
    // Card payments are treated as verified immediately (demo gateway); bank slips need admin verification.
    const status = method === "card" ? "verified" : "pending";

    const [result] = await pool.query(
      `INSERT INTO payments (student_id, purpose, reference_id, amount, method, slip_path, bank_ref, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [student[0].id, purpose, referenceId || null, amount, method, slipPath, bankRef || null, status]
    );

    // If verified immediately and tied to a semester registration / exam application, flip its status to confirmed.
    if (status === "verified" && referenceId) {
      if (purpose === "semester_registration") {
        await pool.query("UPDATE semester_registrations SET status='confirmed' WHERE id=?", [referenceId]);
      } else if (purpose === "medical_exam" || purpose === "repeat_exam") {
        await pool.query("UPDATE exam_applications SET status='approved' WHERE id=?", [referenceId]);
      }
    }

    res.status(201).json({ id: result.insertId, status });
  } catch (err) {
    res.status(500).json({ message: "Payment failed", error: err.message });
  }
}

// GET /api/payments/me (student)
async function myPayments(req, res) {
  try {
    const [student] = await pool.query("SELECT id FROM students WHERE user_id = ?", [req.user.id]);
    if (!student.length) return res.status(404).json({ message: "Student profile not found" });

    const [rows] = await pool.query(
      "SELECT * FROM payments WHERE student_id = ? ORDER BY created_at DESC",
      [student[0].id]
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to load payments", error: err.message });
  }
}

// GET /api/payments (admin) -> all payments, esp. pending bank slips to verify
async function allPayments(req, res) {
  try {
    const [rows] = await pool.query(
      `SELECT p.*, s.index_number, u.full_name
       FROM payments p
       JOIN students s ON p.student_id = s.id
       JOIN users u ON s.user_id = u.id
       ORDER BY p.created_at DESC`
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to load payments", error: err.message });
  }
}

// PUT /api/payments/:id/verify (admin) body: { status: 'verified' | 'rejected' }
async function verifyPayment(req, res) {
  const { status } = req.body;
  if (!["verified", "rejected"].includes(status)) {
    return res.status(400).json({ message: "Invalid status" });
  }
  try {
    const [rows] = await pool.query("SELECT * FROM payments WHERE id = ?", [req.params.id]);
    if (!rows.length) return res.status(404).json({ message: "Payment not found" });
    const payment = rows[0];

    await pool.query("UPDATE payments SET status=? WHERE id=?", [status, req.params.id]);

    if (status === "verified" && payment.reference_id) {
      if (payment.purpose === "semester_registration") {
        await pool.query("UPDATE semester_registrations SET status='confirmed' WHERE id=?", [payment.reference_id]);
      } else if (payment.purpose === "medical_exam" || payment.purpose === "repeat_exam") {
        await pool.query("UPDATE exam_applications SET status='approved' WHERE id=?", [payment.reference_id]);
      }
    }

    res.json({ message: "Payment status updated" });
  } catch (err) {
    res.status(500).json({ message: "Failed to verify payment", error: err.message });
  }
}

module.exports = { createPayment, myPayments, allPayments, verifyPayment };
