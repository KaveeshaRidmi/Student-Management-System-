const pool = require("../config/db");
const XLSX = require("xlsx");

// GET /api/results/me  (student)
async function myResults(req, res) {
  try {
    const [student] = await pool.query("SELECT id FROM students WHERE user_id = ?", [req.user.id]);
    if (!student.length) return res.status(404).json({ message: "Student profile not found" });

    const [rows] = await pool.query(
      `SELECT r.id, r.year, r.semester, r.marks, r.grade, c.code, c.name AS course_name, c.credits
       FROM results r JOIN courses c ON r.course_id = c.id
       WHERE r.student_id = ? ORDER BY r.year, r.semester, c.code`,
      [student[0].id]
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to load results", error: err.message });
  }
}

// GET /api/results/course/:courseId  (lecturer) -> list students to enter marks for
async function courseResults(req, res) {
  const { courseId } = req.params;
  try {
    const [rows] = await pool.query(
      `SELECT s.id AS student_id, s.index_number, u.full_name, r.marks, r.grade
       FROM students s
       JOIN users u ON s.user_id = u.id
       LEFT JOIN results r ON r.student_id = s.id AND r.course_id = ?
       ORDER BY s.index_number`,
      [courseId]
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to load results sheet", error: err.message });
  }
}

function gradeFromMarks(marks) {
  if (marks === null || marks === undefined) return null;
  if (marks >= 85) return "A+";
  if (marks >= 70) return "A";
  if (marks >= 65) return "A-";
  if (marks >= 60) return "B+";
  if (marks >= 55) return "B";
  if (marks >= 50) return "B-";
  if (marks >= 45) return "C+";
  if (marks >= 40) return "C";
  if (marks >= 35) return "C-";
  if (marks >= 30) return "D";
  return "F";
}

// POST /api/results/enter (lecturer) body: { courseId, year, semester, records: [{student_id, marks}] }
async function enterResults(req, res) {
  const { courseId, year, semester, records } = req.body;
  if (!courseId || !year || !semester || !Array.isArray(records)) {
    return res.status(400).json({ message: "courseId, year, semester and records[] are required" });
  }

  try {
    const [lect] = await pool.query("SELECT id FROM lecturers WHERE user_id = ?", [req.user.id]);
    const lecturerId = lect.length ? lect[0].id : null;

    const conn = await pool.getConnection();
    try {
      await conn.beginTransaction();
      for (const r of records) {
        const grade = gradeFromMarks(r.marks);
        await conn.query(
          `INSERT INTO results (student_id, course_id, year, semester, marks, grade, entered_by)
           VALUES (?, ?, ?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE marks = VALUES(marks), grade = VALUES(grade), entered_by = VALUES(entered_by)`,
          [r.student_id, courseId, year, semester, r.marks, grade, lecturerId]
        );
      }
      await conn.commit();
      res.json({ message: "Results saved" });
    } catch (err) {
      await conn.rollback();
      throw err;
    } finally {
      conn.release();
    }
  } catch (err) {
    res.status(500).json({ message: "Failed to save results", error: err.message });
  }
}

// GET /api/results/overview (admin)
async function resultsOverview(req, res) {
  try {
    const [rows] = await pool.query(
      `SELECT s.index_number, u.full_name, c.code, c.name AS course_name, r.marks, r.grade
       FROM results r
       JOIN students s ON r.student_id = s.id
       JOIN users u ON s.user_id = u.id
       JOIN courses c ON r.course_id = c.id
       ORDER BY u.full_name, c.code`
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to load results overview", error: err.message });
  }
}

// POST /api/results/upload (lecturer) — multipart form: file, courseCode, year, semester
// Expects a sheet with columns: Index Number, Marks (column names are matched loosely,
// case-insensitively — "Index No", "Reg No" etc. also work for the ID column).
async function uploadResultsSheet(req, res) {
  const { courseCode, year, semester } = req.body;
  if (!req.file) return res.status(400).json({ message: "No file uploaded" });
  if (!courseCode || !year || !semester) {
    return res.status(400).json({ message: "courseCode, year and semester are required" });
  }

  try {
    const [course] = await pool.query("SELECT id FROM courses WHERE code = ?", [courseCode]);
    if (!course.length) return res.status(404).json({ message: `No course found with code ${courseCode}` });
    const courseId = course[0].id;

    const workbook = XLSX.read(req.file.buffer, { type: "buffer" });
    const sheet = workbook.Sheets[workbook.SheetNames[0]];
    const sheetRows = XLSX.utils.sheet_to_json(sheet, { defval: "" });

    if (!sheetRows.length) return res.status(400).json({ message: "The uploaded sheet is empty" });

    const idKeys = ["index number", "index no", "index no.", "reg no", "registration number", "student id"];
    const marksKeys = ["marks", "mark", "total", "total marks"];
    const findKey = (row, candidates) =>
      Object.keys(row).find(k => candidates.includes(k.trim().toLowerCase()));

    const [lect] = await pool.query("SELECT id FROM lecturers WHERE user_id = ?", [req.user.id]);
    const lecturerId = lect.length ? lect[0].id : null;

    const results = [];
    const skipped = [];
    const conn = await pool.getConnection();
    try {
      await conn.beginTransaction();
      for (const row of sheetRows) {
        const idKey = findKey(row, idKeys);
        const marksKey = findKey(row, marksKeys);
        const indexNumber = idKey ? String(row[idKey]).trim() : "";
        const marks = marksKey ? parseFloat(row[marksKey]) : NaN;

        if (!indexNumber || Number.isNaN(marks)) {
          skipped.push(row);
          continue;
        }

        const [student] = await conn.query("SELECT id FROM students WHERE index_number = ?", [indexNumber]);
        if (!student.length) {
          skipped.push(row);
          continue;
        }

        const grade = gradeFromMarks(marks);
        await conn.query(
          `INSERT INTO results (student_id, course_id, year, semester, marks, grade, entered_by)
           VALUES (?, ?, ?, ?, ?, ?, ?)
           ON DUPLICATE KEY UPDATE marks = VALUES(marks), grade = VALUES(grade), entered_by = VALUES(entered_by)`,
          [student[0].id, courseId, year, semester, marks, grade, lecturerId]
        );
        results.push({ indexNumber, marks, grade });
      }
      await conn.commit();
    } catch (err) {
      await conn.rollback();
      throw err;
    } finally {
      conn.release();
    }

    res.json({
      message: `Saved ${results.length} result${results.length !== 1 ? "s" : ""}${skipped.length ? `, skipped ${skipped.length} row(s) that couldn't be matched` : ""}.`,
      saved: results,
      skippedCount: skipped.length,
    });
  } catch (err) {
    res.status(500).json({ message: "Failed to process the uploaded sheet", error: err.message });
  }
}

// GET /api/results/template/:courseId (lecturer) — blank .xlsx template pre-filled with
// the enrolled students' index numbers, ready to fill in and re-upload.
async function downloadTemplate(req, res) {
  const { courseId } = req.params;
  try {
    const [rows] = await pool.query(
      `SELECT s.index_number AS "Index Number", u.full_name AS "Name", "" AS "Marks"
       FROM students s JOIN users u ON s.user_id = u.id
       ORDER BY s.index_number`
    );
    const sheet = XLSX.utils.json_to_sheet(rows.length ? rows : [{ "Index Number": "", "Name": "", "Marks": "" }]);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, sheet, "Marks Template");
    const buffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });

    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    res.setHeader("Content-Disposition", `attachment; filename="marks-template-course-${courseId}.xlsx"`);
    res.send(buffer);
  } catch (err) {
    res.status(500).json({ message: "Failed to generate template", error: err.message });
  }
}

// GET /api/results/download (student) — the signed-in student's own results as .xlsx
// Optional query params: year, semester, code (subject/course code) — narrows the
// sheet down to a specific Year / Semester / Subject combination instead of the
// full history. courseId is also accepted as an alternative to code.
async function downloadMyResults(req, res) {
  try {
    const { year, semester, code, courseId } = req.query;
    const [student] = await pool.query("SELECT id, index_number FROM students WHERE user_id = ?", [req.user.id]);
    if (!student.length) return res.status(404).json({ message: "Student profile not found" });

    const conditions = ["r.student_id = ?"];
    const params = [student[0].id];
    if (year) { conditions.push("r.year = ?"); params.push(year); }
    if (semester) { conditions.push("r.semester = ?"); params.push(semester); }
    if (code) { conditions.push("c.code = ?"); params.push(code); }
    if (courseId) { conditions.push("r.course_id = ?"); params.push(courseId); }

    const [rows] = await pool.query(
      `SELECT c.code AS "Module Code", c.name AS "Module Name", r.year AS "Year", r.semester AS "Semester",
              r.marks AS "Marks", r.grade AS "Grade"
       FROM results r JOIN courses c ON r.course_id = c.id
       WHERE ${conditions.join(" AND ")} ORDER BY r.year, r.semester, c.code`,
      params
    );

    if (!rows.length) return res.status(404).json({ message: "No results found for the selected filters" });

    const sheet = XLSX.utils.json_to_sheet(rows);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, sheet, "My Results");
    const buffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" });

    const parts = [`results-${student[0].index_number}`];
    if (year) parts.push(`Y${year}`);
    if (semester) parts.push(`S${semester}`);
    if (code) parts.push(String(code).replace(/\s+/g, ""));

    res.setHeader("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
    res.setHeader("Content-Disposition", `attachment; filename="${parts.join("-")}.xlsx"`);
    res.send(buffer);
  } catch (err) {
    res.status(500).json({ message: "Failed to generate results file", error: err.message });
  }
}

module.exports = { myResults, courseResults, enterResults, resultsOverview, uploadResultsSheet, downloadTemplate, downloadMyResults };
