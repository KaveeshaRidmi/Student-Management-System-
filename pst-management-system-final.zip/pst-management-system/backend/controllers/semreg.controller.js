const pool = require("../config/db");

async function getRegistrationFee() {
  const [rows] = await pool.query("SELECT setting_value FROM system_settings WHERE setting_key = 'semester_registration_fee'");
  return rows.length ? parseFloat(rows[0].setting_value) : 300; // fallback if not configured yet
}

// POST /api/semreg  (student) body: { year, semester, combination, courseIds: [] }
async function createRegistration(req, res) {
  const { year, semester, combination, courseIds } = req.body;
  if (!year || !semester || !Array.isArray(courseIds) || !courseIds.length) {
    return res.status(400).json({ message: "year, semester and courseIds[] are required" });
  }

  try {
    const [student] = await pool.query("SELECT id FROM students WHERE user_id = ?", [req.user.id]);
    if (!student.length) return res.status(404).json({ message: "Student profile not found" });

    // Flat one-time semester registration fee — same total regardless of
    // how many subjects are registered.
    const totalFee = await getRegistrationFee();

    const conn = await pool.getConnection();
    try {
      await conn.beginTransaction();
      const [result] = await conn.query(
        `INSERT INTO semester_registrations (student_id, year, semester, combination, status, total_fee)
         VALUES (?, ?, ?, ?, 'payment_pending', ?)`,
        [student[0].id, year, semester, combination || null, totalFee]
      );
      for (const courseId of courseIds) {
        await conn.query(
          "INSERT INTO semester_registration_courses (registration_id, course_id) VALUES (?, ?)",
          [result.insertId, courseId]
        );
      }
      await conn.commit();
      res.status(201).json({ id: result.insertId, total_fee: totalFee });
    } catch (err) {
      await conn.rollback();
      throw err;
    } finally {
      conn.release();
    }
  } catch (err) {
    res.status(500).json({ message: "Failed to create registration", error: err.message });
  }
}

// GET /api/semreg/me (student)
async function myRegistrations(req, res) {
  try {
    const [student] = await pool.query("SELECT id FROM students WHERE user_id = ?", [req.user.id]);
    if (!student.length) return res.status(404).json({ message: "Student profile not found" });

    const [regs] = await pool.query(
      "SELECT * FROM semester_registrations WHERE student_id = ? ORDER BY created_at DESC",
      [student[0].id]
    );
    for (const reg of regs) {
      const [courses] = await pool.query(
        `SELECT c.id, c.code, c.name, c.credits, c.year, c.semester, c.compulsory_for, c.elective_for
         FROM semester_registration_courses src
         JOIN courses c ON src.course_id = c.id WHERE src.registration_id = ?`,
        [reg.id]
      );
      reg.courses = courses;
    }
    res.json(regs);
  } catch (err) {
    res.status(500).json({ message: "Failed to load registrations", error: err.message });
  }
}

// GET /api/semreg (lecturer/admin view of all)
async function allRegistrations(req, res) {
  try {
    const [rows] = await pool.query(
      `SELECT sr.*, s.index_number, u.full_name,
              (SELECT COUNT(*) FROM semester_registration_courses src WHERE src.registration_id = sr.id) AS subject_count
       FROM semester_registrations sr
       JOIN students s ON sr.student_id = s.id
       JOIN users u ON s.user_id = u.id
       ORDER BY sr.created_at DESC`
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to load registrations", error: err.message });
  }
}

// POST /api/semreg/admin  (admin) body: { studentId, year, semester, combination, courseIds: [] }
// Lets an admin register a student for courses directly, e.g. over the phone
// or in person, without the student going through the self-service flow.
async function adminCreateRegistration(req, res) {
  const { studentId, year, semester, combination, courseIds } = req.body;
  if (!studentId || !year || !semester || !Array.isArray(courseIds) || !courseIds.length) {
    return res.status(400).json({ message: "studentId, year, semester and courseIds[] are required" });
  }

  try {
    const [student] = await pool.query("SELECT id FROM students WHERE id = ?", [studentId]);
    if (!student.length) return res.status(404).json({ message: "Student not found" });

    const totalFee = await getRegistrationFee();

    const conn = await pool.getConnection();
    try {
      await conn.beginTransaction();
      const [result] = await conn.query(
        `INSERT INTO semester_registrations (student_id, year, semester, combination, status, total_fee)
         VALUES (?, ?, ?, ?, 'confirmed', ?)`,
        [studentId, year, semester, combination || null, totalFee]
      );
      for (const courseId of courseIds) {
        await conn.query(
          "INSERT INTO semester_registration_courses (registration_id, course_id) VALUES (?, ?)",
          [result.insertId, courseId]
        );
      }
      await conn.commit();
      res.status(201).json({ id: result.insertId, total_fee: totalFee });
    } catch (err) {
      await conn.rollback();
      throw err;
    } finally {
      conn.release();
    }
  } catch (err) {
    res.status(500).json({ message: "Failed to create registration", error: err.message });
  }
}

// PUT /api/semreg/:id  (admin) body: { courseIds: [] } — replaces the course
// list on an existing registration (e.g. correcting a mistaken registration).
async function editRegistration(req, res) {
  const { id } = req.params;
  const { courseIds } = req.body;
  if (!Array.isArray(courseIds) || !courseIds.length) {
    return res.status(400).json({ message: "courseIds[] is required" });
  }

  try {
    const [existing] = await pool.query("SELECT id FROM semester_registrations WHERE id = ?", [id]);
    if (!existing.length) return res.status(404).json({ message: "Registration not found" });

    const conn = await pool.getConnection();
    try {
      await conn.beginTransaction();
      await conn.query("DELETE FROM semester_registration_courses WHERE registration_id = ?", [id]);
      for (const courseId of courseIds) {
        await conn.query(
          "INSERT INTO semester_registration_courses (registration_id, course_id) VALUES (?, ?)",
          [id, courseId]
        );
      }
      await conn.commit();
      res.json({ message: "Registration updated" });
    } catch (err) {
      await conn.rollback();
      throw err;
    } finally {
      conn.release();
    }
  } catch (err) {
    res.status(500).json({ message: "Failed to update registration", error: err.message });
  }
}

// PUT /api/semreg/:id/status (admin) body: { status }
async function updateStatus(req, res) {
  const { status } = req.body;
  if (!["pending", "payment_pending", "confirmed", "rejected"].includes(status)) {
    return res.status(400).json({ message: "Invalid status" });
  }
  try {
    await pool.query("UPDATE semester_registrations SET status=? WHERE id=?", [status, req.params.id]);
    res.json({ message: "Status updated" });
  } catch (err) {
    res.status(500).json({ message: "Failed to update status", error: err.message });
  }
}

module.exports = { createRegistration, adminCreateRegistration, editRegistration, myRegistrations, allRegistrations, updateStatus };
