const pool = require("../config/db");

// GET /api/settings — any signed-in user can read (students need the fee/deadline
// to display on the registration page; admin needs it to edit).
async function getSettings(req, res) {
  try {
    const [rows] = await pool.query("SELECT setting_key, setting_value FROM system_settings");
    const settings = {};
    rows.forEach(r => { settings[r.setting_key] = r.setting_value; });
    res.json(settings);
  } catch (err) {
    res.status(500).json({ message: "Failed to load settings", error: err.message });
  }
}

// PUT /api/settings (admin only) body: { settings: { key: value, ... } }
async function updateSettings(req, res) {
  const { settings } = req.body;
  if (!settings || typeof settings !== "object" || !Object.keys(settings).length) {
    return res.status(400).json({ message: "settings object is required" });
  }
  const conn = await pool.getConnection();
  try {
    await conn.beginTransaction();
    for (const [key, value] of Object.entries(settings)) {
      await conn.query(
        `INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?)
         ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)`,
        [key, String(value)]
      );
    }
    await conn.commit();
    res.json({ message: "Settings updated" });
  } catch (err) {
    await conn.rollback();
    res.status(500).json({ message: "Failed to update settings", error: err.message });
  } finally {
    conn.release();
  }
}

module.exports = { getSettings, updateSettings };
