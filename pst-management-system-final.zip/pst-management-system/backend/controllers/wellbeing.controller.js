const pool = require("../config/db");

// POST /api/wellbeing (student)
async function submitCheckin(req, res) {
  const { mood, energy, stress_level, sleep_hours, note, wants_counselor } = req.body;
  try {
    const [student] = await pool.query("SELECT id FROM students WHERE user_id = ?", [req.user.id]);
    if (!student.length) return res.status(404).json({ message: "Student profile not found" });

    const [result] = await pool.query(
      `INSERT INTO wellbeing_checkins (student_id, mood, energy, stress_level, sleep_hours, note, wants_counselor)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [student[0].id, mood || null, energy || null, stress_level || null, sleep_hours || null, note || null, !!wants_counselor]
    );

    if (wants_counselor) {
      await pool.query(
        "INSERT INTO counseling_sessions (student_id, status) VALUES (?, 'requested')",
        [student[0].id]
      );
    }

    res.status(201).json({ id: result.insertId });
  } catch (err) {
    res.status(500).json({ message: "Failed to submit check-in", error: err.message });
  }
}

// GET /api/wellbeing/me (student)
async function myCheckins(req, res) {
  try {
    const [student] = await pool.query("SELECT id FROM students WHERE user_id = ?", [req.user.id]);
    if (!student.length) return res.status(404).json({ message: "Student profile not found" });

    const [rows] = await pool.query(
      "SELECT * FROM wellbeing_checkins WHERE student_id = ? ORDER BY created_at DESC",
      [student[0].id]
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to load check-ins", error: err.message });
  }
}

// GET /api/wellbeing/reports (lecturer/admin)
async function reports(req, res) {
  try {
    const [rows] = await pool.query(
      `SELECT w.*, s.index_number, u.full_name
       FROM wellbeing_checkins w
       JOIN students s ON w.student_id = s.id
       JOIN users u ON s.user_id = u.id
       ORDER BY w.created_at DESC`
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to load wellbeing reports", error: err.message });
  }
}

// GET /api/wellbeing/counseling (admin)
async function listCounseling(req, res) {
  try {
    const [rows] = await pool.query(
      `SELECT cs.*, s.index_number, u.full_name
       FROM counseling_sessions cs
       JOIN students s ON cs.student_id = s.id
       JOIN users u ON s.user_id = u.id
       ORDER BY cs.created_at DESC`
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ message: "Failed to load counseling sessions", error: err.message });
  }
}

// PUT /api/wellbeing/counseling/:id (admin) body: { counselor_name, scheduled_at, status, notes }
async function updateCounseling(req, res) {
  const { counselor_name, scheduled_at, status, notes } = req.body;
  try {
    await pool.query(
      `UPDATE counseling_sessions SET
        counselor_name = COALESCE(?, counselor_name),
        scheduled_at = COALESCE(?, scheduled_at),
        status = COALESCE(?, status),
        notes = COALESCE(?, notes)
       WHERE id = ?`,
      [counselor_name, scheduled_at, status, notes, req.params.id]
    );
    res.json({ message: "Counseling session updated" });
  } catch (err) {
    res.status(500).json({ message: "Failed to update session", error: err.message });
  }
}

module.exports = { submitCheckin, myCheckins, reports, listCounseling, updateCounseling };
