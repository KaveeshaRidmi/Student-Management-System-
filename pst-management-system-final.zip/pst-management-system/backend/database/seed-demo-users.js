// Run with: node database/seed-demo-users.js
// Creates one demo account per portal so you can log in and test right away,
// plus enough related data (course registration, class assignment,
// attendance) so the dashboards show real numbers instead of 0%/empty.
require("dotenv").config();
const bcrypt = require("bcryptjs");
const pool = require("../config/db");

// Year 4 / Semester 1, Computer Science & Technology (C3) track — matches
// the student's batch below and frontend/src/api.js's offline demo data.
const DEMO_COURSE_CODES = [
  "PST 41201", "PST 41227", "PST 41228", "PST 41229",
  "PST 41232", "PST 41230", "PST 41231", "PST 41233",
];

// Per-course attendance to seed for the demo student — a different, non-zero
// figure for each module (out of 10 sessions each) so the dashboard shows a
// realistic, varied picture (~80% overall) instead of 0% everywhere.
const DEMO_ATTENDANCE = [
  { code: "PST 41201", present: 9, absent: 1, late: 0 },   // 90%
  { code: "PST 41227", present: 8, absent: 1, late: 1 },   // 80% (+1 late)
  { code: "PST 41228", present: 7, absent: 3, late: 0 },   // 70%
  { code: "PST 41229", present: 8, absent: 2, late: 0 },   // 80%
  { code: "PST 41232", present: 10, absent: 0, late: 0 },  // 100%
  { code: "PST 41230", present: 6, absent: 3, late: 1 },   // 60% (+1 late)
  { code: "PST 41231", present: 9, absent: 0, late: 1 },   // 90% (+1 late)
  { code: "PST 41233", present: 8, absent: 2, late: 0 },   // 80%
];

async function upsertUser({ username, password, role, full_name, email }) {
  const [existing] = await pool.query("SELECT id FROM users WHERE username = ?", [username]);
  if (existing.length) {
    console.log(`- ${username} already exists, skipping`);
    return existing[0].id;
  }
  const hash = await bcrypt.hash(password, 10);
  const [result] = await pool.query(
    "INSERT INTO users (username, password_hash, role, full_name, email, status) VALUES (?, ?, ?, ?, ?, 'active')",
    [username, hash, role, full_name, email]
  );
  console.log(`+ created ${role}: ${username} / ${password}`);
  return result.insertId;
}

async function getCourseIds(codes) {
  const [rows] = await pool.query(
    `SELECT id, code FROM courses WHERE code IN (?)`,
    [codes]
  );
  const byCode = {};
  rows.forEach(r => { byCode[r.code] = r.id; });
  const missing = codes.filter(c => !byCode[c]);
  if (missing.length) {
    console.log(`  (skipping ${missing.join(", ")} — not found in courses table; run database/seed_courses.sql first)`);
  }
  return byCode;
}

async function assignLecturerToCourses(lecturerId, courseIds) {
  for (const courseId of courseIds) {
    await pool.query(
      `INSERT IGNORE INTO lecturer_courses (lecturer_id, course_id, academic_year) VALUES (?, ?, '2025/2026')`,
      [lecturerId, courseId]
    );
  }
  console.log(`+ assigned lecturer to ${courseIds.length} module(s)`);
}

async function registerStudentForCourses(studentId, courseIds) {
  const [existingReg] = await pool.query(
    "SELECT id FROM semester_registrations WHERE student_id = ? AND year = 4 AND semester = 1",
    [studentId]
  );
  if (existingReg.length) {
    console.log("- semester registration already exists, skipping");
    return existingReg[0].id;
  }
  const [result] = await pool.query(
    `INSERT INTO semester_registrations (student_id, year, semester, combination, status, total_fee)
     VALUES (?, 4, 1, 'C3', 'confirmed', ?)`,
    [studentId, courseIds.length * 300]
  );
  const registrationId = result.insertId;
  for (const courseId of courseIds) {
    await pool.query(
      "INSERT INTO semester_registration_courses (registration_id, course_id) VALUES (?, ?)",
      [registrationId, courseId]
    );
  }
  console.log(`+ registered student for ${courseIds.length} module(s), Year 4 / Semester 1 (confirmed)`);
  return registrationId;
}

async function seedAttendance(studentId, lecturerId, byCode) {
  const [existing] = await pool.query("SELECT id FROM attendance WHERE student_id = ? LIMIT 1", [studentId]);
  if (existing.length) {
    console.log("- attendance already seeded, skipping");
    return;
  }
  let sessionsInserted = 0;
  for (const row of DEMO_ATTENDANCE) {
    const courseId = byCode[row.code];
    if (!courseId) continue;
    const statuses = [
      ...Array(row.present).fill("present"),
      ...Array(row.absent).fill("absent"),
      ...Array(row.late).fill("late"),
    ];
    // Spread sessions weekly, ending last week, so they read as past classes.
    for (let i = 0; i < statuses.length; i++) {
      const daysAgo = (statuses.length - i) * 7;
      const date = new Date();
      date.setDate(date.getDate() - daysAgo);
      const sessionDate = date.toISOString().slice(0, 10);
      await pool.query(
        `INSERT IGNORE INTO attendance (student_id, course_id, session_date, status, marked_by)
         VALUES (?, ?, ?, ?, ?)`,
        [studentId, courseId, sessionDate, statuses[i], lecturerId]
      );
      sessionsInserted++;
    }
  }
  console.log(`+ seeded ${sessionsInserted} attendance session(s) across ${DEMO_ATTENDANCE.length} module(s)`);
}

async function main() {
  // Admin
  await upsertUser({
    username: "admin",
    password: "admin123",
    role: "admin",
    full_name: "System Administrator",
    email: "admin@pst.edu",
  });

  // Lecturer
  const lecturerUserId = await upsertUser({
    username: "L001",
    password: "lecturer123",
    role: "lecturer",
    full_name: "Dr. A. A. Perera",
    email: "perera@pst.edu",
  });
  let [lect] = await pool.query("SELECT id FROM lecturers WHERE user_id = ?", [lecturerUserId]);
  if (!lect.length) {
    await pool.query(
      "INSERT INTO lecturers (user_id, staff_id, designation, department) VALUES (?, 'L001', 'Senior Lecturer', 'PST Dept.')",
      [lecturerUserId]
    );
    [lect] = await pool.query("SELECT id FROM lecturers WHERE user_id = ?", [lecturerUserId]);
  }
  const lecturerId = lect[0].id;

  // Student
  const studentUserId = await upsertUser({
    username: "21APP5710",
    password: "student123",
    role: "student",
    full_name: "M.D. K. Ridmi",
    email: "ridmi@pst.edu",
  });
  let [stu] = await pool.query("SELECT id FROM students WHERE user_id = ?", [studentUserId]);
  if (!stu.length) {
    await pool.query(
      `INSERT INTO students (user_id, index_number, intake_year, current_year, current_semester, program, batch)
       VALUES (?, '21APP5710', 21, 4, 1, 'B.Sc. Physical Sciences', 'C3')`,
      [studentUserId]
    );
    [stu] = await pool.query("SELECT id FROM students WHERE user_id = ?", [studentUserId]);
  }
  const studentId = stu[0].id;

  // Wire the two portals together: same modules assigned to the lecturer
  // and registered for the student, plus attendance between them — so both
  // the Student and Lecturer dashboards show matching, real (non-zero) data.
  const byCode = await getCourseIds(DEMO_COURSE_CODES);
  const courseIds = Object.values(byCode);
  if (courseIds.length) {
    await assignLecturerToCourses(lecturerId, courseIds);
    await registerStudentForCourses(studentId, courseIds);
    await seedAttendance(studentId, lecturerId, byCode);
  }

  console.log("\nDone. Demo logins:");
  console.log("  Admin:    admin / admin123");
  console.log("  Lecturer: L001 / lecturer123");
  console.log("  Student:  21APP5710 / student123");
  process.exit(0);
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});

