const multer = require("multer");
const path = require("path");
const fs = require("fs");

function makeStorage(subfolder) {
  const dir = path.join(__dirname, "..", "uploads", subfolder);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

  return multer.diskStorage({
    destination: (req, file, cb) => cb(null, dir),
    filename: (req, file, cb) => {
      const unique = Date.now() + "-" + Math.round(Math.random() * 1e9);
      cb(null, unique + path.extname(file.originalname));
    },
  });
}

const uploadMedicalDoc = multer({
  storage: makeStorage("medical_docs"),
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
});

const uploadPaymentSlip = multer({
  storage: makeStorage("payment_slips"),
  limits: { fileSize: 5 * 1024 * 1024 },
});

// Marks sheets are parsed in memory (not saved to disk) — only .xlsx/.xls/.csv accepted
const uploadMarksSheet = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 5 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const ok = [
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", // .xlsx
      "application/vnd.ms-excel", // .xls
      "text/csv",
    ].includes(file.mimetype) || /\.(xlsx|xls|csv)$/i.test(file.originalname);
    cb(ok ? null : new Error("Only .xlsx, .xls or .csv files are allowed"), ok);
  },
});

const uploadAssignmentSubmission = multer({
  storage: makeStorage("assignment_submissions"),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
});

// Full exam timetable document (PDF or image) uploaded by admin.
const uploadExamTimetableDoc = multer({
  storage: makeStorage("exam_timetable_docs"),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
  fileFilter: (req, file, cb) => {
    const ok = [
      "application/pdf",
      "image/jpeg",
      "image/png",
      "image/webp",
    ].includes(file.mimetype) || /\.(pdf|jpe?g|png|webp)$/i.test(file.originalname);
    cb(ok ? null : new Error("Only PDF or image files (jpg, png, webp) are allowed"), ok);
  },
});

// Lecture materials (notes/slides) uploaded by a lecturer for a course.
const uploadCourseMaterial = multer({
  storage: makeStorage("course_materials"),
  limits: { fileSize: 20 * 1024 * 1024 }, // 20MB
});

module.exports = { uploadMedicalDoc, uploadPaymentSlip, uploadMarksSheet, uploadAssignmentSubmission, uploadExamTimetableDoc, uploadCourseMaterial };
