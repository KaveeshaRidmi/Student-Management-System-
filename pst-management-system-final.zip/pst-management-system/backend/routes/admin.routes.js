const express = require("express");
const router = express.Router();
const ctrl = require("../controllers/admin.controller");
const { requireAuth, requireRole } = require("../middleware/auth");

// Admin: students management
router.get("/students", requireAuth, requireRole("admin"), ctrl.listStudents);
router.get("/students/pending", requireAuth, requireRole("admin"), ctrl.pendingRegistrations);
router.put("/students/:userId/activate", requireAuth, requireRole("admin"), ctrl.activateStudent);
router.put("/students/:userId/suspend", requireAuth, requireRole("admin"), ctrl.suspendStudent);

// Admin: lecturer accounts & course assignment
router.post("/lecturers", requireAuth, requireRole("admin"), ctrl.createLecturer);
router.post("/lecturer-courses", requireAuth, requireRole("admin"), ctrl.assignLecturerCourse);

// Admin: dashboard
router.get("/dashboard", requireAuth, requireRole("admin"), ctrl.dashboardStats);

// Lecturer: my classes
router.get("/lecturer/classes", requireAuth, requireRole("lecturer"), ctrl.myClasses);

module.exports = router;
