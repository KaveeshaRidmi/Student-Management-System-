const express = require("express");
const router = express.Router();
const ctrl = require("../controllers/assignment.controller");
const { requireAuth, requireRole } = require("../middleware/auth");
const { uploadAssignmentSubmission } = require("../middleware/upload");

router.get("/me", requireAuth, requireRole("student"), ctrl.myAssignments);
router.post("/", requireAuth, requireRole("lecturer"), ctrl.createAssignment);
router.get("/course/:courseId", requireAuth, requireRole("lecturer", "admin"), ctrl.courseAssignments);
router.post("/:id/submit", requireAuth, requireRole("student"), uploadAssignmentSubmission.single("file"), ctrl.submitAssignment);

module.exports = router;
