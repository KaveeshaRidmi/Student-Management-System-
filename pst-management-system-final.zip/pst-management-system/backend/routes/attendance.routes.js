const express = require("express");
const router = express.Router();
const ctrl = require("../controllers/attendance.controller");
const { requireAuth, requireRole } = require("../middleware/auth");

router.get("/me", requireAuth, requireRole("student"), ctrl.myAttendance);
router.get("/course/:courseId", requireAuth, requireRole("lecturer", "admin"), ctrl.courseAttendance);
router.post("/mark", requireAuth, requireRole("lecturer"), ctrl.markAttendance);
router.get("/reports", requireAuth, requireRole("admin"), ctrl.attendanceReports);

module.exports = router;
