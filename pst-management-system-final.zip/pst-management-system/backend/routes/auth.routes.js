const express = require("express");
const router = express.Router();
const { registerStudent, login, me, sendOtp, verifyOtp } = require("../controllers/auth.controller");
const { requireAuth } = require("../middleware/auth");

router.post("/send-otp", sendOtp);
router.post("/verify-otp", verifyOtp);
router.post("/register/student", registerStudent);
router.post("/login", login);
router.get("/me", requireAuth, me);

module.exports = router;
