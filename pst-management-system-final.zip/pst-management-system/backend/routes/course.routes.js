const express = require("express");
const router = express.Router();
const ctrl = require("../controllers/course.controller");
const { requireAuth, requireRole } = require("../middleware/auth");

router.get("/", requireAuth, ctrl.listCourses);
router.post("/", requireAuth, requireRole("admin"), ctrl.createCourse);
router.put("/:id", requireAuth, requireRole("admin"), ctrl.updateCourse);
router.delete("/:id", requireAuth, requireRole("admin"), ctrl.deleteCourse);

module.exports = router;
