const express = require("express");
const router = express.Router();
const ctrl = require("../controllers/exam.controller");
const { requireAuth, requireRole } = require("../middleware/auth");
const { uploadMedicalDoc } = require("../middleware/upload");

router.post("/", requireAuth, requireRole("student"), uploadMedicalDoc.single("medicalDoc"), ctrl.createApplication);
router.get("/me", requireAuth, requireRole("student"), ctrl.myApplications);
router.get("/", requireAuth, requireRole("lecturer", "admin"), ctrl.allApplications);
router.put("/:id/status", requireAuth, requireRole("lecturer", "admin"), ctrl.updateStatus);

module.exports = router;
