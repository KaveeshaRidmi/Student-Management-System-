const express = require("express");
const router = express.Router();
const ctrl = require("../controllers/examtimetable.controller");
const { requireAuth, requireRole } = require("../middleware/auth");
const { uploadExamTimetableDoc } = require("../middleware/upload");

router.get("/me", requireAuth, requireRole("student"), ctrl.myTimetable);
router.get("/", requireAuth, requireRole("lecturer", "admin"), ctrl.allTimetable);
router.post("/", requireAuth, requireRole("admin"), ctrl.createEntry);
router.put("/:id", requireAuth, requireRole("admin"), ctrl.updateEntry);
router.delete("/:id", requireAuth, requireRole("admin"), ctrl.deleteEntry);

// Uploaded exam timetable documents (PDF/image) — readable by any signed-in role.
router.get("/documents", requireAuth, ctrl.listDocuments);
router.post("/documents", requireAuth, requireRole("admin"), uploadExamTimetableDoc.single("document"), ctrl.uploadDocument);
router.delete("/documents/:id", requireAuth, requireRole("admin"), ctrl.deleteDocument);

module.exports = router;
