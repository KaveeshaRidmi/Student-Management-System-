const express = require("express");
const router = express.Router();
const ctrl = require("../controllers/material.controller");
const { requireAuth, requireRole } = require("../middleware/auth");
const { uploadCourseMaterial } = require("../middleware/upload");

router.get("/me", requireAuth, requireRole("student"), ctrl.myMaterials);
router.post("/", requireAuth, requireRole("lecturer"), uploadCourseMaterial.single("file"), ctrl.uploadMaterial);
router.get("/course/:courseId", requireAuth, requireRole("lecturer", "admin"), ctrl.courseMaterials);
router.delete("/:id", requireAuth, requireRole("lecturer"), ctrl.deleteMaterial);

module.exports = router;
