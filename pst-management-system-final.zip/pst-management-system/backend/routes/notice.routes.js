const express = require("express");
const router = express.Router();
const ctrl = require("../controllers/notice.controller");
const { requireAuth, requireRole } = require("../middleware/auth");

router.get("/", requireAuth, ctrl.listNotices);
router.post("/", requireAuth, requireRole("lecturer", "admin"), ctrl.createNotice);
router.delete("/:id", requireAuth, requireRole("lecturer", "admin"), ctrl.deleteNotice);

module.exports = router;
