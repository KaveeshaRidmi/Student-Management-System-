const express = require("express");
const router = express.Router();
const ctrl = require("../controllers/payment.controller");
const { requireAuth, requireRole } = require("../middleware/auth");
const { uploadPaymentSlip } = require("../middleware/upload");

router.post("/", requireAuth, requireRole("student"), uploadPaymentSlip.single("slip"), ctrl.createPayment);
router.get("/me", requireAuth, requireRole("student"), ctrl.myPayments);
router.get("/", requireAuth, requireRole("admin"), ctrl.allPayments);
router.put("/:id/verify", requireAuth, requireRole("admin"), ctrl.verifyPayment);

module.exports = router;
