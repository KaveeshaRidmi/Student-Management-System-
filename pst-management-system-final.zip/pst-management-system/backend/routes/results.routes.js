const express = require("express");
const router = express.Router();
const ctrl = require("../controllers/results.controller");
const { requireAuth, requireRole } = require("../middleware/auth");
const { uploadMarksSheet } = require("../middleware/upload");

router.get("/me", requireAuth, requireRole("student"), ctrl.myResults);
router.get("/download", requireAuth, requireRole("student"), ctrl.downloadMyResults);
router.get("/course/:courseId", requireAuth, requireRole("lecturer", "admin"), ctrl.courseResults);
router.get("/template/:courseId", requireAuth, requireRole("lecturer", "admin"), ctrl.downloadTemplate);
router.post("/enter", requireAuth, requireRole("lecturer"), ctrl.enterResults);
router.post("/upload", requireAuth, requireRole("lecturer"), uploadMarksSheet.single("file"), ctrl.uploadResultsSheet);
router.get("/overview", requireAuth, requireRole("admin"), ctrl.resultsOverview);

module.exports = router;
