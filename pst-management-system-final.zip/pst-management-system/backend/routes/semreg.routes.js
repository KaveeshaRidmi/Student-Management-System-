const express = require("express");
const router = express.Router();
const ctrl = require("../controllers/semreg.controller");
const { requireAuth, requireRole } = require("../middleware/auth");

router.post("/", requireAuth, requireRole("student"), ctrl.createRegistration);
router.post("/admin", requireAuth, requireRole("admin"), ctrl.adminCreateRegistration);
router.get("/me", requireAuth, requireRole("student"), ctrl.myRegistrations);
router.get("/", requireAuth, requireRole("lecturer", "admin"), ctrl.allRegistrations);
router.put("/:id", requireAuth, requireRole("admin"), ctrl.editRegistration);
router.put("/:id/status", requireAuth, requireRole("admin"), ctrl.updateStatus);

module.exports = router;
