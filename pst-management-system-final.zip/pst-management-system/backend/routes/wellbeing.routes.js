const express = require("express");
const router = express.Router();
const ctrl = require("../controllers/wellbeing.controller");
const { requireAuth, requireRole } = require("../middleware/auth");

router.post("/", requireAuth, requireRole("student"), ctrl.submitCheckin);
router.get("/me", requireAuth, requireRole("student"), ctrl.myCheckins);
router.get("/reports", requireAuth, requireRole("lecturer", "admin"), ctrl.reports);
router.get("/counseling", requireAuth, requireRole("admin"), ctrl.listCounseling);
router.put("/counseling/:id", requireAuth, requireRole("admin"), ctrl.updateCounseling);

module.exports = router;
