const express = require("express");
const cors = require("cors");
const path = require("path");
require("dotenv").config();

const app = express();

// ─── Middleware ───────────────────────────────────────────────────────────
const allowedOrigins = (process.env.CORS_ORIGIN || "http://localhost:3000").split(",");
app.use(cors({ origin: allowedOrigins }));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve uploaded files (medical docs / payment slips) statically
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// ─── Routes ───────────────────────────────────────────────────────────────
app.use("/api/auth", require("./routes/auth.routes"));
app.use("/api/courses", require("./routes/course.routes"));
app.use("/api/attendance", require("./routes/attendance.routes"));
app.use("/api/results", require("./routes/results.routes"));
app.use("/api/semreg", require("./routes/semreg.routes"));
app.use("/api/exams", require("./routes/exam.routes"));
app.use("/api/payments", require("./routes/payment.routes"));
app.use("/api/notices", require("./routes/notice.routes"));
app.use("/api/wellbeing", require("./routes/wellbeing.routes"));
app.use("/api/admin", require("./routes/admin.routes"));
app.use("/api/settings", require("./routes/settings.routes"));
app.use("/api/assignments", require("./routes/assignment.routes"));
app.use("/api/exam-timetable", require("./routes/examtimetable.routes"));
app.use("/api/materials", require("./routes/material.routes"));

app.get("/api/health", (req, res) => res.json({ status: "ok", time: new Date().toISOString() }));

// ─── 404 + error handling ──────────────────────────────────────────────────
app.use((req, res) => res.status(404).json({ message: "Route not found" }));
app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ message: "Internal server error", error: err.message });
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`PST backend running on http://localhost:${PORT}`));
