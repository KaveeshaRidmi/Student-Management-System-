-- Run this if you already have the database set up from an earlier version
-- of schema.sql and just need to add compulsory/elective combination
-- filtering to courses without dropping/recreating everything.
--
--   mysql -u root -p pst_management < database/migrations/001_add_course_combination.sql
--   mysql -u root -p pst_management < database/seed_courses.sql   -- safe to re-run; updates existing rows with their combination tags

-- If you ran an earlier version of this migration that added a single
-- `combination` column, drop it first (safe no-op if it doesn't exist).
ALTER TABLE courses DROP COLUMN IF EXISTS combination;

ALTER TABLE courses ADD COLUMN compulsory_for VARCHAR(20) DEFAULT NULL;
ALTER TABLE courses ADD COLUMN elective_for VARCHAR(20) DEFAULT NULL;
