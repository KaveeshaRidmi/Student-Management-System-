-- Run this if you already have the database set up from an earlier version
-- of schema.sql and just need to add the student profile fields (date of
-- birth, gender, profile picture) without dropping/recreating everything.
--
--   mysql -u root -p pst_management < database/migrations/002_add_student_profile_fields.sql

ALTER TABLE students ADD COLUMN date_of_birth DATE AFTER batch;
ALTER TABLE students ADD COLUMN gender VARCHAR(30) AFTER date_of_birth;
ALTER TABLE students ADD COLUMN profile_picture VARCHAR(255) AFTER address;
