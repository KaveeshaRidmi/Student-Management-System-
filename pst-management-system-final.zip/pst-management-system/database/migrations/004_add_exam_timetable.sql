-- Run this if you already have the database set up from an earlier version
-- of schema.sql and just need to add the Exam Timetable feature.
--
--   mysql -u root -p pst_management < database/migrations/004_add_exam_timetable.sql

CREATE TABLE IF NOT EXISTS exam_timetable (
  id INT AUTO_INCREMENT PRIMARY KEY,
  course_id INT NOT NULL,
  year TINYINT NOT NULL,
  semester TINYINT NOT NULL,
  exam_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME,
  venue VARCHAR(150),
  created_by INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);
