-- Run this if you already have the database set up from an earlier version
-- of schema.sql and just need to add the "upload exam timetable as a
-- document" feature (PDF/image of the full timetable) without dropping
-- or recreating everything.
--
--   mysql -u root -p pst_management < database/migrations/005_add_exam_timetable_documents.sql

CREATE TABLE IF NOT EXISTS exam_timetable_documents (
  id INT AUTO_INCREMENT PRIMARY KEY,
  year TINYINT NOT NULL,
  semester TINYINT NOT NULL,
  title VARCHAR(255) NOT NULL,
  file_path VARCHAR(255) NOT NULL,
  original_name VARCHAR(255) NOT NULL,
  uploaded_by INT,             -- admin user_id
  uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL
);
