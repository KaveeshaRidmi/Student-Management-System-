-- Run this if you already have the database set up from an earlier version
-- of schema.sql and just need to add the Lecture Materials feature
-- (lecturer uploads notes/slides, students see them for their registered
-- courses).
--
--   mysql -u root -p pst_management < database/migrations/006_add_course_materials.sql

CREATE TABLE IF NOT EXISTS course_materials (
  id INT AUTO_INCREMENT PRIMARY KEY,
  course_id INT NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  file_path VARCHAR(255) NOT NULL,
  original_name VARCHAR(255) NOT NULL,
  uploaded_by INT,             -- lecturer_id
  uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
  FOREIGN KEY (uploaded_by) REFERENCES lecturers(id) ON DELETE SET NULL
);
