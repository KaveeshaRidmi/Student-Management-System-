-- ═══════════════════════════════════════════════════════════════════════════
-- PST Department Management System — MySQL Schema
-- ═══════════════════════════════════════════════════════════════════════════

CREATE DATABASE IF NOT EXISTS pst_management CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE pst_management;

-- ─── USERS (auth for all 3 portals) ─────────────────────────────────────────
CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,        -- index number (student) / staff id / 'admin'
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('student','lecturer','admin') NOT NULL,
  full_name VARCHAR(150) NOT NULL,
  email VARCHAR(150),
  phone VARCHAR(20),
  status ENUM('active','pending','suspended') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ─── STUDENTS (extra profile info, index number format e.g. 21APP5710) ─────
CREATE TABLE students (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  index_number VARCHAR(20) NOT NULL UNIQUE,     -- e.g. 21APP5710
  intake_year INT NOT NULL,                     -- 21, 22, 23, 24 -> derived academic year
  current_year TINYINT NOT NULL DEFAULT 1,      -- 1..4
  current_semester TINYINT NOT NULL DEFAULT 1,  -- 1 or 2
  program VARCHAR(150) DEFAULT 'B.Sc. Physical Sciences',
  batch VARCHAR(10),                            -- e.g. C3
  date_of_birth DATE,
  gender VARCHAR(30),
  nic VARCHAR(20),
  address VARCHAR(255),
  profile_picture VARCHAR(255),                 -- URL/path to uploaded photo
  guardian_name VARCHAR(150),
  guardian_phone VARCHAR(20),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ─── LECTURERS ───────────────────────────────────────────────────────────────
CREATE TABLE lecturers (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  staff_id VARCHAR(20) UNIQUE,
  designation VARCHAR(100) DEFAULT 'Lecturer',  -- e.g. Senior Lecturer
  department VARCHAR(100) DEFAULT 'PST Dept.',
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- ─── COURSES (from SEMESTER_COURSES table in the app) ──────────────────────
CREATE TABLE courses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  code VARCHAR(20) NOT NULL UNIQUE,
  name VARCHAR(255) NOT NULL,
  credits TINYINT NOT NULL,
  year TINYINT NOT NULL,       -- 1..4
  semester TINYINT NOT NULL,   -- 1 or 2
  -- Which combination(s) this course is COMPULSORY for, comma separated
  -- (C1 = Physics/Applied Physics, C2 = Chemical Technology, C3 = Computer
  -- Science & Technology). 'ALL' means compulsory for every combination —
  -- used for the common Year 1 & Year 2 courses.
  compulsory_for VARCHAR(20) DEFAULT NULL,
  -- Which combination(s) this course is an ELECTIVE option for (student
  -- chooses whether to take it), comma separated. A course can be
  -- compulsory for one combination and elective for another.
  elective_for VARCHAR(20) DEFAULT NULL
);

-- ─── LECTURER <-> COURSES (My Classes) ──────────────────────────────────────
CREATE TABLE lecturer_courses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  lecturer_id INT NOT NULL,
  course_id INT NOT NULL,
  academic_year VARCHAR(9) NOT NULL,   -- e.g. '2025/2026'
  FOREIGN KEY (lecturer_id) REFERENCES lecturers(id) ON DELETE CASCADE,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
  UNIQUE KEY uniq_lect_course_year (lecturer_id, course_id, academic_year)
);

-- ─── SEMESTER REGISTRATION ───────────────────────────────────────────────────
CREATE TABLE semester_registrations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  year TINYINT NOT NULL,
  semester TINYINT NOT NULL,
  combination VARCHAR(100),
  status ENUM('pending','payment_pending','confirmed','rejected') NOT NULL DEFAULT 'pending',
  total_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

CREATE TABLE semester_registration_courses (
  id INT AUTO_INCREMENT PRIMARY KEY,
  registration_id INT NOT NULL,
  course_id INT NOT NULL,
  FOREIGN KEY (registration_id) REFERENCES semester_registrations(id) ON DELETE CASCADE,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

-- ─── EXAM APPLICATIONS (Normal / Medical / Repeat) ──────────────────────────
CREATE TABLE exam_applications (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  exam_type ENUM('normal','medical','repeat') NOT NULL,
  year TINYINT NOT NULL,
  semester TINYINT NOT NULL,
  medical_doc_path VARCHAR(255),           -- uploaded proof for medical
  status ENUM('submitted','approved','rejected','payment_pending') NOT NULL DEFAULT 'submitted',
  total_fee DECIMAL(10,2) NOT NULL DEFAULT 0,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

CREATE TABLE exam_application_subjects (
  id INT AUTO_INCREMENT PRIMARY KEY,
  application_id INT NOT NULL,
  course_id INT NOT NULL,
  FOREIGN KEY (application_id) REFERENCES exam_applications(id) ON DELETE CASCADE,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
);

-- ─── ATTENDANCE ──────────────────────────────────────────────────────────────
CREATE TABLE attendance (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  course_id INT NOT NULL,
  session_date DATE NOT NULL,
  status ENUM('present','absent','late') NOT NULL DEFAULT 'present',
  marked_by INT,   -- lecturer_id
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
  FOREIGN KEY (marked_by) REFERENCES lecturers(id) ON DELETE SET NULL,
  UNIQUE KEY uniq_attendance (student_id, course_id, session_date)
);

-- ─── RESULTS ─────────────────────────────────────────────────────────────────
CREATE TABLE results (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  course_id INT NOT NULL,
  year TINYINT NOT NULL,
  semester TINYINT NOT NULL,
  marks DECIMAL(5,2),
  grade VARCHAR(5),          -- A+, A, B+, ... F
  entered_by INT,            -- lecturer_id
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
  FOREIGN KEY (entered_by) REFERENCES lecturers(id) ON DELETE SET NULL,
  UNIQUE KEY uniq_result (student_id, course_id)
);

-- ─── PAYMENTS (semester reg / medical / repeat / other fees) ───────────────
CREATE TABLE payments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  purpose ENUM('semester_registration','medical_exam','repeat_exam','other') NOT NULL,
  reference_id INT,                 -- FK to semester_registrations.id or exam_applications.id (nullable, no strict FK since it varies)
  amount DECIMAL(10,2) NOT NULL,
  method ENUM('card','bank_slip') NOT NULL,
  slip_path VARCHAR(255),           -- uploaded bank slip image
  bank_ref VARCHAR(100),
  status ENUM('pending','verified','rejected') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

-- ─── NOTICES ─────────────────────────────────────────────────────────────────
CREATE TABLE notices (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  content TEXT NOT NULL,
  audience ENUM('student','lecturer','all') NOT NULL DEFAULT 'all',
  posted_by INT NOT NULL,     -- user_id
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (posted_by) REFERENCES users(id) ON DELETE CASCADE
);

-- ─── EXAM TIMETABLE ────────────────────────────────────────────────────────
CREATE TABLE exam_timetable (
  id INT AUTO_INCREMENT PRIMARY KEY,
  course_id INT NOT NULL,
  year TINYINT NOT NULL,
  semester TINYINT NOT NULL,
  exam_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME,
  venue VARCHAR(150),
  created_by INT,             -- admin user_id
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

-- Full exam timetable published as a single document (PDF/image) instead of
-- (or alongside) individually entered slots — e.g. the official Examinations
-- Department timetable PDF for a given Year/Semester.
CREATE TABLE exam_timetable_documents (
  id INT AUTO_INCREMENT PRIMARY KEY,
  year TINYINT NOT NULL,
  semester TINYINT NOT NULL,
  title VARCHAR(255) NOT NULL,
  file_path VARCHAR(255) NOT NULL,
  original_name VARCHAR(255) NOT NULL,
  uploaded_by INT,             -- admin user_id
  uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (uploaded_by) REFERENCES users(id) ON DELETE SET NULL
);

-- ─── ASSIGNMENTS ─────────────────────────────────────────────────────────────
CREATE TABLE assignments (
  id INT AUTO_INCREMENT PRIMARY KEY,
  course_id INT NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  deadline DATETIME NOT NULL,
  created_by INT,             -- lecturer_id
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
  FOREIGN KEY (created_by) REFERENCES lecturers(id) ON DELETE SET NULL
);

CREATE TABLE assignment_submissions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  assignment_id INT NOT NULL,
  student_id INT NOT NULL,
  file_path VARCHAR(255),
  submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (assignment_id) REFERENCES assignments(id) ON DELETE CASCADE,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
  UNIQUE KEY uniq_submission (assignment_id, student_id)
);

-- ─── LECTURE MATERIALS ───────────────────────────────────────────────────────
-- Notes/slides a lecturer uploads for a course; visible to students who are
-- registered for that course.
CREATE TABLE course_materials (
  id INT AUTO_INCREMENT PRIMARY KEY,
  course_id INT NOT NULL,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  file_path VARCHAR(255) NOT NULL,
  original_name VARCHAR(255) NOT NULL,
  uploaded_by INT,             -- lecturer_id
  uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
  FOREIGN KEY (uploaded_by) REFERENCES lecturers(id) ON DELETE SET NULL
);

-- ─── WELLBEING CHECK-INS ─────────────────────────────────────────────────────
CREATE TABLE wellbeing_checkins (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  mood VARCHAR(20),
  energy VARCHAR(20),
  stress_level VARCHAR(20),
  sleep_hours DECIMAL(3,1),
  note TEXT,
  wants_counselor BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

-- ─── COUNSELING SESSIONS ─────────────────────────────────────────────────────
CREATE TABLE counseling_sessions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  student_id INT NOT NULL,
  counselor_name VARCHAR(150),
  scheduled_at DATETIME,
  status ENUM('requested','scheduled','completed','cancelled') NOT NULL DEFAULT 'requested',
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

-- ─── SYSTEM SETTINGS (admin portal) ──────────────────────────────────────────
CREATE TABLE system_settings (
  setting_key VARCHAR(100) PRIMARY KEY,
  setting_value VARCHAR(255) NOT NULL
);

INSERT INTO system_settings (setting_key, setting_value) VALUES
  ('semester_registration_fee', '300'),  -- flat one-time fee per semester registration, NOT per subject
  ('semester_registration_late_fee', '500'),
  ('semester_registration_deadline', '2025-07-15'),
  ('medical_exam_fee', '25'),
  ('repeat_exam_fee', '25');

-- ─── INDEXES for common lookups ──────────────────────────────────────────────
CREATE INDEX idx_attendance_student ON attendance(student_id);
CREATE INDEX idx_results_student ON results(student_id);
CREATE INDEX idx_payments_student ON payments(student_id);
CREATE INDEX idx_semreg_student ON semester_registrations(student_id);
CREATE INDEX idx_examapp_student ON exam_applications(student_id);
