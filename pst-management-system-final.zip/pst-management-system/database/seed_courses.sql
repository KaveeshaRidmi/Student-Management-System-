-- ═══════════════════════════════════════════════════════════════════════════
-- PST Course List — Sabaragamuwa University of Sri Lanka
-- Faculty of Applied Sciences, Dept. of Physical Sciences and Technology
-- Transcribed from the official PST Curriculum page (Year 1 to Year 4).
-- Source: https://www.sab.ac.lk/app/pst-curriculum
--
-- Safe to re-run: uses ON DUPLICATE KEY UPDATE keyed on `code`, so re-seeding
-- after a curriculum update just refreshes existing rows instead of erroring.
--
-- `compulsory_for` / `elective_for` record which combination(s) — C1 =
-- Physics / Applied Physics, C2 = Chemical Technology, C3 = Computer
-- Science & Technology — a Year 3/4 course belongs to, and whether it's
-- required or optional for that combination. A course can be compulsory
-- for one combination and an elective option for another. Year 1 & 2
-- courses are common to everyone, so `compulsory_for` is 'ALL' and
-- `elective_for` is NULL for those.
--
-- A few inconsistencies in the source PDF required a judgment call — each is
-- flagged inline below with a comment.
-- ═══════════════════════════════════════════════════════════════════════════
-- ─── Year 1 – Semester I ──────────────────────────────────────
INSERT INTO courses (code, name, credits, year, semester, compulsory_for, elective_for) VALUES
  ('PST 11201', 'Mechanics and Properties of Matter', 2, 1, 1, 'ALL', NULL),
  ('PST 11202', 'Introduction to Electricity and Magnetism', 2, 1, 1, 'ALL', NULL),
  ('PST 11103', 'Physics Laboratory 1-I', 1, 1, 1, 'ALL', NULL),
  ('PST 11204', 'General Chemistry', 2, 1, 1, 'ALL', NULL),
  ('PST 11205', 'Fundamentals of Organic Chemistry', 2, 1, 1, 'ALL', NULL),
  ('PST 11106', 'Inorganic Chemistry Laboratory I', 1, 1, 1, 'ALL', NULL),
  ('PST 11107', 'Structured Programming', 1, 1, 1, 'ALL', NULL),
  ('PST 11208', 'Computer Hardware and Software', 2, 1, 1, 'ALL', NULL),
  ('PST 11109', 'Computer Laboratory 1-I', 1, 1, 1, 'ALL', NULL),
  ('PST 11210', 'Calculus and Differential Equations', 2, 1, 1, 'ALL', NULL),
  ('PST-EGP-1101', 'General English I (Non-GPA)', 2, 1, 1, 'ALL', NULL)
ON DUPLICATE KEY UPDATE name=VALUES(name), credits=VALUES(credits), year=VALUES(year), semester=VALUES(semester), compulsory_for=VALUES(compulsory_for), elective_for=VALUES(elective_for);

-- ─── Year 1 – Semester II ──────────────────────────────────────
INSERT INTO courses (code, name, credits, year, semester, compulsory_for, elective_for) VALUES
  ('PST 12201', 'Physics of Heat and Waves', 2, 1, 2, 'ALL', NULL),
  ('PST 12102', 'Semi-Conductor Physics', 1, 1, 2, 'ALL', NULL),
  ('PST 12103', 'AC Theory & Circuits', 1, 1, 2, 'ALL', NULL),
  ('PST 12104', 'Physics Laboratory 1-II', 1, 1, 2, 'ALL', NULL),
  ('PST 12205', 'Fundamentals of Physical Chemistry', 2, 1, 2, 'ALL', NULL),
  ('PST 12206', 'Fundamentals of Analytical Chemistry', 2, 1, 2, 'ALL', NULL),
  ('PST 12107', 'Organic Chemistry Laboratory I', 1, 1, 2, 'ALL', NULL),
  ('PST 12108', 'Object Oriented Programming', 1, 1, 2, 'ALL', NULL),
  ('PST 12209', 'Fundamentals of Statistics', 2, 1, 2, 'ALL', NULL),
  ('PST 12110', 'Computer Laboratory 1-II', 1, 1, 2, 'ALL', NULL),
  ('PST 12211', 'Database Management Systems', 2, 1, 2, 'ALL', NULL),
  ('PST-EGP-1201', 'General English II (Non-GPA)', 2, 1, 2, 'ALL', NULL)
ON DUPLICATE KEY UPDATE name=VALUES(name), credits=VALUES(credits), year=VALUES(year), semester=VALUES(semester), compulsory_for=VALUES(compulsory_for), elective_for=VALUES(elective_for);

-- ─── Year 2 – Semester I ──────────────────────────────────────
INSERT INTO courses (code, name, credits, year, semester, compulsory_for, elective_for) VALUES
  ('PST 21201', 'Electronics', 2, 2, 1, 'ALL', NULL),
  ('PST 21202', 'Geometrical and Physical Optics', 2, 2, 1, 'ALL', NULL),
  ('PST 21103', 'Physics Laboratory 2-I', 1, 2, 1, 'ALL', NULL),
  ('PST 21204', 'Organic Chemistry', 2, 2, 1, 'ALL', NULL),
  ('PST 21205', 'Industrial Chemistry and Technology I (Organic)', 2, 2, 1, 'ALL', NULL),
  ('PST 21106', 'Organic Chemistry Laboratory II', 1, 2, 1, 'ALL', NULL),
  ('PST 21207', 'Data Structures & Algorithms', 2, 2, 1, 'ALL', NULL),
  ('PST 21208', 'Computer Architecture and Assembly Language', 2, 2, 1, 'ALL', NULL),
  ('PST 21209', 'Statistics for Experimental Analysis', 2, 2, 1, 'ALL', NULL),
  ('PST 21110', 'Computer Laboratory 2-I', 1, 2, 1, 'ALL', NULL),
  ('PST 21111', 'Physical Chemistry Laboratory I', 1, 2, 1, 'ALL', NULL),
  ('PST-EAP-2101', 'Academic English I (Non-GPA)', 2, 2, 1, 'ALL', NULL)
ON DUPLICATE KEY UPDATE name=VALUES(name), credits=VALUES(credits), year=VALUES(year), semester=VALUES(semester), compulsory_for=VALUES(compulsory_for), elective_for=VALUES(elective_for);

-- ─── Year 2 – Semester II ──────────────────────────────────────
INSERT INTO courses (code, name, credits, year, semester, compulsory_for, elective_for) VALUES
  ('PST 22201', 'Physics of Electromagnetic Radiation and Introduction to the Laser', 2, 2, 2, 'ALL', NULL),
  ('PST 22202', 'Quantum Physics, Atomic & Nuclear Physics', 2, 2, 2, 'ALL', NULL),
  ('PST 22103', 'Physics Laboratory 2-II', 1, 2, 2, 'ALL', NULL),
  ('PST 22204', 'Chemistry of Elements', 2, 2, 2, 'ALL', NULL),
  ('PST 22205', 'Physical Chemistry', 2, 2, 2, 'ALL', NULL),
  ('PST 22106', 'Inorganic Chemistry Laboratory II', 1, 2, 2, 'ALL', NULL),
  ('PST 22107', 'Analytical Chemistry Laboratory I', 1, 2, 2, 'ALL', NULL),
  ('PST 22208', 'Software Engineering', 2, 2, 2, 'ALL', NULL),
  ('PST 22209', 'Statistical Methodology', 2, 2, 2, 'ALL', NULL),
  ('PST 22110', 'Computer Laboratory 2-II', 1, 2, 2, 'ALL', NULL),
  ('PST 22211', 'Operating Systems', 2, 2, 2, 'ALL', NULL),
  ('PST 22112', 'Leadership and Communication', 1, 2, 2, 'ALL', NULL),
  ('PST 22213', 'Biology for Physical Sciences', 2, 2, 2, 'ALL', NULL),
  ('PST 22114', 'Soft Skill Development', 1, 2, 2, 'ALL', NULL),
  ('PST 22215', 'Mathematical Methods', 2, 2, 2, 'ALL', NULL),
  ('PST 22116', 'Introduction to Astronomy', 1, 2, 2, 'ALL', NULL),
  ('PST 22217', 'Industrial Metrology', 2, 2, 2, 'ALL', NULL),
  ('PST 22218', 'Management Information Systems', 2, 2, 2, 'ALL', NULL),
  ('PST 22219', 'Molecular Spectroscopy', 2, 2, 2, 'ALL', NULL),
  ('PST-EAP-2201', 'Academic English II (Non-GPA)', 2, 2, 2, 'ALL', NULL)
ON DUPLICATE KEY UPDATE name=VALUES(name), credits=VALUES(credits), year=VALUES(year), semester=VALUES(semester), compulsory_for=VALUES(compulsory_for), elective_for=VALUES(elective_for);

-- ─── Year 3 – Semester I ──────────────────────────────────────
INSERT INTO courses (code, name, credits, year, semester, compulsory_for, elective_for) VALUES
  ('PST 31201', 'Solid State Physics', 2, 3, 1, 'C1', NULL),
  ('PST 31202', 'Nuclear Physics & Applications', 2, 3, 1, 'C1', NULL),
  ('PST 31203', 'Quantum Mechanics', 2, 3, 1, 'C1', NULL),
  ('PST 31104', 'Material Physics', 1, 3, 1, 'C1', NULL),
  -- Kept as two distinct courses: PST 31205 (General Physics pathway) and PST 31105
  -- (Special/Honours Applied Physics pathway) — the source PDF lists both consistently.
  ('PST 31205', 'Special Relativity (General — Physics)', 2, 3, 1, 'C1', NULL),
  ('PST 31105', 'Special Relativity (Special — Applied Physics)', 2, 3, 1, 'C1', NULL),
  ('PST 31206', 'Optical Fiber & Telecommunication', 2, 3, 1, 'C1', NULL),
  ('PST 31107', 'Introduction to Nanotechnology', 1, 3, 1, 'C1', 'C2'),
  ('PST 31108', 'Physics Laboratory 3-I', 1, 3, 1, 'C1', NULL),
  ('PST 31209', 'The Origin and Evolution of the Universe', 2, 3, 1, 'C1', NULL),
  ('PST 31210', 'Multimedia and Hypermedia Systems Development', 2, 3, 1, 'C3', 'C1'),
  ('PST 31211', 'Mathematical Programming', 2, 3, 1, 'C1', 'C2,C3'),
  -- "Numerical Methods" normalized to PST 31212 / 2 credits everywhere (source also
  -- shows it as "PST 31112" with 1 or 2 credits depending on section — treated as the
  -- same course, likely a digit-transposition typo).
  ('PST 31212', 'Numerical Methods', 2, 3, 1, NULL, 'C1,C2,C3'),
  ('PST 31213', 'Economics', 2, 3, 1, NULL, 'C1,C2'),
  ('PST 31014', 'Industrial Visit', 0, 3, 1, 'C1,C2,C3', NULL),
  ('PST-EBP-3101', 'Business English (Non-GPA)', 2, 3, 1, 'C1,C2,C3', NULL),
  ('PST 31216', 'Biochemistry-I', 2, 3, 1, 'C2', NULL),
  ('PST 31217', 'Electroanalytical Techniques', 2, 3, 1, 'C2', NULL),
  ('PST 31218', 'Industrial Chemistry and Technology II (Inorganic)', 2, 3, 1, 'C2', NULL),
  ('PST 31219', 'Environmental Chemistry', 2, 3, 1, 'C2', NULL),
  ('PST 31120', 'Coordination Chemistry', 1, 3, 1, 'C2', NULL),
  ('PST 31121', 'Laboratory Quality Control and Assurance', 1, 3, 1, 'C2', NULL),
  ('PST 31122', 'Physical Chemistry Laboratory II', 1, 3, 1, 'C2', NULL),
  ('PST 31123', 'Analytical Chemistry Laboratory II', 1, 3, 1, 'C2', NULL),
  ('PST 31215', 'Agile Software Development', 2, 3, 1, NULL, 'C3'),
  ('PST 31224', 'Artificial Intelligence & Expert Systems', 2, 3, 1, 'C3', NULL),
  ('PST 31225', 'Software Project Management', 2, 3, 1, 'C3', NULL),
  ('PST 31226', 'Software Quality Assurances', 2, 3, 1, 'C3', NULL),
  ('PST 31227', 'Object Oriented Analysis and Design', 2, 3, 1, 'C3', NULL),
  ('PST 31128', 'Computer Laboratory 3-I', 1, 3, 1, 'C3', NULL),
  ('PST 31229', 'Advanced Database Management Systems', 2, 3, 1, 'C3', NULL),
  ('PST 31230', 'Social and Professional Issues in Computing', 2, 3, 1, NULL, 'C3')
ON DUPLICATE KEY UPDATE name=VALUES(name), credits=VALUES(credits), year=VALUES(year), semester=VALUES(semester), compulsory_for=VALUES(compulsory_for), elective_for=VALUES(elective_for);

-- ─── Year 3 – Semester II ──────────────────────────────────────
INSERT INTO courses (code, name, credits, year, semester, compulsory_for, elective_for) VALUES
  ('PST 32801', 'Project Work (Industrial Exposure): B.Sc. Thesis — Major in Applied Physics', 8, 3, 2, 'C1', NULL),
  ('PST 32802', 'Project Work (Industrial Exposure): B.Sc. Thesis — Major in Chemical Technology', 8, 3, 2, 'C2', NULL),
  ('PST 32803', 'Project Work (Industrial Exposure): B.Sc. Thesis — Major in Computer Science & Technology', 8, 3, 2, 'C3', NULL),
  ('PST 32201', 'Statistical Physics', 2, 3, 2, 'C1', NULL),
  ('PST 32102', 'Interaction of Radiation with Matter', 1, 3, 2, 'C1', NULL),
  ('PST 32203', 'Atmospheric Physics & Applications', 2, 3, 2, 'C1', NULL),
  ('PST 32104', 'Advanced Electronics', 1, 3, 2, 'C1', NULL),
  ('PST 32205', 'Solid State Devices', 2, 3, 2, 'C1', NULL),
  ('PST 32206', 'Astrophysics', 2, 3, 2, 'C1', NULL),
  ('PST 32207', 'Atomic and Molecular Spectroscopy', 2, 3, 2, NULL, 'C1'),
  ('PST 32108', 'Current Topics in Physics', 1, 3, 2, 'C1', NULL),
  ('PST 32109', 'Human Resource Management', 1, 3, 2, NULL, 'C1,C2,C3'),
  ('PST 32210', 'Statistics in Quality Control', 2, 3, 2, NULL, 'C1,C2,C3'),
  ('PST 32111', 'Physics Laboratory 3-II', 1, 3, 2, 'C1', NULL),
  ('PST 32212', 'Graph Theory', 2, 3, 2, NULL, 'C1,C3'),
  ('PST 32213', 'Resource Efficient and Cleaner Production', 2, 3, 2, NULL, 'C1,C2'),
  ('PST 32214', 'Chemistry of Drug Design and Drug Action', 2, 3, 2, 'C2', NULL),
  ('PST 32215', 'Polymer Chemistry and Technology', 2, 3, 2, 'C2', NULL),
  ('PST 32216', 'Surface and Colloid Chemistry', 2, 3, 2, 'C2', NULL),
  ('PST 32217', 'Biochemistry II', 2, 3, 2, 'C2', NULL),
  ('PST 32118', 'Advanced Organic Chemistry', 1, 3, 2, 'C2', NULL),
  ('PST 32219', 'Introduction to Organic Electronics', 2, 3, 2, NULL, 'C2'),
  ('PST 32220', 'Structures and Properties of Solids', 2, 3, 2, 'C2', NULL),
  ('PST 32121', 'Advanced Inorganic Chemistry Laboratory', 1, 3, 2, 'C2', NULL),
  ('PST 32122', 'Biochemistry Laboratory', 1, 3, 2, 'C2', NULL),
  ('PST 32223', 'Organometallic Chemistry', 2, 3, 2, NULL, 'C2'),
  ('PST 32224', 'Artificial Neural Networks', 2, 3, 2, 'C3', NULL),
  ('PST 32225', 'Digital Image Processing', 2, 3, 2, 'C3', NULL),
  ('PST 32226', 'Data Mining and Applications', 2, 3, 2, 'C3', NULL),
  ('PST 32227', 'Data Communication and Computer Networks', 2, 3, 2, 'C3', NULL),
  ('PST 32228', 'Computer Graphics & Visualization', 2, 3, 2, 'C3', NULL),
  ('PST 32229', 'Project in Computer Science and Technology (Mini Project)', 2, 3, 2, 'C3', NULL),
  ('PST 32130', 'Computer Laboratory 3-II', 1, 3, 2, 'C3', NULL),
  ('PST 32231', 'Human Computer Interactions', 2, 3, 2, NULL, 'C3'),
  ('PST 32232', 'Bioinformatics', 2, 3, 2, NULL, 'C3'),
  ('PST 32133', 'Current Topics in Computer Technology', 1, 3, 2, NULL, 'C3')
ON DUPLICATE KEY UPDATE name=VALUES(name), credits=VALUES(credits), year=VALUES(year), semester=VALUES(semester), compulsory_for=VALUES(compulsory_for), elective_for=VALUES(elective_for);

-- ─── Year 4 – Semester I ──────────────────────────────────────
INSERT INTO courses (code, name, credits, year, semester, compulsory_for, elective_for) VALUES
  -- "Research Methodology and Scientific Communication" shows 2 credits under Applied
  -- Physics but 0 under Chemical Technology / CS&T in the source — kept at 2 (treating
  -- "0" as a non-GPA/audit weighting).
  ('PST 41201', 'Research Methodology and Scientific Communication', 2, 4, 1, 'C1,C2,C3', NULL),
  ('PST 41202', 'Computational Physics', 2, 4, 1, 'C1', NULL),
  ('PST 41203', 'Robotics', 2, 4, 1, NULL, 'C1,C3'),
  ('PST 41204', 'Remote Sensing & GIS', 2, 4, 1, 'C1', NULL),
  ('PST 41205', 'Geophysics', 2, 4, 1, 'C1', NULL),
  ('PST 41206', 'Medical and Bio Physics', 2, 4, 1, 'C1', NULL),
  ('PST 41207', 'Advanced Nanotechnology', 2, 4, 1, NULL, 'C1,C2'),
  ('PST 41208', 'Data Acquisition and Signal Processing Methods', 2, 4, 1, 'C1', NULL),
  ('PST 41209', 'Advanced Laser Physics', 2, 4, 1, NULL, 'C1'),
  ('PST 41210', 'Automation', 2, 4, 1, NULL, 'C1'),
  ('PST 41211', 'Astronomical Instruments and Data Reduction & Analysis', 2, 4, 1, 'C1', NULL),
  ('PST 41212', 'Electrochemical Power Conversion', 2, 4, 1, NULL, 'C1,C2'),
  ('PST 41013', 'Literature Search Seminar in Applied Physics', 1, 4, 1, 'C1', NULL),
  ('PST 41014', 'Independent Research / Project in Applied Physics', 2, 4, 1, 'C1', NULL),
  ('PST 41215', 'Industrial Management', 2, 4, 1, NULL, 'C1,C2,C3'),
  -- Source reuses code "PST 41216" for two different courses under Applied Physics
  -- ("Classical Mechanics" and "Critical Thinking") — kept for "Classical Mechanics"
  -- only; "Critical Thinking" mapped onto PST 41235, the code already used for the
  -- same title in the other two tracks.
  ('PST 41216', 'Classical Mechanics', 2, 4, 1, 'C1', NULL),
  ('PST 41235', 'Critical Thinking', 2, 4, 1, NULL, 'C1,C2,C3'),
  ('PST 41217', 'Natural Products Chemistry', 2, 4, 1, 'C2', NULL),
  ('PST 41218', 'Biotechnology', 2, 4, 1, 'C2', NULL),
  ('PST 41219', 'Advanced Solid State Chemistry', 2, 4, 1, 'C2', NULL),
  ('PST 41120', 'Bioinorganic Chemistry', 1, 4, 1, 'C2', NULL),
  ('PST 41221', 'Instrumental Analysis', 2, 4, 1, 'C2', NULL),
  ('PST 41222', 'Applied Molecular Modeling', 2, 4, 1, NULL, 'C2'),
  ('PST 41223', 'State of Matter', 2, 4, 1, NULL, 'C2'),
  ('PST 41124', 'Literature Search Seminar in Chemical Technology', 1, 4, 1, 'C2', NULL),
  ('PST 41225', 'Independent Research / Project in Chemical Technology', 2, 4, 1, 'C2', NULL),
  ('PST 41226', 'Computer Applications in Instrumentation', 2, 4, 1, NULL, 'C2'),
  ('PST 41227', 'Web Services', 2, 4, 1, 'C3', NULL),
  ('PST 41228', 'Computer System Security', 2, 4, 1, 'C3', NULL),
  ('PST 41229', 'Advanced Computer Networks', 2, 4, 1, 'C3', NULL),
  ('PST 41230', 'Internet of Things (IoT)', 2, 4, 1, NULL, 'C3'),
  ('PST 41231', 'Natural Language Processing', 2, 4, 1, NULL, 'C3'),
  ('PST 41232', 'Cloud Computing', 2, 4, 1, 'C3', NULL),
  ('PST 41233', 'Business Process Management Systems', 2, 4, 1, NULL, 'C3'),
  ('PST 41234', 'Mobile Computing', 2, 4, 1, NULL, 'C3')
ON DUPLICATE KEY UPDATE name=VALUES(name), credits=VALUES(credits), year=VALUES(year), semester=VALUES(semester), compulsory_for=VALUES(compulsory_for), elective_for=VALUES(elective_for);

-- ─── Year 4 – Semester II ──────────────────────────────────────
INSERT INTO courses (code, name, credits, year, semester, compulsory_for, elective_for) VALUES
  ('PST 42801', 'Project Work (Industrial Exposure): B.Sc. Thesis in Applied Physics', 8, 4, 2, 'C1', NULL),
  ('PST 42102', 'Literature Search Seminar in Applied Physics', 1, 4, 2, 'C1', NULL),
  ('PST 42203', 'Independent Research / Project in Applied Physics', 2, 4, 2, 'C1', NULL),
  ('PST 42804', 'Project Work (Industrial Exposure): B.Sc. Thesis in Chemical Technology', 8, 4, 2, 'C2', NULL),
  ('PST 42803', 'Project: B.Sc. Thesis in Computer Science and Technology', 8, 4, 2, 'C3', NULL),
  ('PST 42606', 'Industrial Training', 6, 4, 2, 'C3', NULL)
ON DUPLICATE KEY UPDATE name=VALUES(name), credits=VALUES(credits), year=VALUES(year), semester=VALUES(semester), compulsory_for=VALUES(compulsory_for), elective_for=VALUES(elective_for);

