# PST Department Management System

A full-featured student management system with three portals:
- 👩‍🎓 **Student Portal** — Dashboard, Modules, Attendance, Results, Semester Registration, Exam Application (Normal / Medical / Repeat), Payments (Card & Bank Slip), Notices, Wellbeing Check-In, Course Catalog
- 👨‍🏫 **Lecturer Portal** — Dashboard, My Classes, Course Catalog, Mark Attendance, Enter Results, Semester Registration View, Exam Applications, Post Notice, Student Wellbeing
- 🛡️ **Admin Portal** — Dashboard, All Students, New Registrations, Attendance Reports, Results Overview, Semester Registration, Exam Applications, Course Catalog, Payment Management, Notices, Wellbeing Reports, Counseling Sessions, System Settings

## Index Number Format
| Prefix | Year     |
|--------|----------|
| 24APP  | 1st Year |
| 23APP  | 2nd Year |
| 22APP  | 3rd Year |
| 21APP  | 4th Year |

## Fees
- Semester Registration: **LKR 300 per subject**
- Medical Exam: **LKR 1,500 per subject**
- Repeat Exam: **LKR 25 per subject**

## Getting Started

### Prerequisites
- Node.js v16 or higher
- npm v8 or higher

### Installation & Run
```bash
npm install
npm start
```
The app opens at **http://localhost:3000**

### Build for Production
```bash
npm run build
```

## Portal Access (Demo)
Select any portal on the login screen and click **Sign In** — no real credentials required in demo mode.
