import { useState, useEffect, Fragment } from "react";
import * as XLSX from "xlsx";
import api, { getToken, setToken, clearToken, fileUrl } from "./api";

// ─── DESIGN TOKENS ───────────────────────────────────────────────────────────
const COLORS = {
  primary: "#122A44",
  primaryLight: "#24466E",
  accent: "#B08948",
  accentGold: "#C9A66B",
  success: "#2F6F52",
  warning: "#B8863B",
  danger: "#A23B33",
  bg: "#F7F5F1",
  card: "#FFFFFF",
  sidebar: "#122A44",
  sidebarHover: "#1D3A5C",
  textPrimary: "#1C1C22",
  textSecondary: "#54555C",
  textMuted: "#8B8C93",
  border: "#E6E1D8",
  gradStart: "#122A44",
  gradEnd: "#24466E",
};

// ─── ICONS (SVG inline) ───────────────────────────────────────────────────────
const Icon = ({ name, size = 18, color = "currentColor" }) => {
  const icons = {
    dashboard: <><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></>,
    modules: <><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></>,
    attendance: <><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></>,
    results: <><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></>,
    exam: <><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/><polyline points="10 9 9 9 8 9"/></>,
    payment: <><rect x="1" y="4" width="22" height="16" rx="2" ry="2"/><line x1="1" y1="10" x2="23" y2="10"/></>,
    notices: <><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></>,
    wellbeing: <><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></>,
    classes: <><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></>,
    mark: <><polyline points="20 6 9 17 4 12"/></>,
    enter: <><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></>,
    post: <><path d="M12 20h9"/><path d="M16.5 3.5a2.121 2.121 0 0 1 3 3L7 19l-4 1 1-4L16.5 3.5z"/></>,
    students: <><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></>,
    registration: <><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="8.5" cy="7" r="4"/><line x1="20" y1="8" x2="20" y2="14"/><line x1="23" y1="11" x2="17" y2="11"/></>,
    report: <><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></>,
    catalog: <><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></>,
    settings: <><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></>,
    signout: <><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/></>,
    counseling: <><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></>,
    overview: <><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></>,
    user: <><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></>,
    bell: <><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></>,
    trend: <><polyline points="22 7 13.5 15.5 8.5 10.5 2 17"/><polyline points="16 7 22 7 22 13"/></>,
    check: <><polyline points="20 6 9 17 4 12"/></>,
    star: <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>,
    bank: <><line x1="3" y1="21" x2="21" y2="21"/><line x1="5" y1="21" x2="5" y2="10"/><line x1="9" y1="21" x2="9" y2="10"/><line x1="15" y1="21" x2="15" y2="10"/><line x1="19" y1="21" x2="19" y2="10"/><polygon points="12 2 21 8 3 8"/></>,
    lock: <><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></>,
    alert: <><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></>,
    key: <><circle cx="7.5" cy="15.5" r="5.5"/><path d="M21 2l-9.6 9.6"/><path d="M15.5 7.5L18 5l2 2-2.5 2.5"/></>,
    graduation: <><path d="M22 10L12 5 2 10l10 5 10-5z"/><path d="M6 12v5c0 1.5 2.7 3 6 3s6-1.5 6-3v-5"/></>,
    eye: <><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/></>,
    eyeOff: <><path d="M17.94 17.94A10.94 10.94 0 0 1 12 20c-7 0-11-8-11-8a19.4 19.4 0 0 1 5.06-5.94M9.9 4.24A10.94 10.94 0 0 1 12 4c7 0 11 8 11 8a19.5 19.5 0 0 1-2.16 3.19"/><path d="M14.12 14.12a3 3 0 1 1-4.24-4.24"/><line x1="1" y1="1" x2="23" y2="23"/></>,
    shieldAdmin: <path d="M12 2 4 5v6c0 5.25 3.4 9.74 8 11 4.6-1.26 8-5.75 8-11V5l-8-3z"/>,
    sparkle: <path d="M12 3l1.9 5.6L19.5 10l-5.6 1.9L12 17.5l-1.9-5.6L4.5 10l5.6-1.9L12 3z"/>,
    phone: <><rect x="7" y="2" width="10" height="20" rx="2"/><line x1="11" y1="18" x2="13" y2="18"/></>,
    medical: <><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></>,
    repeat: <><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></>,
  };
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      {icons[name] || null}
    </svg>
  );
};

// ─── STAT CARD ────────────────────────────────────────────────────────────────
const StatCard = ({ label, value, icon, color = COLORS.accent, trend }) => (
  <div style={{
    background: COLORS.card, borderRadius: 14, padding: "22px 24px",
    boxShadow: "0 2px 12px rgba(30,58,95,0.08)", display: "flex",
    alignItems: "center", gap: 18, flex: 1, minWidth: 160,
  }}>
    <div style={{
      width: 52, height: 52, borderRadius: 12,
      background: color + "18", display: "flex", alignItems: "center", justifyContent: "center",
    }}>
      <Icon name={icon} size={24} color={color} />
    </div>
    <div>
      <div style={{ fontSize: 26, fontWeight: 700, color: COLORS.textPrimary, lineHeight: 1 }}>{value}</div>
      <div style={{ fontSize: 13, color: COLORS.textMuted, marginTop: 4 }}>{label}</div>
      {trend && <div style={{ fontSize: 12, color: COLORS.success, marginTop: 2, fontWeight: 600 }}>↑ {trend}</div>}
    </div>
  </div>
);

// ─── TABLE ────────────────────────────────────────────────────────────────────
const Table = ({ headers, rows, badge }) => (
  <div style={{ overflowX: "auto" }}>
    <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
      <thead>
        <tr style={{ background: COLORS.bg }}>
          {headers.map((h, i) => (
            <th key={i} style={{ padding: "12px 16px", textAlign: "left", color: COLORS.textSecondary, fontWeight: 600, fontSize: 12, textTransform: "uppercase", letterSpacing: "0.05em" }}>{h}</th>
          ))}
        </tr>
      </thead>
      <tbody>
        {rows.map((row, i) => (
          <tr key={i} style={{ borderBottom: `1px solid ${COLORS.border}` }}>
            {row.map((cell, j) => (
              <td key={j} style={{ padding: "13px 16px", color: COLORS.textPrimary }}>
                {badge && j === row.length - 1
                  ? <span style={{ padding: "3px 10px", borderRadius: 20, fontSize: 12, fontWeight: 600, background: cell === "Present" || cell === "Pass" || cell === "Active" || cell === "Paid" ? COLORS.success + "18" : cell === "Absent" || cell === "Fail" ? COLORS.danger + "18" : COLORS.warning + "18", color: cell === "Present" || cell === "Pass" || cell === "Active" || cell === "Paid" ? COLORS.success : cell === "Absent" || cell === "Fail" ? COLORS.danger : COLORS.warning }}>{cell}</span>
                  : cell}
              </td>
            ))}
          </tr>
        ))}
      </tbody>
    </table>
  </div>
);

// ─── SECTION CARD ─────────────────────────────────────────────────────────────
const SectionCard = ({ title, children, action, onAction }) => (
  <div style={{ background: COLORS.card, borderRadius: 14, boxShadow: "0 2px 12px rgba(30,58,95,0.08)", overflow: "hidden", marginBottom: 24 }}>
    <div style={{ padding: "18px 24px", borderBottom: `1px solid ${COLORS.border}`, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
      <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: COLORS.textPrimary }}>{title}</h3>
      {action && <button onClick={onAction} style={{ background: COLORS.primary, color: "#fff", border: "none", borderRadius: 8, padding: "7px 16px", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>{action}</button>}
    </div>
    <div style={{ padding: 24 }}>{children}</div>
  </div>
);

// ─── PROGRESS BAR ─────────────────────────────────────────────────────────────
const ProgressBar = ({ value, color = COLORS.accent, label }) => (
  <div style={{ marginBottom: 14 }}>
    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6, fontSize: 13 }}>
      <span style={{ color: COLORS.textSecondary }}>{label}</span>
      <span style={{ fontWeight: 600, color: COLORS.textPrimary }}>{value}%</span>
    </div>
    <div style={{ height: 8, background: COLORS.border, borderRadius: 99 }}>
      <div style={{ width: `${value}%`, height: "100%", borderRadius: 99, background: color, transition: "width 0.5s" }} />
    </div>
  </div>
);

// ─── FORM FIELD ───────────────────────────────────────────────────────────────
const Field = ({ label, type = "text", options, placeholder, value, onChange }) => (
  <div style={{ marginBottom: 18 }}>
    <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>{label}</label>
    {type === "select" ? (
      <select value={value} onChange={onChange ? e => onChange(e.target.value) : undefined} style={{ width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, color: COLORS.textPrimary, background: "#fff", outline: "none" }}>
        {options.map((o, i) => <option key={i}>{o}</option>)}
      </select>
    ) : type === "textarea" ? (
      <textarea rows={4} placeholder={placeholder} value={value} onChange={onChange ? e => onChange(e.target.value) : undefined} style={{ width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, resize: "vertical", outline: "none", boxSizing: "border-box" }} />
    ) : (
      <input type={type} placeholder={placeholder} value={value} onChange={onChange ? e => onChange(e.target.value) : undefined} style={{ width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, outline: "none", boxSizing: "border-box" }} />
    )}
  </div>
);

// ═══════════════════════════════════════════════════════════════════════════════
// STUDENT PORTAL PAGES
// ═══════════════════════════════════════════════════════════════════════════════

const StudentDashboard = () => {
  const [user, setUser] = useState(null);
  const [stats, setStats] = useState(null);
  const [modules, setModules] = useState([]);
  const [notices, setNotices] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([api.me(), api.myAttendance(), api.myResults(), api.mySemRegs(), api.notices()])
      .then(([me, attendance, results, regs, allNotices]) => {
        setUser(me);

        const byCode = {};
        (attendance || []).forEach(a => {
          if (!byCode[a.code]) byCode[a.code] = { present: 0, total: 0, name: a.course_name };
          byCode[a.code].total++;
          if (a.status === "present") byCode[a.code].present++;
        });
        const attendedTotal = attendance.length;
        const attendedPresent = attendance.filter(a => a.status === "present").length;
        const attendedAbsent = attendance.filter(a => a.status === "absent").length;
        const attendedLate = attendance.filter(a => a.status === "late").length;
        const attendancePct = attendedTotal ? Math.round((attendedPresent / attendedTotal) * 100) : 0;

        const graded = results.filter(r => r.grade && r.grade in GRADE_POINTS);
        const totalCredits = graded.reduce((s, r) => s + (r.credits || 0), 0);
        const gpa = totalCredits ? (graded.reduce((s, r) => s + GRADE_POINTS[r.grade] * (r.credits || 0), 0) / totalCredits) : 0;

        const latestReg = regs && regs.length ? regs[0] : null;
        const registeredCredits = (latestReg?.courses || []).reduce((s, c) => s + (c.credits || 0), 0);

        setStats({
          courses: latestReg?.courses?.length || 0,
          attendancePct,
          attendedTotal,
          attendedPresent,
          attendedAbsent,
          attendedLate,
          gpa: gpa.toFixed(2),
          credits: registeredCredits,
        });

        setModules((latestReg?.courses || []).map(c => {
          const att = byCode[c.code];
          return { name: c.name, progress: att ? Math.round((att.present / att.total) * 100) : 0 };
        }));

        setNotices((allNotices || []).slice(0, 3));
      })
      .catch(err => setError(err.message));
  }, []);

  if (error) return <div style={{ color: COLORS.danger, fontSize: 14 }}>{error}</div>;
  if (!user || !stats) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading dashboard…</div>;

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <h2 style={{ margin: 0, fontSize: 24, fontWeight: 700, color: COLORS.textPrimary }}>Welcome back, {user.full_name || user.username}</h2>
        <p style={{ color: COLORS.textMuted, marginTop: 4 }}>{user.program} · Year {user.current_year} · Semester {user.current_semester}</p>
      </div>

      <SectionCard title="Student Profile">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 18 }}>
          {[
            ["Student Name", user.full_name || user.username],
            ["Student ID", user.index_number || user.username],
            ["Degree Programme", user.program || "—"],
            ["Current Semester", `Year ${user.current_year} · Semester ${user.current_semester}`],
          ].map(([label, value], i) => (
            <div key={i}>
              <div style={{ fontSize: 11, fontWeight: 600, color: COLORS.textMuted, textTransform: "uppercase", letterSpacing: "0.04em", marginBottom: 4 }}>{label}</div>
              <div style={{ fontSize: 15, fontWeight: 700, color: COLORS.textPrimary }}>{value}</div>
            </div>
          ))}
        </div>
      </SectionCard>

      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 24 }}>
        <StatCard label="Courses Enrolled" value={String(stats.courses)} icon="modules" color={COLORS.accent} />
        <StatCard label="Attendance Rate" value={`${stats.attendancePct}%`} icon="attendance" color={COLORS.success} />
        <StatCard label="Credits" value={String(stats.credits)} icon="star" color={COLORS.primaryLight} />
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
        <SectionCard title="Attendance Summary">
          {stats.attendedTotal === 0 ? (
            <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No attendance records yet.</div>
          ) : (
            <>
              <ProgressBar value={stats.attendancePct} label="Overall Attendance" color={stats.attendancePct >= 85 ? COLORS.success : stats.attendancePct >= 70 ? COLORS.accentGold : COLORS.danger} />
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12, marginTop: 14 }}>
                {[["Present", stats.attendedPresent, COLORS.success], ["Absent", stats.attendedAbsent, COLORS.danger], ["Late", stats.attendedLate, COLORS.accentGold]].map(([label, val, c], i) => (
                  <div key={i} style={{ background: c + "10", borderRadius: 10, padding: "10px 12px", textAlign: "center" }}>
                    <div style={{ fontSize: 20, fontWeight: 800, color: c }}>{val}</div>
                    <div style={{ fontSize: 11, color: COLORS.textMuted, marginTop: 2 }}>{label}</div>
                  </div>
                ))}
              </div>
            </>
          )}
        </SectionCard>
        <SectionCard title="Module Progress">
          {modules.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No registered modules yet.</div> : modules.map((m, i) => (
            <ProgressBar key={i} value={m.progress} label={m.name} color={[COLORS.accent, COLORS.success, COLORS.accentGold, COLORS.primaryLight][i % 4]} />
          ))}
        </SectionCard>
        <SectionCard title="Upcoming Schedule">
          <div style={{ color: COLORS.textMuted, fontSize: 13, padding: "10px 0" }}>Timetable data isn't available yet — check with your department for the current class schedule.</div>
        </SectionCard>
        <SectionCard title="Recent Notices">
          {notices.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No notices yet.</div> : notices.map((n, i) => (
            <div key={n.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", padding: "10px 0", borderBottom: i < notices.length - 1 ? `1px solid ${COLORS.border}` : "none" }}>
              <div>
                <div style={{ fontWeight: 600, fontSize: 14, color: COLORS.textPrimary }}>{n.title}</div>
                <div style={{ fontSize: 12, color: COLORS.textMuted }}>{new Date(n.created_at).toLocaleDateString()}</div>
              </div>
            </div>
          ))}
        </SectionCard>
      </div>
    </div>
  );
};

const GENDER_LABELS = { Male: "Male", Female: "Female", "Prefer not to say": "Prefer not to say" };

const StudentProfile = () => {
  const [user, setUser] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api.me().then(setUser).catch(err => setError(err.message));
  }, []);

  if (error) return <div style={{ color: COLORS.danger, fontSize: 14 }}>{error}</div>;
  if (!user) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading profile…</div>;

  const fields = [
    ["Student ID", user.index_number || user.username],
    ["Full Name", user.full_name],
    ["Date of Birth", user.date_of_birth ? new Date(user.date_of_birth).toLocaleDateString(undefined, { year: "numeric", month: "long", day: "numeric" }) : "—"],
    ["Gender", GENDER_LABELS[user.gender] || user.gender || "—"],
    ["Address", user.address || "—"],
    ["Phone Number", user.phone || "—"],
    ["Email", user.email || "—"],
    ["Degree Programme", user.program || "—"],
    ["Academic Year", user.current_year ? `Year ${user.current_year} · Semester ${user.current_semester}` : "—"],
  ];

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>Student Profile</h2>
      <SectionCard title="">
        <div style={{ display: "flex", gap: 28, alignItems: "flex-start", flexWrap: "wrap" }}>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12, minWidth: 140 }}>
            {user.profile_picture ? (
              <img src={user.profile_picture} alt="Profile" style={{ width: 120, height: 120, borderRadius: "50%", objectFit: "cover", border: `3px solid ${COLORS.border}` }} />
            ) : (
              <div style={{ width: 120, height: 120, borderRadius: "50%", background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.accent})`, display: "flex", alignItems: "center", justifyContent: "center" }}>
                <Icon name="user" size={48} color="#fff" />
              </div>
            )}
            <div style={{ fontSize: 13, color: COLORS.textMuted, textAlign: "center" }}>No photo uploaded</div>
          </div>
          <div style={{ flex: 1, minWidth: 280, display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 20 }}>
            {fields.map(([label, value], i) => (
              <div key={i}>
                <div style={{ fontSize: 11, fontWeight: 600, color: COLORS.textMuted, textTransform: "uppercase", letterSpacing: "0.04em", marginBottom: 4 }}>{label}</div>
                <div style={{ fontSize: 15, fontWeight: 600, color: COLORS.textPrimary }}>{value}</div>
              </div>
            ))}
          </div>
        </div>
      </SectionCard>
    </div>
  );
};

const StudentModules = () => {
  const [modules, setModules] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([api.mySemRegs(), api.myAttendance()])
      .then(([regs, attendance]) => {
        const latest = regs && regs.length ? regs[0] : null;
        const byCode = {};
        (attendance || []).forEach(a => {
          if (!byCode[a.code]) byCode[a.code] = { present: 0, total: 0 };
          byCode[a.code].total++;
          if (a.status === "present") byCode[a.code].present++;
        });
        const list = (latest?.courses || []).map(c => {
          const att = byCode[c.code];
          const progress = att ? Math.round((att.present / att.total) * 100) : null;
          return { code: c.code, name: c.name, credits: c.credits, progress };
        });
        setModules(list);
      })
      .catch(err => setError(err.message));
  }, []);

  if (error) return <div style={{ color: COLORS.danger, fontSize: 14 }}>{error}</div>;
  if (!modules) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading modules…</div>;

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>My Modules</h2>
      {modules.length === 0 ? (
        <div style={{ color: COLORS.textMuted, fontSize: 14 }}>You haven't registered for any modules yet. Head to Semester Registration to get started.</div>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 20 }}>
          {modules.map((m, i) => (
            <div key={i} style={{ background: COLORS.card, borderRadius: 14, overflow: "hidden", boxShadow: "0 2px 12px rgba(30,58,95,0.08)" }}>
              <div style={{ background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.primaryLight})`, padding: "20px 20px 16px" }}>
                <div style={{ fontSize: 12, fontWeight: 700, color: COLORS.accent, marginBottom: 4 }}>{m.code} · {m.credits} Credits</div>
                <div style={{ fontSize: 16, fontWeight: 700, color: "#fff" }}>{m.name}</div>
              </div>
              <div style={{ padding: 20 }}>
                {m.progress === null ? (
                  <div>
                    <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6, fontSize: 13 }}>
                      <span style={{ color: COLORS.textSecondary }}>Attendance Progress</span>
                      <span style={{ fontWeight: 600, color: COLORS.textMuted }}>N/A</span>
                    </div>
                    <div style={{ height: 8, background: COLORS.border, borderRadius: 99 }} />
                    <div style={{ fontSize: 12, color: COLORS.textMuted, marginTop: 6 }}>No attendance recorded yet</div>
                  </div>
                ) : (
                  <ProgressBar value={m.progress} label="Attendance Progress" color={m.progress > 70 ? COLORS.success : m.progress > 50 ? COLORS.accentGold : COLORS.danger} />
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

const StudentCourseRegistration = () => {
  const [user, setUser] = useState(null);
  const [year, setYear] = useState("");
  const [semester, setSemester] = useState("");
  const [available, setAvailable] = useState(null);
  const [regs, setRegs] = useState(null);
  const [selected, setSelected] = useState([]);
  const [tab, setTab] = useState("available"); // available | registered
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [submitMsg, setSubmitMsg] = useState("");

  useEffect(() => {
    api.me().then(u => {
      setUser(u);
      setYear(String(u.current_year));
      setSemester(String(u.current_semester));
    }).catch(err => setError(err.message));
  }, []);

  const loadRegistered = () => api.mySemRegs().then(setRegs).catch(() => setRegs([]));
  useEffect(() => { loadRegistered(); }, []);

  useEffect(() => {
    if (!year || !semester || !user) return;
    const combo = user.batch ? user.batch.split(" ")[0] : null;
    setAvailable(null);
    api.courses(year, semester, combo)
      .then(rows => {
        setAvailable(rows);
        setSelected(rows.filter(r => !r.is_elective).map(r => r.id)); // compulsory auto-included
        setSubmitMsg("");
      })
      .catch(err => setError(err.message));
  }, [year, semester, user]);

  if (error) return <div style={{ color: COLORS.danger, fontSize: 14 }}>{error}</div>;
  if (!user) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading…</div>;

  const alreadyRegisteredCodes = new Set(
    (regs || [])
      .filter(r => String(r.year) === year && String(r.semester) === semester)
      .flatMap(r => (r.courses || []).map(c => c.code))
  );

  const toggle = (course) => {
    if (!course.is_elective) return; // compulsory — locked
    setSelected(s => s.includes(course.id) ? s.filter(x => x !== course.id) : [...s, course.id]);
  };

  const handleRegister = async () => {
    if (!selected.length) return;
    setSubmitting(true);
    setSubmitMsg("");
    try {
      await api.createSemReg({ year: parseInt(year, 10), semester: parseInt(semester, 10), combination: user.batch || null, courseIds: selected });
      setSubmitMsg("Registered successfully.");
      loadRegistered();
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const allRegisteredRows = (regs || []).flatMap(r => (r.courses || []).map(c => ({ ...c, regYear: r.year, regSemester: r.semester, status: r.status })));

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 8 }}>Course Registration</h2>
      <p style={{ color: COLORS.textMuted, marginBottom: 20, fontSize: 14 }}>{user.program}{user.batch ? ` (${user.batch})` : ""}</p>

      <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
        {[["available", "Available Courses"], ["registered", "My Registered Courses"]].map(([k, label]) => (
          <button key={k} onClick={() => setTab(k)}
            style={{ padding: "9px 20px", borderRadius: 10, border: `2px solid ${tab === k ? COLORS.primary : COLORS.border}`, background: tab === k ? COLORS.primary : "#fff", color: tab === k ? "#fff" : COLORS.textSecondary, fontWeight: 700, fontSize: 14, cursor: "pointer" }}>
            {label}
          </button>
        ))}
      </div>

      {tab === "available" && (
        <>
          <SectionCard title="Filter">
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
              <div>
                <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Academic Year</label>
                <select value={year} onChange={e => setYear(e.target.value)} style={{ width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, background: "#fff" }}>
                  <option value="1">Year 1</option><option value="2">Year 2</option><option value="3">Year 3</option><option value="4">Year 4</option>
                </select>
              </div>
              <div>
                <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Semester</label>
                <select value={semester} onChange={e => setSemester(e.target.value)} style={{ width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, background: "#fff" }}>
                  <option value="1">Semester I</option><option value="2">Semester II</option>
                </select>
              </div>
            </div>
          </SectionCard>

          <SectionCard title="Available Courses" action={submitting ? "Registering…" : "Register Selected Courses"} onAction={submitting ? undefined : handleRegister}>
            {submitMsg && <div style={{ color: COLORS.success, fontSize: 13, fontWeight: 600, marginBottom: 14, display: "flex", alignItems: "center", gap: 6 }}><Icon name="check" size={14} color={COLORS.success} /> {submitMsg}</div>}
            {!available ? (
              <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading courses…</div>
            ) : available.length === 0 ? (
              <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No courses found for this year/semester.</div>
            ) : (
              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
                <thead>
                  <tr style={{ background: COLORS.bg }}>
                    {["", "Course Code", "Course Name", "Credits", "Semester", "Compulsory / Optional", "Status"].map((h, i) => (
                      <th key={i} style={{ padding: "11px 14px", textAlign: "left", color: COLORS.textSecondary, fontWeight: 600, fontSize: 12, textTransform: "uppercase" }}>{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {available.map(c => {
                    const sel = selected.includes(c.id);
                    const alreadyReg = alreadyRegisteredCodes.has(c.code);
                    return (
                      <tr key={c.id} style={{ borderBottom: `1px solid ${COLORS.border}`, opacity: alreadyReg ? 0.55 : 1 }}>
                        <td style={{ padding: "10px 14px" }}>
                          <input type="checkbox" checked={sel} disabled={!c.is_elective || alreadyReg} onChange={() => toggle(c)} style={{ accentColor: COLORS.primary, width: 16, height: 16 }} />
                        </td>
                        <td style={{ padding: "10px 14px", fontWeight: 700, color: COLORS.primary, fontSize: 13 }}>{c.code}</td>
                        <td style={{ padding: "10px 14px", color: COLORS.textPrimary }}>{c.name}</td>
                        <td style={{ padding: "10px 14px" }}>{c.credits}</td>
                        <td style={{ padding: "10px 14px" }}>Y{c.year}/S{c.semester}</td>
                        <td style={{ padding: "10px 14px" }}>
                          <span style={{ padding: "3px 10px", borderRadius: 20, fontSize: 12, fontWeight: 600, background: (c.is_elective ? COLORS.accentGold : COLORS.success) + "18", color: c.is_elective ? "#B45309" : COLORS.success }}>
                            {c.is_elective ? "Optional" : "Compulsory"}
                          </span>
                        </td>
                        <td style={{ padding: "10px 14px", fontSize: 12, color: alreadyReg ? COLORS.success : COLORS.textMuted, fontWeight: alreadyReg ? 700 : 400 }}>
                          {alreadyReg ? "Already Registered" : sel ? "Selected" : "—"}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            )}
          </SectionCard>
        </>
      )}

      {tab === "registered" && (
        <SectionCard title="My Registered Courses">
          {!regs ? (
            <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading…</div>
          ) : allRegisteredRows.length === 0 ? (
            <div style={{ color: COLORS.textMuted, fontSize: 14 }}>You haven't registered for any courses yet.</div>
          ) : (
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
              <thead>
                <tr style={{ background: COLORS.bg }}>
                  {["Course Code", "Course Name", "Credits", "Semester", "Compulsory / Optional"].map((h, i) => (
                    <th key={i} style={{ padding: "11px 14px", textAlign: "left", color: COLORS.textSecondary, fontWeight: 600, fontSize: 12, textTransform: "uppercase" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {allRegisteredRows.map((c, i) => {
                  const combo = user.batch ? user.batch.split(" ")[0] : null;
                  const isElective = combo ? (c.compulsory_for !== "ALL" && !(c.compulsory_for || "").split(",").includes(combo) && (c.elective_for || "").split(",").includes(combo)) : false;
                  return (
                    <tr key={i} style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                      <td style={{ padding: "10px 14px", fontWeight: 700, color: COLORS.primary, fontSize: 13 }}>{c.code}</td>
                      <td style={{ padding: "10px 14px" }}>{c.name}</td>
                      <td style={{ padding: "10px 14px" }}>{c.credits}</td>
                      <td style={{ padding: "10px 14px" }}>Y{c.regYear}/S{c.regSemester}</td>
                      <td style={{ padding: "10px 14px" }}>
                        <span style={{ padding: "3px 10px", borderRadius: 20, fontSize: 12, fontWeight: 600, background: (isElective ? COLORS.accentGold : COLORS.success) + "18", color: isElective ? "#B45309" : COLORS.success }}>
                          {isElective ? "Optional" : "Compulsory"}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </SectionCard>
      )}
    </div>
  );
};

const LOW_ATTENDANCE_THRESHOLD = 80; // %

const StudentAttendance = () => {
  const [records, setRecords] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api.myAttendance().then(setRecords).catch(err => setError(err.message));
  }, []);

  if (error) return <div style={{ color: COLORS.danger, fontSize: 14 }}>{error}</div>;
  if (!records) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading attendance…</div>;

  const total = records.length;
  const present = records.filter(r => r.status === "present").length;
  const overallPct = total ? Math.round((present / total) * 100) : null;

  const byModule = {};
  records.forEach(r => {
    const key = r.code;
    if (!byModule[key]) byModule[key] = { name: r.course_name, present: 0, absent: 0, late: 0, total: 0 };
    byModule[key].total++;
    if (r.status === "present") byModule[key].present++;
    else if (r.status === "absent") byModule[key].absent++;
    else if (r.status === "late") byModule[key].late++;
  });

  const moduleRows = Object.entries(byModule).map(([code, m]) => ({
    code, ...m, pct: m.total ? Math.round((m.present / m.total) * 100) : 0,
  }));
  const lowAttendanceModules = moduleRows.filter(m => m.pct < LOW_ATTENDANCE_THRESHOLD);

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>My Attendance</h2>
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 24 }}>
        <StatCard label="Overall Attendance" value={overallPct === null ? "N/A" : `${overallPct}%`} icon="check" color={COLORS.success} />
        <StatCard label="Present Days" value={String(present)} icon="attendance" color={COLORS.accent} />
        <StatCard label="Absent Days" value={String(total - present)} icon="overview" color={COLORS.danger} />
      </div>

      {lowAttendanceModules.length > 0 && (
        <div style={{ background: COLORS.danger + "10", border: `1px solid ${COLORS.danger}30`, borderRadius: 12, padding: "14px 18px", marginBottom: 24, display: "flex", alignItems: "flex-start", gap: 12 }}>
          <Icon name="alert" size={18} color={COLORS.danger} />
          <div>
            <div style={{ fontWeight: 700, fontSize: 14, color: COLORS.danger, marginBottom: 4 }}>Low Attendance Warning</div>
            <div style={{ fontSize: 13, color: COLORS.textSecondary, lineHeight: 1.5 }}>
              Your attendance is below {LOW_ATTENDANCE_THRESHOLD}% in {lowAttendanceModules.length} module{lowAttendanceModules.length !== 1 ? "s" : ""}: {" "}
              <strong>{lowAttendanceModules.map(m => `${m.code} (${m.pct}%)`).join(", ")}</strong>. You may not be eligible to sit the end-of-semester exam for {lowAttendanceModules.length !== 1 ? "these modules" : "this module"} unless this improves.
            </div>
          </div>
        </div>
      )}

      <SectionCard title="Attendance by Course">
        {moduleRows.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No attendance records yet.</div> : (
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
            <thead>
              <tr style={{ background: COLORS.bg }}>
                {["Course", "Present Days", "Absent Days", "Attendance %", ""].map((h, i) => (
                  <th key={i} style={{ padding: "11px 14px", textAlign: "left", color: COLORS.textSecondary, fontWeight: 600, fontSize: 12, textTransform: "uppercase" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {moduleRows.map((m) => (
                <tr key={m.code} style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                  <td style={{ padding: "12px 14px" }}>
                    <div style={{ fontWeight: 700, color: COLORS.primary, fontSize: 13 }}>{m.code}</div>
                    <div style={{ fontSize: 13, color: COLORS.textPrimary }}>{m.name}</div>
                  </td>
                  <td style={{ padding: "12px 14px", fontWeight: 700, color: COLORS.success }}>{m.present}</td>
                  <td style={{ padding: "12px 14px", fontWeight: 700, color: COLORS.danger }}>{m.absent}</td>
                  <td style={{ padding: "12px 14px" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      <div style={{ flex: 1, maxWidth: 100, height: 7, background: COLORS.border, borderRadius: 99 }}>
                        <div style={{ width: `${m.pct}%`, height: "100%", borderRadius: 99, background: m.pct >= 85 ? COLORS.success : m.pct >= LOW_ATTENDANCE_THRESHOLD ? COLORS.accentGold : COLORS.danger }} />
                      </div>
                      <span style={{ fontWeight: 700, fontSize: 13, color: m.pct >= LOW_ATTENDANCE_THRESHOLD ? COLORS.textPrimary : COLORS.danger }}>{m.pct}%</span>
                    </div>
                  </td>
                  <td style={{ padding: "12px 14px" }}>
                    {m.pct < LOW_ATTENDANCE_THRESHOLD ? (
                      <span style={{ display: "inline-flex", alignItems: "center", gap: 5, padding: "3px 10px", borderRadius: 20, fontSize: 11, fontWeight: 700, background: COLORS.danger + "18", color: COLORS.danger }}>
                        <Icon name="alert" size={11} color={COLORS.danger} /> Low
                      </span>
                    ) : (
                      <span style={{ padding: "3px 10px", borderRadius: 20, fontSize: 11, fontWeight: 700, background: COLORS.success + "18", color: COLORS.success }}>Good</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </SectionCard>

      <SectionCard title="Recent Attendance Records">
        {total === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No records yet.</div> : (
          <Table
            headers={["Date", "Module", "Status"]}
            rows={records.slice(0, 15).map(r => [new Date(r.session_date).toLocaleDateString(), `${r.code} — ${r.course_name}`, r.status.charAt(0).toUpperCase() + r.status.slice(1)])}
            badge
          />
        )}
      </SectionCard>
    </div>
  );
};

const GRADE_POINTS = { "A+": 4.0, "A": 4.0, "A-": 3.7, "B+": 3.3, "B": 3.0, "B-": 2.7, "C+": 2.3, "C": 2.0, "C-": 1.7, "D": 1.0, "F": 0.0 };

const StudentResults = () => {
  const [results, setResults] = useState(null);
  const [error, setError] = useState("");
  const [downloading, setDownloading] = useState(false);
  const [filterYear, setFilterYear] = useState("");
  const [filterSemester, setFilterSemester] = useState("");
  const [filterCode, setFilterCode] = useState("");

  useEffect(() => {
    api.myResults().then(setResults).catch(err => setError(err.message));
  }, []);

  // Reset dependent filters when a broader one changes, so stale combinations
  // (e.g. a subject that doesn't exist in the newly-picked semester) can't linger.
  const onYearChange = (v) => { setFilterYear(v); setFilterSemester(""); setFilterCode(""); };
  const onSemesterChange = (v) => { setFilterSemester(v); setFilterCode(""); };

  const downloadResults = async () => {
    setDownloading(true);
    setError("");
    try {
      await api.downloadMyResults({ year: filterYear, semester: filterSemester, code: filterCode });
    } catch (err) {
      if (err.message.startsWith("Can't reach the server") && results) {
        // Offline demo mode — generate the file client-side instead, applying the same filters.
        const filtered = results.filter(r =>
          (!filterYear || String(r.year) === String(filterYear)) &&
          (!filterSemester || String(r.semester) === String(filterSemester)) &&
          (!filterCode || r.code === filterCode)
        );
        if (!filtered.length) { setError("No results found for the selected filters."); return; }
        const sheet = XLSX.utils.json_to_sheet(filtered.map(r => ({
          "Module Code": r.code, "Module Name": r.course_name, "Year": r.year, "Semester": r.semester,
          "Marks": r.marks ?? "", "Grade": r.grade || "",
        })));
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, sheet, "My Results");
        const nameParts = ["my-results"];
        if (filterYear) nameParts.push(`Y${filterYear}`);
        if (filterSemester) nameParts.push(`S${filterSemester}`);
        if (filterCode) nameParts.push(filterCode.replace(/\s+/g, ""));
        XLSX.writeFile(workbook, `${nameParts.join("-")}.xlsx`);
      } else {
        setError(err.message);
      }
    } finally {
      setDownloading(false);
    }
  };

  if (error && !results) return <div style={{ color: COLORS.danger, fontSize: 14 }}>{error}</div>;
  if (!results) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading results…</div>;

  // Options for the download filters — cascading: semesters depend on the chosen
  // year, subjects depend on the chosen year + semester.
  const yearOptions = [...new Set(results.map(r => r.year))].sort((a, b) => a - b);
  const semesterOptions = [...new Set(
    results.filter(r => !filterYear || String(r.year) === String(filterYear)).map(r => r.semester)
  )].sort((a, b) => a - b);
  const subjectOptions = results
    .filter(r =>
      (!filterYear || String(r.year) === String(filterYear)) &&
      (!filterSemester || String(r.semester) === String(filterSemester))
    )
    .reduce((acc, r) => (acc.some(s => s.code === r.code) ? acc : [...acc, { code: r.code, name: r.course_name }]), [])
    .sort((a, b) => a.code.localeCompare(b.code));

  const selectStyle = { width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, background: "#fff" };

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>My Results</h2>

      {results.length === 0 ? (
        <SectionCard title="My Results">
          <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No results published yet.</div>
        </SectionCard>
      ) : (
        <SectionCard title="Download Result Sheet" action={downloading ? "Downloading…" : "Download as Excel"} onAction={downloading ? undefined : downloadResults}>
          <p style={{ fontSize: 13, color: COLORS.textMuted, marginTop: 0, marginBottom: 16 }}>
            Choose a Year, Semester and Subject to download that result sheet as an Excel file — or leave a filter on "All" to include everything.
          </p>
          <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
            <div style={{ flex: "1 1 160px", minWidth: 160 }}>
              <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Year</label>
              <select value={filterYear} onChange={e => onYearChange(e.target.value)} style={selectStyle}>
                <option value="">All Years</option>
                {yearOptions.map(y => <option key={y} value={y}>Year {y}</option>)}
              </select>
            </div>
            <div style={{ flex: "1 1 160px", minWidth: 160 }}>
              <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Semester</label>
              <select value={filterSemester} onChange={e => onSemesterChange(e.target.value)} style={selectStyle}>
                <option value="">All Semesters</option>
                {semesterOptions.map(s => <option key={s} value={s}>Semester {s}</option>)}
              </select>
            </div>
            <div style={{ flex: "2 1 240px", minWidth: 200 }}>
              <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Subject</label>
              <select value={filterCode} onChange={e => setFilterCode(e.target.value)} style={selectStyle}>
                <option value="">All Subjects</option>
                {subjectOptions.map(s => <option key={s.code} value={s.code}>{s.code} — {s.name}</option>)}
              </select>
            </div>
          </div>
          {error && <div style={{ color: COLORS.danger, fontSize: 13, marginTop: 12 }}>{error}</div>}
        </SectionCard>
      )}
    </div>
  );
};

const ASSIGNMENT_STATUS_LABELS = {
  submitted: { label: "Submitted", color: "success" },
  submitted_late: { label: "Submitted Late", color: "warning" },
  pending: { label: "Pending", color: "textMuted" },
};

const StudentAssignments = () => {
  const [assignments, setAssignments] = useState(null);
  const [error, setError] = useState("");
  const [submittingId, setSubmittingId] = useState(null);
  const [fileByAssignment, setFileByAssignment] = useState({});

  const load = () => api.myAssignments().then(setAssignments).catch(err => setError(err.message));
  useEffect(() => { load(); }, []);

  const handleSubmit = async (id) => {
    const file = fileByAssignment[id];
    setSubmittingId(id);
    try {
      const form = new FormData();
      if (file) form.append("file", file);
      await api.submitAssignment(id, form);
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmittingId(null);
    }
  };

  if (error) return <div style={{ color: COLORS.danger, fontSize: 14 }}>{error}</div>;
  if (!assignments) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading assignments…</div>;

  const pendingCount = assignments.filter(a => a.status === "pending").length;
  const submittedCount = assignments.filter(a => a.status === "submitted" || a.status === "submitted_late").length;

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>Assignments</h2>
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 24 }}>
        <StatCard label="Pending" value={String(pendingCount)} icon="report" color={COLORS.warning} />
        <StatCard label="Submitted" value={String(submittedCount)} icon="check" color={COLORS.success} />
      </div>

      {assignments.length === 0 ? (
        <SectionCard title="Assignments">
          <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No assignments posted for your registered courses yet.</div>
        </SectionCard>
      ) : (
        assignments.map((a) => {
          const statusInfo = ASSIGNMENT_STATUS_LABELS[a.status];
          const statusColor = COLORS[statusInfo.color] || COLORS.textMuted;
          const canSubmit = a.status === "pending";
          const isPastDeadline = new Date() > new Date(a.deadline);
          return (
            <SectionCard key={a.id} title="">
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 16, flexWrap: "wrap" }}>
                <div style={{ flex: 1, minWidth: 260 }}>
                  <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 6, flexWrap: "wrap" }}>
                    <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: COLORS.textPrimary }}>{a.title}</h3>
                    <span style={{ padding: "3px 10px", borderRadius: 20, fontSize: 11, fontWeight: 700, background: statusColor + "18", color: statusColor }}>{statusInfo.label}</span>
                  </div>
                  <div style={{ fontSize: 13, color: COLORS.primary, fontWeight: 600, marginBottom: 8 }}>{a.code} — {a.course_name}</div>
                  {a.description && <p style={{ fontSize: 13, color: COLORS.textSecondary, lineHeight: 1.6, margin: "0 0 10px" }}>{a.description}</p>}
                  <div style={{ fontSize: 12, color: canSubmit && isPastDeadline ? COLORS.danger : COLORS.textMuted, display: "flex", alignItems: "center", gap: 6 }}>
                    <Icon name="attendance" size={13} color={canSubmit && isPastDeadline ? COLORS.danger : COLORS.textMuted} />
                    Deadline: {new Date(a.deadline).toLocaleString(undefined, { year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" })}
                    {canSubmit && isPastDeadline ? " (past deadline — late submissions may still be accepted)" : ""}
                  </div>
                </div>
                {canSubmit && (
                  <div style={{ display: "flex", flexDirection: "column", gap: 8, minWidth: 220 }}>
                    <label style={{ display: "inline-flex", alignItems: "center", gap: 8, background: "#fff", color: COLORS.primary, border: `1.5px solid ${COLORS.primary}`, borderRadius: 8, padding: "8px 14px", fontWeight: 700, fontSize: 12.5, cursor: "pointer" }}>
                      <Icon name="report" size={14} color={COLORS.primary} />
                      {fileByAssignment[a.id] ? fileByAssignment[a.id].name.slice(0, 22) : "Choose File"}
                      <input type="file" style={{ display: "none" }} onChange={e => setFileByAssignment(f => ({ ...f, [a.id]: e.target.files[0] }))} />
                    </label>
                    <button onClick={() => handleSubmit(a.id)} disabled={submittingId === a.id}
                      style={{ background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.accent})`, color: "#fff", border: "none", borderRadius: 8, padding: "9px 14px", fontWeight: 700, fontSize: 12.5, cursor: submittingId === a.id ? "default" : "pointer", opacity: submittingId === a.id ? 0.7 : 1 }}>
                      {submittingId === a.id ? "Submitting…" : "Submit Assignment"}
                    </button>
                  </div>
                )}
              </div>
            </SectionCard>
          );
        })
      )}
    </div>
  );
};

const StudentExamTimetable = () => {
  const [entries, setEntries] = useState(null);
  const [documents, setDocuments] = useState(null);
  const [error, setError] = useState("");
  const [filterYear, setFilterYear] = useState("");
  const [filterSemester, setFilterSemester] = useState("");
  const [loadingDoc, setLoadingDoc] = useState(false);
  const [docError, setDocError] = useState("");

  useEffect(() => {
    api.myExamTimetable().then(setEntries).catch(err => setError(err.message));
  }, []);

  const onYearChange = (v) => { setFilterYear(v); setFilterSemester(""); setDocuments(null); setDocError(""); };
  const onSemesterChange = (v) => { setFilterSemester(v); setDocuments(null); setDocError(""); };

  if (error) return <div style={{ color: COLORS.danger, fontSize: 14 }}>{error}</div>;
  if (!entries) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading exam timetable…</div>;

  const fmtTime = (t) => {
    if (!t) return "—";
    const [h, m] = t.split(":");
    const hour = parseInt(h, 10);
    const ampm = hour >= 12 ? "PM" : "AM";
    const hr12 = hour % 12 === 0 ? 12 : hour % 12;
    return `${hr12}:${m} ${ampm}`;
  };

  const today = new Date(); today.setHours(0, 0, 0, 0);
  const upcoming = entries.filter(e => new Date(e.exam_date) >= today);
  const nextExam = upcoming[0];

  const filteredEntries = entries.filter(e =>
    (!filterYear || String(e.year) === String(filterYear)) &&
    (!filterSemester || String(e.semester) === String(filterSemester))
  );

  const findDocuments = async () => {
    setLoadingDoc(true);
    setDocError("");
    try {
      const docs = await api.examTimetableDocuments(filterYear, filterSemester);
      setDocuments(docs);
      if (!docs || docs.length === 0) setDocError("No exam timetable PDF has been published for that Year / Semester yet.");
    } catch (err) {
      setDocError(err.message);
    } finally {
      setLoadingDoc(false);
    }
  };

  const selectStyle = { width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, background: "#fff" };

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>Exam Timetable</h2>

      {nextExam && (
        <div style={{ background: COLORS.primary + "08", border: `1px solid ${COLORS.primary}25`, borderRadius: 12, padding: "14px 18px", marginBottom: 24, display: "flex", alignItems: "center", gap: 12 }}>
          <Icon name="attendance" size={18} color={COLORS.primary} />
          <div style={{ fontSize: 13, color: COLORS.textSecondary }}>
            <strong style={{ color: COLORS.primary }}>Next Exam:</strong> {nextExam.code} — {nextExam.course_name} on {new Date(nextExam.exam_date).toLocaleDateString(undefined, { weekday: "long", year: "numeric", month: "long", day: "numeric" })} at {fmtTime(nextExam.start_time)}{nextExam.venue ? ` · ${nextExam.venue}` : ""}
          </div>
        </div>
      )}

      <SectionCard title="Download Exam Timetable (PDF)" action={loadingDoc ? "Searching…" : "Find PDF"} onAction={loadingDoc ? undefined : findDocuments}>
        <p style={{ fontSize: 13, color: COLORS.textMuted, marginTop: 0, marginBottom: 16 }}>
          Choose a Year and Semester to find and download the published exam timetable PDF for that semester.
        </p>
        <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
          <div style={{ flex: "1 1 220px", minWidth: 200 }}>
            <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Year</label>
            <select value={filterYear} onChange={e => onYearChange(e.target.value)} style={selectStyle}>
              <option value="">Select Year</option>
              <option value="1">Year 1</option>
              <option value="2">Year 2</option>
              <option value="3">Year 3</option>
              <option value="4">Year 4</option>
            </select>
          </div>
          <div style={{ flex: "1 1 220px", minWidth: 200 }}>
            <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Semester</label>
            <select value={filterSemester} onChange={e => onSemesterChange(e.target.value)} style={selectStyle} disabled={!filterYear}>
              <option value="">Select Semester</option>
              <option value="1">Semester I</option>
              <option value="2">Semester II</option>
            </select>
          </div>
        </div>
        {docError && <div style={{ color: COLORS.danger, fontSize: 13, marginTop: 12 }}>{docError}</div>}
        {documents && documents.length > 0 && (
          <div style={{ marginTop: 16 }}>
            {documents.map(d => (
              <a key={d.id} href={fileUrl(d.file_path)} target="_blank" rel="noreferrer" download={d.original_name}
                style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "12px 14px", background: COLORS.bg, borderRadius: 8, marginBottom: 8, textDecoration: "none" }}>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 14, color: COLORS.textPrimary }}>{d.title}</div>
                  <div style={{ fontSize: 12, color: COLORS.textMuted }}>Year {d.year} · Semester {d.semester} · Uploaded {new Date(d.uploaded_at).toLocaleDateString()}</div>
                </div>
                <span style={{ background: COLORS.primary + "18", color: COLORS.primary, borderRadius: 6, padding: "6px 12px", fontSize: 12, fontWeight: 600 }}>Download PDF</span>
              </a>
            ))}
          </div>
        )}
      </SectionCard>

      <SectionCard title="Exam Schedule">
        {filteredEntries.length === 0 ? (
          <div style={{ color: COLORS.textMuted, fontSize: 14 }}>
            {entries.length === 0 ? "No exam dates have been published for your registered courses yet." : "No exam dates match the selected filters."}
          </div>
        ) : (
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
            <thead>
              <tr style={{ background: COLORS.bg }}>
                {["Subject", "Date", "Time", "Venue"].map((h, i) => (
                  <th key={i} style={{ padding: "11px 14px", textAlign: "left", color: COLORS.textSecondary, fontWeight: 600, fontSize: 12, textTransform: "uppercase" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filteredEntries.map((e) => {
                const isPast = new Date(e.exam_date) < today;
                return (
                  <tr key={e.id} style={{ borderBottom: `1px solid ${COLORS.border}`, opacity: isPast ? 0.5 : 1 }}>
                    <td style={{ padding: "12px 14px" }}>
                      <div style={{ fontWeight: 700, color: COLORS.primary, fontSize: 13 }}>{e.code}</div>
                      <div style={{ fontSize: 13, color: COLORS.textPrimary }}>{e.course_name}</div>
                    </td>
                    <td style={{ padding: "12px 14px" }}>{new Date(e.exam_date).toLocaleDateString(undefined, { weekday: "short", year: "numeric", month: "short", day: "numeric" })}</td>
                    <td style={{ padding: "12px 14px" }}>{fmtTime(e.start_time)}{e.end_time ? ` – ${fmtTime(e.end_time)}` : ""}</td>
                    <td style={{ padding: "12px 14px" }}>{e.venue || "—"}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </SectionCard>
    </div>
  );
};

// ─── COURSE DATA (from FAS handbook) ─────────────────────────────────────────
// ─── CURRENT STUDENT (mock stand-in for GET /api/auth/me until Stage 2 wiring) ─
// Matches the student shown on the Dashboard — swap for the real API response
// once the frontend is wired to the backend (see README "Stage 2").
const CURRENT_STUDENT = {
  name: "M.D. K. Ridmi",
  indexNo: "21APP5710",
  degree: "B.Sc. Physical Sciences",
  batch: "C3",
  combination: "C3 — Computer Science & Technology",
  currentYear: 4,
  currentSemester: 1,
  registeredSubjects: 11,
};

// ─── REGISTRATION FEES (mock stand-in for GET /api/settings) ──────────────────
// These are admin-managed — see Admin Portal → System Settings → Registration
// Fees, and the backend's /api/settings endpoint (system_settings table).
const REGISTRATION_SETTINGS = {
  fee: 300, // flat one-time semester registration fee, NOT per subject
  lateFee: 500,
  deadline: "15 July 2025",
};

const EXAM_TYPES = [
  {
    id: "normal",
    label: "Proper Examination",
    icon: "report",
    desc: "Regular end-of-semester examination for currently enrolled subjects",
    color: "#1E3A5F",
    fee: null,
    feeLabel: "No payment required",
  },
  {
    id: "medical",
    label: "Medical / Aegrotat Examination",
    icon: "medical",
    desc: "For students who missed the normal exam due to a verified medical condition",
    color: "#2D9B6F",
    fee: 25,
    feeLabel: "",
  },
  {
    id: "repeat",
    label: "Repeat Examination",
    icon: "repeat",
    desc: "For students who failed or wish to improve a grade in a previous semester",
    color: "#E63946",
    fee: 25,
    feeLabel: "",
  },
];

const StudentExamApp = () => {
  const [step, setStep] = useState(1);           // 1=type, 2=details, 3=subjects, 4=payment/confirm, 5=success
  const [examType, setExamType] = useState(null);
  const [year, setYear] = useState("");
  const [semester, setSemester] = useState("");
  const [selectedSubjects, setSelectedSubjects] = useState([]);
  const [medDoc, setMedDoc] = useState(null);
  const [medDocName, setMedDocName] = useState("");
  const [cardData, setCardData] = useState({ number: "", name: "", expiry: "", cvv: "" });
  const [paySlip, setPaySlip] = useState(null);
  const [paySlipName, setPaySlipName] = useState("");
  const [payMethod, setPayMethod] = useState("card");

  const [liveCourses, setLiveCourses] = useState([]);
  const [combination, setCombination] = useState("");
  useEffect(() => {
    api.me().then(u => { if (u.batch && !combination) setCombination(u.batch); }).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const needsCombination = year === "3" || year === "4";
  useEffect(() => {
    if (!year || !semester) { setLiveCourses([]); return; }
    if (needsCombination && !combination) { setLiveCourses([]); return; }
    api.courses(year, semester, combination || null)
      .then(rows => setLiveCourses(rows.map(c => ({ id: c.id, code: c.code, name: c.name, cre: c.credits }))))
      .catch(() => setLiveCourses([]));
  }, [year, semester, combination, needsCombination]);

  // Proper Examination is only for subjects the student is already enrolled
  // in — pull those from their confirmed Semester Registration instead of
  // the full course catalogue. Medical / Repeat exams can be for any past
  // subject, so those keep using the full catalogue (liveCourses) below.
  const [semRegs, setSemRegs] = useState([]);
  useEffect(() => { api.mySemRegs().then(setSemRegs).catch(() => setSemRegs([])); }, []);
  const myRegistration = semRegs.find(r =>
    String(r.year) === String(year) && String(r.semester) === String(semester) && r.status === "confirmed"
  );
  const registeredCourses = myRegistration
    ? (myRegistration.courses || []).map(c => ({ id: c.id, code: c.code, name: c.name, cre: c.credits }))
    : [];

  const courses = examType === "normal" ? registeredCourses : liveCourses;
  const typeObj = EXAM_TYPES.find(t => t.id === examType);
  const needsPayment = examType === "medical" || examType === "repeat";
  const feePerSubject = typeObj?.fee || 0;
  const totalFee = selectedSubjects.length * feePerSubject;

  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState("");
  const [myApps, setMyApps] = useState(null);
  const loadMyApps = () => api.myExamApps().then(setMyApps).catch(() => setMyApps([]));
  useEffect(() => { loadMyApps(); }, []);

  const submitApplication = async () => {
    setSubmitError("");
    setSubmitting(true);
    try {
      const selectedCourseIds = courses.filter(c => selectedSubjects.includes(c.code)).map(c => c.id);
      const form = new FormData();
      form.append("examType", examType);
      form.append("year", year);
      form.append("semester", semester);
      form.append("courseIds", JSON.stringify(selectedCourseIds));
      if (examType === "medical" && medDoc) form.append("medicalDoc", medDoc);
      const created = await api.createExamApp(form);

      // Medical / Repeat applications carry a fee — record the payment
      // (card or bank slip) against the application we just created.
      if (needsPayment && created && created.id) {
        const purpose = examType === "medical" ? "medical_exam" : "repeat_exam";
        if (payMethod === "slip") {
          const payForm = new FormData();
          payForm.append("purpose", purpose);
          payForm.append("referenceId", created.id);
          payForm.append("amount", totalFee);
          payForm.append("method", "bank_slip");
          if (paySlip) payForm.append("slip", paySlip);
          await api.createPayment(payForm, true);
        } else {
          await api.createPayment({ purpose, referenceId: created.id, amount: totalFee, method: "card" });
        }
      }

      loadMyApps();
      setStep(5);
    } catch (err) {
      setSubmitError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const fmtCard = (v) => v.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim();
  const fmtExpiry = (v) => { const d = v.replace(/\D/g, "").slice(0, 4); return d.length >= 3 ? d.slice(0, 2) + "/" + d.slice(2) : d; };

  const toggleSubject = (code) => setSelectedSubjects(prev =>
    prev.includes(code) ? prev.filter(c => c !== code) : [...prev, code]
  );

  const iStyle = { width: "100%", padding: "11px 14px", borderRadius: 10, border: `1.5px solid ${COLORS.border}`, fontSize: 14, outline: "none", boxSizing: "border-box", fontFamily: "inherit" };
  const lStyle = { display: "block", fontSize: 12, fontWeight: 700, color: COLORS.textSecondary, marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.04em" };

  // ── Step tracker ──
  const steps = ["Exam Type", "Details", "Subjects", needsPayment ? "Payment" : "Confirm"];
  const StepBar = () => (
    <div style={{ display: "flex", alignItems: "center", marginBottom: 28 }}>
      {steps.map((s, i) => {
        const num = i + 1;
        const active = step === num;
        const done = step > num;
        return (
          <div key={i} style={{ display: "flex", alignItems: "center", flex: i < steps.length - 1 ? 1 : "none" }}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
              <div style={{ width: 32, height: 32, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 13, background: done ? COLORS.success : active ? COLORS.primary : COLORS.border, color: done || active ? "#fff" : COLORS.textMuted, transition: "all 0.3s" }}>
                {done ? "✓" : num}
              </div>
              <div style={{ fontSize: 11, fontWeight: active ? 700 : 500, color: active ? COLORS.primary : done ? COLORS.success : COLORS.textMuted, whiteSpace: "nowrap" }}>{s}</div>
            </div>
            {i < steps.length - 1 && <div style={{ flex: 1, height: 2, background: done ? COLORS.success : COLORS.border, margin: "0 8px", marginBottom: 18, transition: "background 0.3s" }} />}
          </div>
        );
      })}
    </div>
  );

  // ── SUCCESS ──
  if (step === 5) return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>Exam Application</h2>
      <div style={{ background: COLORS.card, borderRadius: 20, padding: 48, textAlign: "center", boxShadow: "0 2px 24px rgba(30,58,95,0.10)" }}>
        <div style={{ width: 72, height: 72, borderRadius: "50%", background: COLORS.success + "18", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px" }}>
          <Icon name="check" size={36} color={COLORS.success} />
        </div>
        <h3 style={{ fontSize: 22, fontWeight: 800, color: COLORS.textPrimary, margin: "0 0 10px" }}>Application Submitted!</h3>
        <p style={{ color: COLORS.textMuted, fontSize: 14, marginBottom: 20 }}>
          Your <strong>{typeObj?.label}</strong> application for <strong>Year {year} Semester {semester}</strong> has been received.
        </p>
        <div style={{ background: COLORS.bg, borderRadius: 12, padding: "16px 24px", display: "inline-block", marginBottom: 28, textAlign: "left", minWidth: 280 }}>
          <div style={{ fontSize: 12, color: COLORS.textMuted, marginBottom: 4 }}>Application Reference</div>
          <div style={{ fontSize: 16, fontWeight: 700, color: COLORS.primary, letterSpacing: "0.05em" }}>EXA-{Date.now().toString().slice(-8)}</div>
          <div style={{ fontSize: 12, color: COLORS.textMuted, marginTop: 8 }}>Subjects: {selectedSubjects.length}</div>
          {}
        </div>
        <br />
        <button onClick={() => { setStep(1); setExamType(null); setYear(""); setSemester(""); setSelectedSubjects([]); setMedDoc(null); setPaySlip(null); setCardData({ number: "", name: "", expiry: "", cvv: "" }); }}
          style={{ background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.primaryLight})`, color: "#fff", border: "none", borderRadius: 12, padding: "12px 36px", fontWeight: 700, fontSize: 15, cursor: "pointer" }}>
          New Application
        </button>
      </div>
      <div style={{ marginTop: 24 }}>
        <SectionCard title="Application History">
          <Table headers={["Ref", "Exam Period", "Type", "Subjects", "Fee", "Status"]}
            rows={[
              ["EXA-" + Date.now().toString().slice(-8), `Y${year} Sem ${semester}`, typeObj?.label || "", `${selectedSubjects.length}`, needsPayment ? `LKR ${totalFee.toLocaleString()}` : "Free", "Active"],
              ["EXA-20241215", "Sem 2, 2023/24", "Proper Examination", "5", "Free", "Completed"],
              ["EXA-20240620", "Sem 1, 2023/24", "Proper Examination", "6", "Free", "Completed"],
            ]}
            badge />
        </SectionCard>
      </div>
    </div>
  );

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 8 }}>Exam Application</h2>
      <p style={{ color: COLORS.textMuted, marginBottom: 24, fontSize: 14 }}>Academic Year 2024/25 · Applications close 30 June 2025</p>

      <div style={{ background: COLORS.card, borderRadius: 16, padding: "28px 28px 24px", boxShadow: "0 2px 12px rgba(30,58,95,0.08)", marginBottom: 24 }}>
        <StepBar />

        {/* ── STEP 1 — Exam Type ── */}
        {step === 1 && (
          <div>
            <h3 style={{ fontSize: 17, fontWeight: 700, color: COLORS.textPrimary, margin: "0 0 6px" }}>Select Examination Type</h3>
            <p style={{ fontSize: 13, color: COLORS.textMuted, marginBottom: 20 }}>Choose the type of examination you are applying for.</p>
            <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
              {EXAM_TYPES.map((t) => (
                <div key={t.id} onClick={() => setExamType(t.id)}
                  style={{ display: "flex", alignItems: "center", gap: 16, padding: "18px 20px", borderRadius: 14, border: `2px solid ${examType === t.id ? t.color : COLORS.border}`, background: examType === t.id ? t.color + "08" : "#fff", cursor: "pointer", transition: "all 0.2s" }}>
                  <div style={{ width: 44, height: 44, borderRadius: 12, background: t.color + "15", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Icon name={t.icon} size={22} color={t.color} /></div>
                  <div style={{ flex: 1 }}>
                    <div style={{ fontWeight: 700, fontSize: 15, color: examType === t.id ? t.color : COLORS.textPrimary }}>{t.label}</div>
                    <div style={{ fontSize: 13, color: COLORS.textMuted, marginTop: 3 }}>{t.desc}</div>
                  </div>
                  <div style={{ textAlign: "right", flexShrink: 0 }}>
                    {t.fee
                      ? <span style={{ fontSize: 12, fontWeight: 700, padding: "4px 10px", borderRadius: 20, background: t.color + "18", color: t.color }}>{t.feeLabel}</span>
                      : <span style={{ fontSize: 12, fontWeight: 700, padding: "4px 10px", borderRadius: 20, background: COLORS.success + "18", color: COLORS.success }}>{t.feeLabel}</span>}
                  </div>
                  {examType === t.id && (
                    <div style={{ width: 22, height: 22, borderRadius: "50%", background: t.color, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                      <Icon name="check" size={13} color="#fff" />
                    </div>
                  )}
                </div>
              ))}
            </div>
            <div style={{ marginTop: 24, display: "flex", justifyContent: "flex-end" }}>
              <button onClick={() => examType && setStep(2)} style={{ background: examType ? `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.primaryLight})` : COLORS.border, color: examType ? "#fff" : COLORS.textMuted, border: "none", borderRadius: 12, padding: "12px 32px", fontWeight: 700, fontSize: 14, cursor: examType ? "pointer" : "not-allowed" }}>
                Next: Details →
              </button>
            </div>
          </div>
        )}

        {/* ── STEP 2 — Year & Semester Details ── */}
        {step === 2 && (
          <div>
            <h3 style={{ fontSize: 17, fontWeight: 700, color: COLORS.textPrimary, margin: "0 0 6px" }}>Academic Details</h3>
            <p style={{ fontSize: 13, color: COLORS.textMuted, marginBottom: 20 }}>Select the academic year and semester for this application.</p>

            {/* Exam type badge */}
            <div style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "8px 14px", borderRadius: 10, background: typeObj?.color + "12", border: `1px solid ${typeObj?.color}30`, marginBottom: 20 }}>
              <Icon name={typeObj?.icon} size={16} color={typeObj?.color} />
              <span style={{ fontSize: 13, fontWeight: 700, color: typeObj?.color }}>{typeObj?.label}</span>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: needsCombination ? "1fr 1fr 1fr" : "1fr 1fr", gap: 16, marginBottom: 16 }}>
              <div>
                <label style={lStyle}>Academic Year</label>
                <select value={year} onChange={e => { setYear(e.target.value); setSelectedSubjects([]); if (e.target.value !== "3" && e.target.value !== "4") setCombination(""); }} style={{ ...iStyle, cursor: "pointer" }}>
                  <option value="">Select Year</option>
                  <option value="1">Year 1</option>
                  <option value="2">Year 2</option>
                  <option value="3">Year 3</option>
                  <option value="4">Year 4</option>
                </select>
              </div>
              <div>
                <label style={lStyle}>Semester</label>
                <select value={semester} onChange={e => { setSemester(e.target.value); setSelectedSubjects([]); }} style={{ ...iStyle, cursor: "pointer" }}>
                  <option value="">Select Semester</option>
                  <option value="1">Semester I</option>
                  <option value="2">Semester II</option>
                </select>
              </div>
              {needsCombination && (
                <div>
                  <label style={lStyle}>Special Subject (Combination)</label>
                  <select value={combination} onChange={e => { setCombination(e.target.value); setSelectedSubjects([]); }} style={{ ...iStyle, cursor: "pointer" }}>
                    <option value="">Select Computer Science / Physics / Chemistry</option>
                    <option value="C1">C1 — Physics (Applied Physics)</option>
                    <option value="C2">C2 — Chemistry (Chemical Technology)</option>
                    <option value="C3">C3 — Computer Science</option>
                  </select>
                </div>
              )}
            </div>
            {needsCombination && !combination && (
              <div style={{ fontSize: 12.5, color: COLORS.warning, marginBottom: 16, display: "flex", alignItems: "center", gap: 6 }}>
                <Icon name="alert" size={13} color={COLORS.warning} /> Year 3 and 4 split into three special subjects — pick yours to see its modules.
              </div>
            )}

            {/* Medical: doc upload */}
            {examType === "medical" && (
              <div style={{ marginTop: 4 }}>
                <label style={lStyle}>Medical Certificate / Doctor's Letter</label>
                <label style={{ display: "block", border: `2px dashed ${medDoc ? COLORS.success : COLORS.border}`, borderRadius: 12, padding: "20px", textAlign: "center", cursor: "pointer", background: medDoc ? COLORS.success + "08" : COLORS.bg }}>
                  <input type="file" accept="image/*,.pdf" onChange={e => { const f = e.target.files[0]; if (f) { setMedDoc(f); setMedDocName(f.name); }}} style={{ display: "none" }} />
                  {medDoc
                    ? <div><div style={{ width: 32, height: 32, borderRadius: "50%", background: COLORS.success + "18", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto" }}><Icon name="check" size={16} color={COLORS.success} /></div><div style={{ fontWeight: 700, fontSize: 13, color: COLORS.success, marginTop: 6 }}>{medDocName}</div><div style={{ fontSize: 12, color: COLORS.textMuted }}>Click to change</div></div>
                    : <div><div style={{ display: "flex", justifyContent: "center", marginBottom: 4 }}><Icon name="medical" size={26} color={COLORS.textMuted} /></div><div style={{ fontWeight: 700, fontSize: 13, color: COLORS.textPrimary, marginTop: 6 }}>Upload Medical Certificate</div><div style={{ fontSize: 12, color: COLORS.textMuted }}>PDF, JPG or PNG · Max 5MB</div></div>}
                </label>
              </div>
            )}

            {/* Repeat: reason */}
            {examType === "repeat" && (
              <div style={{ marginTop: 4 }}>
                <label style={lStyle}>Reason for Repeat</label>
                <select style={{ ...iStyle, cursor: "pointer" }}>
                  <option>Failed the examination</option>
                  <option>Grade improvement</option>
                  <option>Absent without valid reason</option>
                </select>
              </div>
            )}

            <div style={{ marginTop: 24, display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <button onClick={() => setStep(1)} style={{ background: COLORS.bg, color: COLORS.textSecondary, border: `1px solid ${COLORS.border}`, borderRadius: 12, padding: "12px 24px", fontWeight: 700, fontSize: 14, cursor: "pointer" }}>← Back</button>
              <button onClick={() => (year && semester && (!needsCombination || combination)) && setStep(3)} style={{ background: (year && semester && (!needsCombination || combination)) ? `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.primaryLight})` : COLORS.border, color: (year && semester && (!needsCombination || combination)) ? "#fff" : COLORS.textMuted, border: "none", borderRadius: 12, padding: "12px 32px", fontWeight: 700, fontSize: 14, cursor: (year && semester && (!needsCombination || combination)) ? "pointer" : "not-allowed" }}>
                Next: Select Subjects →
              </button>
            </div>
          </div>
        )}

        {/* ── STEP 3 — Subject Selection ── */}
        {step === 3 && (
          <div>
            <h3 style={{ fontSize: 17, fontWeight: 700, color: COLORS.textPrimary, margin: "0 0 4px" }}>Select Subjects</h3>
            <p style={{ fontSize: 13, color: COLORS.textMuted, marginBottom: 4 }}>
              Year {year} · Semester {semester} · {courses.length} subjects available
              {needsPayment && <span style={{ marginLeft: 8, color: typeObj?.color, fontWeight: 600 }}>· {typeObj?.feeLabel}</span>}
            </p>
            <p style={{ fontSize: 12.5, color: COLORS.textMuted, marginBottom: 16 }}>
              {examType === "normal"
                ? "Showing only the subjects you're already registered for this semester."
                : "Showing every subject offered for this year & semester — pick any subject to sit for, regardless of your current registration."}
            </p>

            {courses.length === 0 ? (
              <div style={{ textAlign: "center", padding: "32px 0", color: COLORS.textMuted }}>
                {examType === "normal"
                  ? "You don't have a confirmed Semester Registration for this year & semester, so there are no subjects to apply for a Proper Examination in. Complete Course Registration first, or choose Medical / Repeat if this is for a past semester."
                  : "No courses found for this selection."}
              </div>
            ) : (
              <>
                <div style={{ display: "flex", gap: 10, marginBottom: 14 }}>
                  <button onClick={() => setSelectedSubjects(courses.map(c => c.code))} style={{ fontSize: 12, fontWeight: 700, padding: "6px 14px", borderRadius: 8, background: COLORS.primary + "10", color: COLORS.primary, border: "none", cursor: "pointer" }}>Select All</button>
                  <button onClick={() => setSelectedSubjects([])} style={{ fontSize: 12, fontWeight: 700, padding: "6px 14px", borderRadius: 8, background: COLORS.bg, color: COLORS.textSecondary, border: `1px solid ${COLORS.border}`, cursor: "pointer" }}>Clear All</button>
                  <span style={{ marginLeft: "auto", fontSize: 13, color: COLORS.textSecondary, alignSelf: "center" }}>
                    {selectedSubjects.length} selected
                  </span>
                </div>
                <div style={{ border: `1px solid ${COLORS.border}`, borderRadius: 12, overflow: "hidden" }}>
                  {courses.map((c, i) => {
                    const sel = selectedSubjects.includes(c.code);
                    return (
                      <div key={c.code} onClick={() => toggleSubject(c.code)}
                        style={{ display: "flex", alignItems: "center", gap: 14, padding: "13px 16px", borderBottom: i < courses.length - 1 ? `1px solid ${COLORS.border}` : "none", background: sel ? COLORS.primary + "06" : "#fff", cursor: "pointer", transition: "background 0.15s" }}>
                        <div style={{ width: 22, height: 22, borderRadius: 6, border: `2px solid ${sel ? COLORS.primary : COLORS.border}`, background: sel ? COLORS.primary : "#fff", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, transition: "all 0.15s" }}>
                          {sel && <Icon name="check" size={13} color="#fff" />}
                        </div>
                        <div style={{ flex: 1 }}>
                          <div style={{ fontWeight: 600, fontSize: 14, color: COLORS.textPrimary }}>{c.name}</div>
                          <div style={{ fontSize: 12, color: COLORS.textMuted, marginTop: 2 }}>{c.code} · {c.cre} Credit{c.cre !== 1 ? "s" : ""}</div>
                        </div>
                        
                      </div>
                    );
                  })}
                </div>

                
              </>
            )}

            <div style={{ marginTop: 24, display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <button onClick={() => setStep(2)} style={{ background: COLORS.bg, color: COLORS.textSecondary, border: `1px solid ${COLORS.border}`, borderRadius: 12, padding: "12px 24px", fontWeight: 700, fontSize: 14, cursor: "pointer" }}>← Back</button>
              <button onClick={() => selectedSubjects.length > 0 && setStep(4)} style={{ background: selectedSubjects.length > 0 ? `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.primaryLight})` : COLORS.border, color: selectedSubjects.length > 0 ? "#fff" : COLORS.textMuted, border: "none", borderRadius: 12, padding: "12px 32px", fontWeight: 700, fontSize: 14, cursor: selectedSubjects.length > 0 ? "pointer" : "not-allowed" }}>
                {needsPayment ? "Next: Payment →" : "Next: Confirm →"}
              </button>
            </div>
          </div>
        )}

        {/* ── STEP 4 — Payment (Medical/Repeat) OR Confirm (Normal) ── */}
        {step === 4 && !needsPayment && (
          <div>
            <h3 style={{ fontSize: 17, fontWeight: 700, color: COLORS.textPrimary, margin: "0 0 6px" }}>Confirm Application</h3>
            <p style={{ fontSize: 13, color: COLORS.textMuted, marginBottom: 20 }}>Please review your application before submitting.</p>
            <div style={{ background: COLORS.bg, borderRadius: 14, padding: 20, marginBottom: 20 }}>
              {[
                ["Exam Type", `${typeObj?.label}`],
                ["Year", `Year ${year}`],
                ["Semester", `Semester ${semester}`],
                ["Subjects Selected", `${selectedSubjects.length} subject${selectedSubjects.length !== 1 ? "s" : ""}`],
                ["Examination Fee", "Free — No payment required"],
              ].map(([k, v]) => (
                <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "9px 0", borderBottom: `1px solid ${COLORS.border}`, fontSize: 14 }}>
                  <span style={{ color: COLORS.textSecondary }}>{k}</span>
                  <span style={{ fontWeight: 700, color: COLORS.textPrimary }}>{v}</span>
                </div>
              ))}
            </div>
            <div style={{ border: `1px solid ${COLORS.border}`, borderRadius: 12, overflow: "hidden", marginBottom: 20 }}>
              {courses.filter(c => selectedSubjects.includes(c.code)).map((c, i, arr) => (
                <div key={c.code} style={{ display: "flex", justifyContent: "space-between", padding: "11px 16px", borderBottom: i < arr.length - 1 ? `1px solid ${COLORS.border}` : "none", fontSize: 13 }}>
                  <span style={{ color: COLORS.textPrimary, fontWeight: 500 }}>{c.name}</span>
                  <span style={{ color: COLORS.textMuted }}>{c.code}</span>
                </div>
              ))}
            </div>
            <div style={{ background: COLORS.success + "10", border: `1px solid ${COLORS.success}30`, borderRadius: 10, padding: "12px 16px", marginBottom: 20, fontSize: 13, color: COLORS.success }}>
              No payment is required for Proper Examinations. Your application will be reviewed within 2 working days.
            </div>
            {submitError && <div style={{ color: COLORS.danger, fontSize: 13, marginBottom: 10, fontWeight: 600 }}>{submitError}</div>}
            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <button onClick={() => setStep(3)} style={{ background: COLORS.bg, color: COLORS.textSecondary, border: `1px solid ${COLORS.border}`, borderRadius: 12, padding: "12px 24px", fontWeight: 700, fontSize: 14, cursor: "pointer" }}>← Back</button>
              <button onClick={submitApplication} disabled={submitting} style={{ background: `linear-gradient(135deg, ${COLORS.success}, #1e7e5a)`, color: "#fff", border: "none", borderRadius: 12, padding: "12px 32px", fontWeight: 700, fontSize: 14, cursor: submitting ? "default" : "pointer", opacity: submitting ? 0.7 : 1 }}>{submitting ? "Submitting…" : "✓ Submit Application"}</button>
            </div>
          </div>
        )}

        {step === 4 && needsPayment && (
          <div>
            <h3 style={{ fontSize: 17, fontWeight: 700, color: COLORS.textPrimary, margin: "0 0 4px" }}>Payment</h3>
            <p style={{ fontSize: 13, color: COLORS.textMuted, marginBottom: 16 }}>
              {typeObj?.label} · {selectedSubjects.length} subject{selectedSubjects.length !== 1 ? "s" : ""}
            </p>

            {/* Fee summary */}
            <div style={{ background: typeObj?.color + "10", border: `1px solid ${typeObj?.color}30`, borderRadius: 12, padding: "14px 18px", marginBottom: 20 }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13, marginBottom: 6 }}>
                <span style={{ color: COLORS.textSecondary }}>{selectedSubjects.length} subject{selectedSubjects.length !== 1 ? "s" : ""} × LKR {feePerSubject.toLocaleString()}</span>
                <span style={{ fontWeight: 700 }}>LKR {totalFee.toLocaleString()}</span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 16, fontWeight: 800, borderTop: `1px solid ${typeObj?.color}30`, paddingTop: 10 }}>
                <span style={{ color: COLORS.textPrimary }}>Total Due</span>
                <span style={{ color: typeObj?.color }}>LKR {totalFee.toLocaleString()}</span>
              </div>
            </div>

            {/* Payment method toggle */}
            <div style={{ display: "flex", gap: 10, marginBottom: 20 }}>
              {[{ id: "card", label: "Card Payment" }, { id: "slip", label: "Bank Slip" }].map(m => (
                <button key={m.id} onClick={() => setPayMethod(m.id)} style={{ flex: 1, padding: "11px", borderRadius: 10, border: `2px solid ${payMethod === m.id ? COLORS.primary : COLORS.border}`, background: payMethod === m.id ? COLORS.primary + "10" : "#fff", fontWeight: 700, fontSize: 13, color: payMethod === m.id ? COLORS.primary : COLORS.textSecondary, cursor: "pointer" }}>
                  {m.label}
                </button>
              ))}
            </div>

            {/* Card form */}
            {payMethod === "card" && (
              <div>
                <div style={{ marginBottom: 14 }}>
                  <label style={lStyle}>Card Number</label>
                  <input value={cardData.number} onChange={e => setCardData(p => ({ ...p, number: fmtCard(e.target.value) }))} placeholder="1234 5678 9012 3456" maxLength={19} style={{ ...iStyle, fontFamily: "monospace", letterSpacing: "0.1em" }} />
                </div>
                <div style={{ marginBottom: 14 }}>
                  <label style={lStyle}>Cardholder Name</label>
                  <input value={cardData.name} onChange={e => setCardData(p => ({ ...p, name: e.target.value.toUpperCase() }))} placeholder="AS ON CARD" style={iStyle} />
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 20 }}>
                  <div>
                    <label style={lStyle}>Expiry</label>
                    <input value={cardData.expiry} onChange={e => setCardData(p => ({ ...p, expiry: fmtExpiry(e.target.value) }))} placeholder="MM/YY" maxLength={5} style={iStyle} />
                  </div>
                  <div>
                    <label style={lStyle}>CVV</label>
                    <input value={cardData.cvv} onChange={e => setCardData(p => ({ ...p, cvv: e.target.value.replace(/\D/g, "").slice(0, 4) }))} placeholder="•••" maxLength={4} type="password" style={iStyle} />
                  </div>
                </div>
                <div style={{ fontSize: 12, color: COLORS.textMuted, marginBottom: 18, textAlign: "center", display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}><Icon name="lock" size={13} color={COLORS.textMuted} /> 256-bit SSL encrypted · PCI DSS compliant</div>
              </div>
            )}

            {/* Slip upload */}
            {payMethod === "slip" && (
              <div style={{ marginBottom: 20 }}>
                <div style={{ background: COLORS.bg, borderRadius: 12, padding: 16, marginBottom: 14 }}>
                  <div style={{ fontWeight: 700, fontSize: 13, color: COLORS.primary, marginBottom: 10 }}>Bank Transfer Details</div>
                  {[["Bank", "Bank of Ceylon"], ["Account Name", "PST Department"], ["Account No.", "8001-2345-6789"], ["Reference", `Student ID + EXA FEE`]].map(([k, v]) => (
                    <div key={k} style={{ display: "flex", justifyContent: "space-between", fontSize: 13, padding: "5px 0", borderBottom: `1px solid ${COLORS.border}` }}>
                      <span style={{ color: COLORS.textSecondary }}>{k}</span>
                      <span style={{ fontWeight: 600 }}>{v}</span>
                    </div>
                  ))}
                </div>
                <label style={lStyle}>Upload Deposit Slip</label>
                <label style={{ display: "block", border: `2px dashed ${paySlip ? COLORS.success : COLORS.border}`, borderRadius: 12, padding: "20px", textAlign: "center", cursor: "pointer", background: paySlip ? COLORS.success + "06" : COLORS.bg }}>
                  <input type="file" accept="image/*,.pdf" onChange={e => { const f = e.target.files[0]; if (f) { setPaySlip(f); setPaySlipName(f.name); }}} style={{ display: "none" }} />
                  {paySlip
                    ? <div><div style={{ width: 32, height: 32, borderRadius: "50%", background: COLORS.success + "18", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto" }}><Icon name="check" size={16} color={COLORS.success} /></div><div style={{ fontWeight: 700, fontSize: 13, color: COLORS.success, marginTop: 6 }}>{paySlipName}</div></div>
                    : <div><div style={{ display: "flex", justifyContent: "center", marginBottom: 4 }}><Icon name="report" size={26} color={COLORS.textMuted} /></div><div style={{ fontWeight: 700, fontSize: 13, marginTop: 6 }}>Upload Slip</div><div style={{ fontSize: 12, color: COLORS.textMuted }}>JPG, PNG or PDF</div></div>}
                </label>
              </div>
            )}

            {submitError && <div style={{ color: COLORS.danger, fontSize: 13, marginBottom: 10, fontWeight: 600 }}>{submitError}</div>}
            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <button onClick={() => setStep(3)} style={{ background: COLORS.bg, color: COLORS.textSecondary, border: `1px solid ${COLORS.border}`, borderRadius: 12, padding: "12px 24px", fontWeight: 700, fontSize: 14, cursor: "pointer" }}>← Back</button>
              <button onClick={() => {
                  const cardOk = payMethod === "card" && cardData.number.length >= 19 && cardData.name && cardData.expiry.length === 5 && cardData.cvv.length >= 3;
                  const slipOk = payMethod === "slip" && paySlip;
                  if (cardOk || slipOk) submitApplication();
                }}
                disabled={submitting}
                style={{ background: `linear-gradient(135deg, ${typeObj?.color || COLORS.primary}, ${COLORS.primaryLight})`, color: "#fff", border: "none", borderRadius: 12, padding: "12px 32px", fontWeight: 700, fontSize: 14, cursor: submitting ? "default" : "pointer", opacity: submitting ? 0.7 : 1 }}>
                {submitting ? "Submitting…" : payMethod === "card" ? `Pay LKR ${totalFee.toLocaleString()} & Submit` : "Submit Slip & Apply"}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* History always visible */}
      <SectionCard title="Application History">
        {!myApps ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading…</div> : myApps.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No past applications.</div> : (
          <Table headers={["Ref", "Exam Period", "Type", "Subjects", "Fee", "Status"]}
            rows={myApps.map(a => [
              `EXA-${String(a.id).padStart(6, "0")}`,
              `Y${a.year} Sem ${a.semester}`,
              EXAM_TYPES.find(t => t.id === a.exam_type)?.label || a.exam_type,
              String(a.subjects?.length || 0),
              a.total_fee > 0 ? `LKR ${Number(a.total_fee).toLocaleString()}` : "Free",
              a.status.charAt(0).toUpperCase() + a.status.slice(1).replace("_", " "),
            ])}
            badge />
        )}
      </SectionCard>
    </div>
  );
};

const StudentNotices = () => {
  const [notices, setNotices] = useState(null); // null = loading
  const [error, setError] = useState("");

  useEffect(() => {
    api.notices().then(setNotices).catch(err => setError(err.message));
  }, []);

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>Notices</h2>
      {error && <div style={{ color: COLORS.danger, fontSize: 14, marginBottom: 16 }}>{error}</div>}
      {!notices && !error && <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading notices…</div>}
      {notices && notices.length === 0 && <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No notices yet.</div>}
      {notices && notices.map((n) => (
        <div key={n.id} style={{ background: COLORS.card, borderRadius: 14, padding: 24, boxShadow: "0 2px 12px rgba(30,58,95,0.08)", marginBottom: 16 }}>
          <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 8 }}>{n.title}</h3>
          <div style={{ fontSize: 12, color: COLORS.textMuted, marginBottom: 10 }}>From: {n.posted_by_name} · {new Date(n.created_at).toLocaleDateString()}</div>
          <p style={{ margin: 0, fontSize: 14, color: COLORS.textSecondary, lineHeight: 1.6 }}>{n.content}</p>
        </div>
      ))}
    </div>
  );
};

const StudentWellbeing = () => {
  const [mood, setMood] = useState(null);
  const [energy, setEnergy] = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const [note, setNote] = useState("");
  const [counselor, setCounselor] = useState("No, I'm fine");
  const [counsellorChoice, setCounsellorChoice] = useState(null); // "sitharana" | "pst"
  const [sleepHours, setSleepHours] = useState("");
  const [stressLevel, setStressLevel] = useState(null);
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState("");

  const handleSubmit = async () => {
    if (!mood) return;
    setSubmitting(true);
    setSubmitError("");
    try {
      await api.submitCheckin({
        mood, energy, stress_level: stressLevel, sleep_hours: sleepHours || null, note: note || null,
        wants_counselor: counselor !== "No, I'm fine",
      });
      setSubmitted(true);
    } catch (err) {
      setSubmitError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const moods = [
    { label: "Great", val: 5, color: "#22c55e" },
    { label: "Good", val: 4, color: "#84cc16" },
    { label: "Okay", val: 3, color: "#f59e0b" },
    { label: "Low", val: 2, color: "#f97316" },
    { label: "Struggling", val: 1, color: "#ef4444" },
  ];
  const energyLevels = [
    { label: "Full of Energy", val: 3 },
    { label: "Okay", val: 2 },
    { label: "Tired", val: 1 },
  ];
  const stressLevels = [
    { label: "Low", val: 1, color: "#22c55e" },
    { label: "Moderate", val: 2, color: "#f59e0b" },
    { label: "High", val: 3, color: "#f97316" },
    { label: "Very High", val: 4, color: "#ef4444" },
  ];

  if (submitted) return (
    <div style={{ textAlign: "center", padding: "60px 24px" }}>
      <div style={{ width: 84, height: 84, borderRadius: "50%", background: COLORS.success + "18", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px" }}><Icon name="check" size={36} color={COLORS.success} /></div>
      <h2 style={{ fontSize: 24, fontWeight: 800, color: COLORS.textPrimary, marginBottom: 8 }}>Thank you for checking in!</h2>
      <p style={{ color: COLORS.textMuted, fontSize: 15, maxWidth: 420, margin: "0 auto 28px" }}>Your response has been recorded confidentially. Remember, you're not alone — support is available through the university.</p>
      {counselor !== "No, I'm fine" && (
        <div style={{ background: COLORS.accent + "10", border: `1px solid ${COLORS.accent}30`, borderRadius: 14, padding: "20px 24px", maxWidth: 440, margin: "0 auto 24px", textAlign: "left" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 14, color: COLORS.accent, fontWeight: 700, marginBottom: 10 }}>
            <Icon name="counseling" size={16} color={COLORS.accent} /> We'll connect you with support
          </div>
          {counsellorChoice === "pst" ? (
            <p style={{ fontSize: 13.5, color: COLORS.textSecondary, margin: 0, lineHeight: 1.6 }}>
              Your <strong>PST Student Counsellor</strong> has been notified and will reach out to you through your university email to arrange a confidential meeting within the department.
            </p>
          ) : (
            <p style={{ fontSize: 13.5, color: COLORS.textSecondary, margin: 0, lineHeight: 1.6 }}>
              Your request has been forwarded to the <strong>Sitharana Psychological Counselling Centre</strong> (Faculty of Social Sciences &amp; Languages). A counsellor will contact you via your university email to arrange an appointment.
            </p>
          )}
        </div>
      )}
      <button onClick={() => { setSubmitted(false); setMood(null); setEnergy(null); setStressLevel(null); setNote(""); setCounsellorChoice(null); }} style={{ background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.accent})`, color: "#fff", border: "none", borderRadius: 10, padding: "12px 32px", fontWeight: 700, fontSize: 15, cursor: "pointer" }}>Check In Again</button>
    </div>
  );

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 4 }}>Wellbeing Check-In</h2>
      <p style={{ color: COLORS.textMuted, marginBottom: 24, fontSize: 14 }}>Your mental health matters. This takes less than a minute — and it makes a difference.</p>

      {/* Mood */}
      <SectionCard title="How are you feeling today?">
        <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap", marginBottom: 8 }}>
          {moods.map((m) => (
            <div key={m.val} onClick={() => setMood(m.val)} style={{ textAlign: "center", cursor: "pointer", padding: "16px 20px", borderRadius: 14, border: `2px solid ${mood === m.val ? m.color : COLORS.border}`, background: mood === m.val ? m.color + "18" : "#fff", transition: "all 0.2s", minWidth: 72 }}>
              <div style={{ width: 14, height: 14, borderRadius: "50%", background: m.color, margin: "0 auto" }} />
              <div style={{ fontSize: 12, fontWeight: 600, color: mood === m.val ? m.color : COLORS.textMuted, marginTop: 10 }}>{m.label}</div>
            </div>
          ))}
        </div>
      </SectionCard>

      {/* Energy */}
      <SectionCard title="Energy Level">
        <div style={{ display: "flex", gap: 12, justifyContent: "center" }}>
          {energyLevels.map((e) => (
            <div key={e.val} onClick={() => setEnergy(e.val)} style={{ textAlign: "center", cursor: "pointer", padding: "16px 24px", borderRadius: 14, border: `2px solid ${energy === e.val ? COLORS.primary : COLORS.border}`, background: energy === e.val ? COLORS.primary + "12" : "#fff", transition: "all 0.2s", minWidth: 90 }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: energy === e.val ? COLORS.primary : COLORS.textMuted }}>{e.label}</div>
            </div>
          ))}
        </div>
      </SectionCard>

      {/* Stress */}
      <SectionCard title="Stress Level">
        <div style={{ display: "flex", gap: 10, justifyContent: "center", flexWrap: "wrap" }}>
          {stressLevels.map((s) => (
            <div key={s.val} onClick={() => setStressLevel(s.val)} style={{ cursor: "pointer", padding: "10px 22px", borderRadius: 30, border: `2px solid ${stressLevel === s.val ? s.color : COLORS.border}`, background: stressLevel === s.val ? s.color + "18" : "#fff", fontWeight: 700, fontSize: 13, color: stressLevel === s.val ? s.color : COLORS.textMuted, transition: "all 0.2s" }}>
              {s.label}
            </div>
          ))}
        </div>
      </SectionCard>

      {/* Sleep & note */}
      <SectionCard title="A Little More">
        <div style={{ marginBottom: 16 }}>
          <label style={{ fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, display: "block", marginBottom: 6 }}>How many hours did you sleep last night?</label>
          <select value={sleepHours} onChange={e => setSleepHours(e.target.value)} style={{ width: "100%", padding: "10px 14px", borderRadius: 10, border: `1px solid ${COLORS.border}`, fontSize: 14, color: COLORS.textPrimary, background: "#fff" }}>
            <option value="">Select...</option>
            {["Less than 4 hrs", "4–5 hrs", "6–7 hrs", "7–8 hrs", "8+ hrs"].map(o => <option key={o}>{o}</option>)}
          </select>
        </div>
        <div style={{ marginBottom: 16 }}>
          <label style={{ fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, display: "block", marginBottom: 6 }}>What's on your mind? <span style={{ fontWeight: 400 }}>(optional)</span></label>
          <textarea value={note} onChange={e => setNote(e.target.value)} placeholder="Share anything you'd like your wellbeing coordinator to know..." rows={3} style={{ width: "100%", padding: "10px 14px", borderRadius: 10, border: `1px solid ${COLORS.border}`, fontSize: 14, resize: "vertical", fontFamily: "inherit", color: COLORS.textPrimary, boxSizing: "border-box" }} />
        </div>
        <div style={{ marginBottom: 20 }}>
          <label style={{ fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, display: "block", marginBottom: 6 }}>Would you like to speak with a counsellor?</label>
          <select value={counselor} onChange={e => { setCounselor(e.target.value); if (e.target.value === "No, I'm fine") setCounsellorChoice(null); }} style={{ width: "100%", padding: "10px 14px", borderRadius: 10, border: `1px solid ${COLORS.border}`, fontSize: 14, color: COLORS.textPrimary, background: "#fff" }}>
            {["No, I'm fine", "Yes — I'd like an appointment", "Maybe, please check in with me"].map(o => <option key={o}>{o}</option>)}
          </select>
          {counselor !== "No, I'm fine" && (
            <div style={{ marginTop: 12, padding: 16, borderRadius: 12, background: COLORS.bg, border: `1px solid ${COLORS.border}` }}>
              <div style={{ fontSize: 12.5, fontWeight: 700, color: COLORS.textSecondary, marginBottom: 10, textTransform: "uppercase", letterSpacing: "0.03em" }}>Who would you prefer to speak with?</div>
              <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
                <div onClick={() => setCounsellorChoice("sitharana")} style={{ flex: "1 1 220px", cursor: "pointer", padding: "12px 14px", borderRadius: 10, border: `2px solid ${counsellorChoice === "sitharana" ? COLORS.accent : COLORS.border}`, background: counsellorChoice === "sitharana" ? COLORS.accent + "10" : "#fff" }}>
                  <div style={{ fontWeight: 700, fontSize: 13.5, color: COLORS.textPrimary }}>Sitharana Psychological Counselling Centre</div>
                  <div style={{ fontSize: 12, color: COLORS.textMuted, marginTop: 3 }}>University-wide · Faculty of Social Sciences &amp; Languages</div>
                </div>
                <div onClick={() => setCounsellorChoice("pst")} style={{ flex: "1 1 220px", cursor: "pointer", padding: "12px 14px", borderRadius: 10, border: `2px solid ${counsellorChoice === "pst" ? COLORS.accent : COLORS.border}`, background: counsellorChoice === "pst" ? COLORS.accent + "10" : "#fff" }}>
                  <div style={{ fontWeight: 700, fontSize: 13.5, color: COLORS.textPrimary }}>PST Student Counsellor</div>
                  <div style={{ fontSize: 12, color: COLORS.textMuted, marginTop: 3 }}>Within the Dept. of Physical Sciences &amp; Technology</div>
                </div>
              </div>
            </div>
          )}
        </div>
        {submitError && <div style={{ color: COLORS.danger, fontSize: 13, marginBottom: 10, fontWeight: 600 }}>{submitError}</div>}
        <button onClick={handleSubmit} disabled={!mood || submitting} style={{ background: mood ? `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.accent})` : COLORS.border, color: mood ? "#fff" : COLORS.textMuted, border: "none", borderRadius: 10, padding: "13px 36px", fontWeight: 700, fontSize: 15, cursor: mood && !submitting ? "pointer" : "not-allowed", width: "100%", transition: "all 0.2s", opacity: submitting ? 0.7 : 1 }}>
          {submitting ? "Submitting…" : mood ? "Submit Check-In ✓" : "Select a mood to continue"}
        </button>
      </SectionCard>

      {/* Resources */}
      <SectionCard title="Wellbeing Resources">
        <p style={{ fontSize: 13, color: COLORS.textMuted, marginTop: -6, marginBottom: 16 }}>
          Confidential support through Sabaragamuwa University of Sri Lanka's existing student welfare services — for academic stress, personal difficulties, and anything in between.
        </p>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
          {[
            { title: "Sitharana Psychological Counselling Centre", desc: "Confidential 1-on-1 sessions · Faculty of Social Sciences & Languages", phone: "045 222 0301", cta: "Book Counselling Appointment", icon: "counseling", color: COLORS.accent },
            { title: "PST Student Counsellor", desc: "Speak with a counsellor within your own department", phone: "045 222 0480", cta: "Contact Counsellor", icon: "classes", color: COLORS.primary },
            { title: "Senior Student Counsellor", desc: "University-wide guidance for academic & personal difficulties", phone: "045 222 0155", cta: "Request a Meeting", icon: "wellbeing", color: COLORS.success },
            { title: "National Mental Health Helpline", desc: "1926 · Available 24/7, free and confidential", phone: "1926", cta: "Call 1926", icon: "phone", color: COLORS.danger },
          ].map((r, i) => (
            <div key={i} style={{ background: r.color + "08", border: `1px solid ${r.color}20`, borderRadius: 12, padding: 16 }}>
              <Icon name={r.icon} size={20} color={r.color} />
              <div style={{ fontWeight: 700, fontSize: 14, color: COLORS.textPrimary, marginTop: 8 }}>{r.title}</div>
              <div style={{ fontSize: 12, color: COLORS.textMuted, marginTop: 3, marginBottom: 8, lineHeight: 1.5 }}>{r.desc}</div>
              <a href={`tel:${r.phone.replace(/\s+/g, "")}`} style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12.5, fontWeight: 700, color: r.color, textDecoration: "none", marginBottom: 12 }}>
                <Icon name="phone" size={13} color={r.color} /> {r.phone}
              </a>
              <a href={`tel:${r.phone.replace(/\s+/g, "")}`} style={{ display: "block", textAlign: "center", width: "100%", background: "#fff", color: r.color, border: `1.5px solid ${r.color}40`, borderRadius: 8, padding: "8px", fontWeight: 700, fontSize: 12.5, cursor: "pointer", boxSizing: "border-box", textDecoration: "none" }}>{r.cta}</a>
            </div>
          ))}
        </div>
      </SectionCard>
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════════════════════
// LECTURE PORTAL PAGES
// ═══════════════════════════════════════════════════════════════════════════════

const LectureDashboard = () => {
  const [user, setUser] = useState(null);
  const [classes, setClasses] = useState([]);
  const [totalStudents, setTotalStudents] = useState(0);
  const [pendingExamApps, setPendingExamApps] = useState([]);
  const [pendingResultsClasses, setPendingResultsClasses] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([api.me(), api.myClasses(), api.allSemRegs(), api.allExamApps()])
      .then(async ([me, cs, regs, examApps]) => {
        setUser(me);
        setClasses(cs);
        const codes = new Set(cs.map(c => c.code));
        const uniqueStudents = new Set();
        regs.forEach(r => { if ((r.courses || []).some(rc => codes.has(rc.code))) uniqueStudents.add(r.index_number); });
        setTotalStudents(uniqueStudents.size);

        // Pending assignment: exam applications still awaiting review for
        // this lecturer's own modules.
        const relevantExamApps = examApps.filter(a => a.status !== "approved" && a.status !== "rejected");
        setPendingExamApps(relevantExamApps);

        // Pending assignment: classes where at least one student doesn't
        // have a result entered yet.
        const resultChecks = await Promise.all(
          cs.map(c => api.courseResults(c.course_id).then(rows => ({
            code: c.code, name: c.name,
            missing: rows.filter(r => r.grade === null).length,
          })).catch(() => ({ code: c.code, name: c.name, missing: 0 })))
        );
        setPendingResultsClasses(resultChecks.filter(r => r.missing > 0));
      })
      .catch(err => setError(err.message));
  }, []);

  if (error) return <div style={{ color: COLORS.danger, fontSize: 14 }}>{error}</div>;
  if (!user) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading dashboard…</div>;

  const pendingCount = pendingExamApps.length + pendingResultsClasses.length;

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <h2 style={{ margin: 0, fontSize: 24, fontWeight: 700, color: COLORS.textPrimary }}>Welcome, {user.full_name}</h2>
        <p style={{ color: COLORS.textMuted, marginTop: 4 }}>{user.department || "PST Department"} · {user.designation || "Lecturer"}</p>
      </div>
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 24 }}>
        <StatCard label="Number of Students" value={String(totalStudents)} icon="students" color={COLORS.accent} />
        <StatCard label="Today's Classes" value="—" icon="classes" color={COLORS.success} />
        <StatCard label="Pending Assignments" value={String(pendingCount)} icon="overview" color={COLORS.warning} />
      </div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
        <SectionCard title="Today's Classes">
          <div style={{ color: COLORS.textMuted, fontSize: 14, padding: "10px 0" }}>
            Timetable data isn't available yet — check with your department for today's class schedule.
          </div>
        </SectionCard>

        <SectionCard title="Pending Assignments">
          {pendingCount === 0 ? (
            <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Nothing pending — you're all caught up.</div>
          ) : (
            <>
              {pendingResultsClasses.map((r, i) => (
                <div key={`res-${i}`} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 0", borderBottom: `1px solid ${COLORS.border}` }}>
                  <div>
                    <div style={{ fontSize: 14, fontWeight: 600, color: COLORS.textPrimary }}>Enter results — {r.code}</div>
                    <div style={{ fontSize: 12, color: COLORS.textMuted }}>{r.missing} student{r.missing !== 1 ? "s" : ""} without a result yet</div>
                  </div>
                  <span style={{ fontSize: 11, fontWeight: 700, padding: "3px 9px", borderRadius: 20, background: COLORS.warning + "18", color: COLORS.warning }}>Results</span>
                </div>
              ))}
              {pendingExamApps.slice(0, 5).map((a, i) => (
                <div key={`exam-${i}`} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 0", borderBottom: i < pendingExamApps.length - 1 ? `1px solid ${COLORS.border}` : "none" }}>
                  <div>
                    <div style={{ fontSize: 14, fontWeight: 600, color: COLORS.textPrimary }}>Review exam application — {a.full_name}</div>
                    <div style={{ fontSize: 12, color: COLORS.textMuted }}>{a.index_number} · Y{a.year}/S{a.semester}</div>
                  </div>
                  <span style={{ fontSize: 11, fontWeight: 700, padding: "3px 9px", borderRadius: 20, background: COLORS.accent + "18", color: COLORS.accent }}>Exam App</span>
                </div>
              ))}
            </>
          )}
        </SectionCard>
      </div>
    </div>
  );
};

const LectureProfile = () => {
  const [user, setUser] = useState(null);
  const [classes, setClasses] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([api.me(), api.myClasses()])
      .then(([u, cs]) => { setUser(u); setClasses(cs); })
      .catch(err => setError(err.message));
  }, []);

  if (error) return <div style={{ color: COLORS.danger, fontSize: 14 }}>{error}</div>;
  if (!user) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading profile…</div>;

  const initials = (user.full_name || user.username || "?")
    .split(" ")
    .map(w => w[0])
    .filter(Boolean)
    .slice(0, 2)
    .join("")
    .toUpperCase();

  const fields = [
    ["Lecturer ID", user.staff_id || user.username],
    ["Name", user.full_name],
    ["Email", user.email || "—"],
    ["Phone", user.phone || "—"],
    ["Department", user.department || "—"],
  ];

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>Lecturer Profile</h2>
      <SectionCard title="">
        <div style={{ display: "flex", gap: 28, alignItems: "flex-start", flexWrap: "wrap" }}>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 12, minWidth: 140 }}>
            <div style={{ width: 120, height: 120, borderRadius: "50%", background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.accent})`, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 36, fontWeight: 800, color: "#fff" }}>
              {initials}
            </div>
            <div style={{ fontSize: 13, color: COLORS.textMuted }}>{user.designation || "Lecturer"}</div>
          </div>
          <div style={{ flex: 1, minWidth: 280, display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 20 }}>
            {fields.map(([label, value], i) => (
              <div key={i}>
                <div style={{ fontSize: 11, fontWeight: 600, color: COLORS.textMuted, textTransform: "uppercase", letterSpacing: "0.04em", marginBottom: 4 }}>{label}</div>
                <div style={{ fontSize: 15, fontWeight: 600, color: COLORS.textPrimary }}>{value}</div>
              </div>
            ))}
          </div>
        </div>
      </SectionCard>

      <SectionCard title="Assigned Courses">
        {!classes ? (
          <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading…</div>
        ) : classes.length === 0 ? (
          <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No courses assigned yet.</div>
        ) : (
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
            <thead>
              <tr style={{ background: COLORS.bg }}>
                {["Course Code", "Course Name", "Year / Semester", "Credits"].map((h, i) => (
                  <th key={i} style={{ padding: "11px 14px", textAlign: "left", color: COLORS.textSecondary, fontWeight: 600, fontSize: 12, textTransform: "uppercase" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {classes.map((c) => (
                <tr key={c.course_id} style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                  <td style={{ padding: "12px 14px", fontWeight: 700, color: COLORS.primary, fontSize: 13 }}>{c.code}</td>
                  <td style={{ padding: "12px 14px", color: COLORS.textPrimary }}>{c.name}</td>
                  <td style={{ padding: "12px 14px" }}>Year {c.year} · Semester {c.semester}</td>
                  <td style={{ padding: "12px 14px" }}>{c.credits}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </SectionCard>
    </div>
  );
};

const LectureClasses = () => {
  const [classes, setClasses] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api.myClasses().then(setClasses).catch(err => setError(err.message));
  }, []);

  if (error) return <div style={{ color: COLORS.danger, fontSize: 14 }}>{error}</div>;
  if (!classes) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading classes…</div>;

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>My Classes</h2>
      {classes.length === 0 && <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No classes assigned yet.</div>}
      {classes.map((c) => (
        <SectionCard key={c.course_id} title={`${c.code} — ${c.name}`}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 16 }}>
            {[["Year / Semester", `Year ${c.year} · Sem ${c.semester}`], ["Credits", c.credits], ["Academic Year", c.academic_year]].map(([k, v], j) => (
              <div key={j} style={{ background: COLORS.bg, borderRadius: 8, padding: "10px 14px" }}>
                <div style={{ fontSize: 11, fontWeight: 600, color: COLORS.textMuted, textTransform: "uppercase" }}>{k}</div>
                <div style={{ fontSize: 14, fontWeight: 600, color: COLORS.textPrimary, marginTop: 4 }}>{v}</div>
              </div>
            ))}
          </div>
        </SectionCard>
      ))}
    </div>
  );
};

const LectureMarkAttendance = () => {
  const [classes, setClasses] = useState([]);
  const [filterYear, setFilterYear] = useState("");
  const [filterSemester, setFilterSemester] = useState("");
  const [courseId, setCourseId] = useState("");
  const [date, setDate] = useState(new Date().toISOString().slice(0, 10));
  const [roster, setRoster] = useState(null);
  const [statuses, setStatuses] = useState({});
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  // ── Bulk-mark attendance from an uploaded Excel sheet ──
  const [uploadError, setUploadError] = useState("");
  const [uploadSummary, setUploadSummary] = useState(null);

  useEffect(() => {
    api.myClasses().then(cs => { setClasses(cs); if (cs.length) setCourseId(String(cs[0].course_id)); }).catch(err => setError(err.message));
  }, []);

  useEffect(() => {
    if (!courseId) return;
    setRoster(null);
    setUploadSummary(null);
    api.courseRoster(courseId, date)
      .then(rows => {
        setRoster(rows);
        const init = {};
        rows.forEach(r => { init[r.student_id] = r.status || "present"; });
        setStatuses(init);
      })
      .catch(err => setError(err.message));
  }, [courseId, date]);

  const yearOptions = [...new Set(classes.map(c => c.year))].sort((a, b) => a - b);
  const semesterOptions = [...new Set(
    classes.filter(c => !filterYear || String(c.year) === String(filterYear)).map(c => c.semester)
  )].sort((a, b) => a - b);
  const filteredClasses = classes.filter(c =>
    (!filterYear || String(c.year) === String(filterYear)) &&
    (!filterSemester || String(c.semester) === String(filterSemester))
  );

  const onFilterYearChange = (v) => {
    setFilterYear(v); setFilterSemester("");
    const next = classes.filter(c => !v || String(c.year) === String(v));
    if (next.length && !next.some(c => String(c.course_id) === String(courseId))) setCourseId(String(next[0].course_id));
  };
  const onFilterSemesterChange = (v) => {
    setFilterSemester(v);
    const next = classes.filter(c => (!filterYear || String(c.year) === String(filterYear)) && (!v || String(c.semester) === String(v)));
    if (next.length && !next.some(c => String(c.course_id) === String(courseId))) setCourseId(String(next[0].course_id));
  };

  const selectedClass = classes.find(c => String(c.course_id) === String(courseId));

  const setAll = (status) => {
    const next = {};
    (roster || []).forEach(r => { next[r.student_id] = status; });
    setStatuses(next);
  };

  const handleSave = async () => {
    setSaving(true);
    setSaved(false);
    setError("");
    try {
      const records = (roster || []).map(r => ({ student_id: r.student_id, status: statuses[r.student_id] || "present" }));
      await api.markAttendance({ courseId, date, records });
      setSaved(true);
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  // Parses an uploaded .xlsx sheet (columns like "Index Number" / "Student ID"
  // and "Status") and fills the statuses below — the lecturer still reviews
  // and hits "Save All" to persist it, same as marking manually.
  const handleUploadSheet = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    e.target.value = "";
    setUploadError("");
    setUploadSummary(null);
    if (!roster || roster.length === 0) {
      setUploadError("Select a module and date with an enrolled roster before uploading a sheet.");
      return;
    }
    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const workbook = XLSX.read(evt.target.result, { type: "array" });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(sheet, { defval: "" });
        const byIndexNo = {};
        roster.forEach(r => { byIndexNo[String(r.index_number).trim().toUpperCase()] = r.student_id; });

        const next = { ...statuses };
        let matched = 0;
        const unmatched = [];
        rows.forEach(row => {
          const idxKey = Object.keys(row).find(k => /index|student.*id|reg.*no/i.test(k));
          const statusKey = Object.keys(row).find(k => /status|attendance/i.test(k));
          if (!idxKey) return;
          const idxVal = String(row[idxKey]).trim().toUpperCase();
          if (!idxVal) return;
          const studentId = byIndexNo[idxVal];
          if (!studentId) { unmatched.push(idxVal); return; }
          let statusVal = statusKey ? String(row[statusKey]).trim().toLowerCase() : "present";
          if (!["present", "absent", "late"].includes(statusVal)) {
            statusVal = /^p/.test(statusVal) ? "present" : /^a/.test(statusVal) ? "absent" : /^l/.test(statusVal) ? "late" : "present";
          }
          next[studentId] = statusVal;
          matched++;
        });
        setStatuses(next);
        setUploadSummary({ matched, unmatched, total: rows.length });
        setSaved(false);
      } catch (err) {
        setUploadError("Couldn't read that file — make sure it's a valid Excel (.xlsx) sheet with Index Number and Status columns.");
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const selectStyle = { width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, background: "#fff", boxSizing: "border-box" };

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>Mark Attendance</h2>
      <SectionCard title="Session Details">
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 2fr 1fr", gap: 16 }}>
          <div style={{ marginBottom: 18 }}>
            <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Year</label>
            <select value={filterYear} onChange={e => onFilterYearChange(e.target.value)} style={selectStyle}>
              <option value="">All Years</option>
              {yearOptions.map(y => <option key={y} value={y}>Year {y}</option>)}
            </select>
          </div>
          <div style={{ marginBottom: 18 }}>
            <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Semester</label>
            <select value={filterSemester} onChange={e => onFilterSemesterChange(e.target.value)} style={selectStyle}>
              <option value="">All Semesters</option>
              {semesterOptions.map(s => <option key={s} value={s}>Semester {s}</option>)}
            </select>
          </div>
          <div style={{ marginBottom: 18 }}>
            <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Module</label>
            <select value={courseId} onChange={e => setCourseId(e.target.value)} style={selectStyle}>
              {filteredClasses.map(c => <option key={c.course_id} value={c.course_id}>{c.code} — {c.name}</option>)}
            </select>
          </div>
          <div style={{ marginBottom: 18 }}>
            <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Date</label>
            <input type="date" value={date} onChange={e => setDate(e.target.value)} style={selectStyle} />
          </div>
        </div>
      </SectionCard>

      <SectionCard title="Upload Attendance Sheet">
        <p style={{ fontSize: 13, color: COLORS.textMuted, marginTop: 0, marginBottom: 16 }}>
          For the Year, Semester, Module and Date selected above, upload an Excel (.xlsx) sheet with <strong>Index Number</strong> and <strong>Status</strong> (Present / Absent / Late) columns — matching students will be marked below automatically. Review, then click "Save All" to confirm.
        </p>
        <input type="file" accept=".xlsx,.xls" onChange={handleUploadSheet} style={selectStyle} />
        {uploadError && <div style={{ color: COLORS.danger, fontSize: 13, marginTop: 12, fontWeight: 600 }}>{uploadError}</div>}
        {uploadSummary && (
          <div style={{ marginTop: 12, fontSize: 13, color: COLORS.textSecondary }}>
            <span style={{ color: COLORS.success, fontWeight: 700 }}>{uploadSummary.matched}</span> of {uploadSummary.total} rows matched to students on the roster and pre-filled below.
            {uploadSummary.unmatched.length > 0 && (
              <span style={{ color: COLORS.danger }}> Could not match: {uploadSummary.unmatched.join(", ")}.</span>
            )}
          </div>
        )}
      </SectionCard>

      {error && <div style={{ color: COLORS.danger, fontSize: 14, marginBottom: 16 }}>{error}</div>}
      <SectionCard title={selectedClass ? `Student Attendance — ${selectedClass.code} (${roster?.length || 0} Students)` : "Student Attendance"} action={saving ? "Saving…" : saved ? "Saved ✓" : "Save All"} onAction={saving ? undefined : handleSave}>
        {!roster ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading roster…</div> : roster.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No students enrolled.</div> : (
          <>
            <div style={{ marginBottom: 16, display: "flex", gap: 10 }}>
              <button onClick={() => setAll("present")} style={{ background: COLORS.success, color: "#fff", border: "none", borderRadius: 8, padding: "7px 16px", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>Mark All Present</button>
              <button onClick={() => setAll("absent")} style={{ background: COLORS.danger + "18", color: COLORS.danger, border: "none", borderRadius: 8, padding: "7px 16px", fontSize: 13, fontWeight: 600, cursor: "pointer" }}>Mark All Absent</button>
            </div>
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
              <thead>
                <tr style={{ background: COLORS.bg }}>
                  {["Student ID", "Name", "Present", "Absent", "Late"].map((h, i) => (
                    <th key={i} style={{ padding: "11px 14px", textAlign: "left", color: COLORS.textSecondary, fontWeight: 600, fontSize: 12, textTransform: "uppercase" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {roster.map((r) => (
                  <tr key={r.student_id} style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                    <td style={{ padding: "12px 14px", color: COLORS.textMuted, fontSize: 13 }}>{r.index_number}</td>
                    <td style={{ padding: "12px 14px", fontWeight: 600, color: COLORS.textPrimary }}>{r.full_name}</td>
                    {["present", "absent", "late"].map((opt) => (
                      <td key={opt} style={{ padding: "12px 14px" }}>
                        <input type="radio" name={`att-${r.student_id}`} checked={statuses[r.student_id] === opt} onChange={() => setStatuses(s => ({ ...s, [r.student_id]: opt }))} style={{ accentColor: COLORS.primary }} />
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </>
        )}
      </SectionCard>
    </div>
  );
};

const LectureEnterResults = () => {
  const [classes, setClasses] = useState([]);
  const [filterYear, setFilterYear] = useState("");
  const [filterSemester, setFilterSemester] = useState("");
  const [courseId, setCourseId] = useState("");
  const [rows, setRows] = useState([]);
  const [loadingRoster, setLoadingRoster] = useState(false);
  const [fileName, setFileName] = useState("");
  const [uploadNote, setUploadNote] = useState(null); // { type: "ok" | "warn", text }
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    api.myClasses().then(cs => { setClasses(cs); if (cs.length) setCourseId(String(cs[0].course_id)); }).catch(err => setError(err.message));
  }, []);

  useEffect(() => {
    if (!courseId) return;
    setLoadingRoster(true);
    setSaved(false);
    api.courseRoster(courseId)
      .then(roster => setRows(roster.map(r => ({ student_id: r.student_id, id: r.index_number, name: r.full_name, mark: "" }))))
      .catch(err => setError(err.message))
      .finally(() => setLoadingRoster(false));
  }, [courseId]);

  const yearOptions = [...new Set(classes.map(c => c.year))].sort((a, b) => a - b);
  const semesterOptions = [...new Set(
    classes.filter(c => !filterYear || String(c.year) === String(filterYear)).map(c => c.semester)
  )].sort((a, b) => a - b);
  const filteredClasses = classes.filter(c =>
    (!filterYear || String(c.year) === String(filterYear)) &&
    (!filterSemester || String(c.semester) === String(filterSemester))
  );

  const onFilterYearChange = (v) => {
    setFilterYear(v); setFilterSemester("");
    const next = classes.filter(c => !v || String(c.year) === String(v));
    if (next.length && !next.some(c => String(c.course_id) === String(courseId))) setCourseId(String(next[0].course_id));
  };
  const onFilterSemesterChange = (v) => {
    setFilterSemester(v);
    const next = classes.filter(c => (!filterYear || String(c.year) === String(filterYear)) && (!v || String(c.semester) === String(v)));
    if (next.length && !next.some(c => String(c.course_id) === String(courseId))) setCourseId(String(next[0].course_id));
  };

  const selectedClass = classes.find(c => String(c.course_id) === String(courseId));

  const gradeOf = (mark) => {
    const m = parseFloat(mark);
    if (Number.isNaN(m)) return "—";
    if (m >= 85) return "A+";
    if (m >= 70) return "A";
    if (m >= 65) return "A-";
    if (m >= 60) return "B+";
    if (m >= 55) return "B";
    if (m >= 50) return "B-";
    if (m >= 45) return "C+";
    if (m >= 40) return "C";
    if (m >= 35) return "C-";
    if (m >= 30) return "D";
    return "F";
  };

  const idKeys = ["index number", "index no", "index no.", "reg no", "registration number", "student id"];
  const marksKeys = ["marks", "mark", "total", "total marks"];
  const findKey = (row, candidates) => Object.keys(row).find(k => candidates.includes(k.trim().toLowerCase()));

  const handleFile = (file) => {
    if (!file) return;
    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const workbook = XLSX.read(e.target.result, { type: "array" });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const sheetRows = XLSX.utils.sheet_to_json(sheet, { defval: "" });

        let matched = 0, skipped = 0;
        const byIndexNo = {};
        sheetRows.forEach((r) => {
          const idKey = findKey(r, idKeys);
          const marksKey = findKey(r, marksKeys);
          const idxNo = idKey ? String(r[idKey]).trim() : "";
          const mark = marksKey ? String(r[marksKey]).trim() : "";
          if (!idxNo || mark === "" || Number.isNaN(parseFloat(mark))) { skipped++; return; }
          byIndexNo[idxNo] = mark;
        });

        setRows(rs => rs.map(row => {
          if (byIndexNo[row.id] !== undefined) { matched++; return { ...row, mark: byIndexNo[row.id] }; }
          return row;
        }));

        if (!matched) {
          setUploadNote({ type: "warn", text: "Couldn't match any rows to this class's roster. Make sure the Index Number column matches." });
        } else {
          setUploadNote({ type: "ok", text: `Matched ${matched} student${matched !== 1 ? "s" : ""} from ${file.name}${skipped ? ` — skipped ${skipped} row(s).` : "."}` });
        }
      } catch (err) {
        setUploadNote({ type: "warn", text: "Couldn't read that file. Please upload a valid .xlsx, .xls or .csv sheet." });
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const downloadTemplate = () => {
    const sheet = XLSX.utils.json_to_sheet(rows.map(r => ({ "Index Number": r.id, "Name": r.name, "Marks": "" })));
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, sheet, "Marks Template");
    XLSX.writeFile(workbook, `marks-template-${selectedClass?.code?.replace(/\s+/g, "") || "course"}.xlsx`);
  };

  const updateMark = (i, value) => setRows(rs => rs.map((r, idx) => idx === i ? { ...r, mark: value } : r));

  const handleSubmit = async () => {
    if (!selectedClass) return;
    setSaving(true);
    setError("");
    try {
      const records = rows.filter(r => r.mark !== "").map(r => ({ student_id: r.student_id, marks: parseFloat(r.mark) }));
      await api.enterResults({ courseId, year: selectedClass.year, semester: selectedClass.semester, records });
      setSaved(true);
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>Enter Results</h2>
      <SectionCard title="Assessment Details">
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 2fr", gap: 16 }}>
          <div>
            <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Year</label>
            <select value={filterYear} onChange={e => onFilterYearChange(e.target.value)} style={{ width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, background: "#fff", boxSizing: "border-box" }}>
              <option value="">All Years</option>
              {yearOptions.map(y => <option key={y} value={y}>Year {y}</option>)}
            </select>
          </div>
          <div>
            <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Semester</label>
            <select value={filterSemester} onChange={e => onFilterSemesterChange(e.target.value)} style={{ width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, background: "#fff", boxSizing: "border-box" }}>
              <option value="">All Semesters</option>
              {semesterOptions.map(s => <option key={s} value={s}>Semester {s}</option>)}
            </select>
          </div>
          <div>
            <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Module</label>
            <select value={courseId} onChange={e => setCourseId(e.target.value)} style={{ width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, background: "#fff", boxSizing: "border-box" }}>
              {filteredClasses.map(c => <option key={c.course_id} value={c.course_id}>{c.code} — {c.name} (Year {c.year}, Sem {c.semester})</option>)}
            </select>
          </div>
        </div>
      </SectionCard>

      <SectionCard title="Upload Marks Sheet">
        <p style={{ fontSize: 13, color: COLORS.textMuted, marginTop: 0, marginBottom: 16 }}>
          Upload an Excel sheet with <strong>Index Number</strong> and <strong>Marks</strong> columns to fill the table below in one go, instead of entering marks one by one.
        </p>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
          <label style={{ display: "inline-flex", alignItems: "center", gap: 8, background: COLORS.primary, color: "#fff", border: "none", borderRadius: 10, padding: "10px 18px", fontWeight: 700, fontSize: 13, cursor: "pointer" }}>
            <Icon name="report" size={15} color="#fff" />
            {fileName ? "Choose a different file" : "Upload Excel Sheet"}
            <input type="file" accept=".xlsx,.xls,.csv" style={{ display: "none" }} onChange={e => handleFile(e.target.files[0])} />
          </label>
          <button onClick={downloadTemplate} style={{ display: "inline-flex", alignItems: "center", gap: 8, background: "#fff", color: COLORS.primary, border: `1.5px solid ${COLORS.primary}`, borderRadius: 10, padding: "10px 18px", fontWeight: 700, fontSize: 13, cursor: "pointer" }}>
            <Icon name="report" size={15} color={COLORS.primary} />
            Download Blank Template
          </button>
          {fileName && <span style={{ fontSize: 13, color: COLORS.textMuted }}>{fileName}</span>}
        </div>
        {uploadNote && (
          <div style={{ marginTop: 14, display: "flex", alignItems: "center", gap: 8, fontSize: 13, fontWeight: 600, padding: "10px 14px", borderRadius: 10, background: (uploadNote.type === "ok" ? COLORS.success : COLORS.warning) + "12", color: uploadNote.type === "ok" ? COLORS.success : "#92400e" }}>
            <Icon name={uploadNote.type === "ok" ? "check" : "alert"} size={15} color={uploadNote.type === "ok" ? COLORS.success : "#92400e"} />
            {uploadNote.text}
          </div>
        )}
      </SectionCard>

      {error && <div style={{ color: COLORS.danger, fontSize: 14, marginBottom: 16 }}>{error}</div>}
      <SectionCard title="Enter Marks" action={saving ? "Saving…" : saved ? "Saved ✓" : "Submit Results"} onAction={saving ? undefined : handleSubmit}>
        {loadingRoster ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading roster…</div> : rows.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No students enrolled.</div> : (
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
            <thead>
              <tr style={{ background: COLORS.bg }}>
                {["Student ID", "Name", "Marks Obtained", "Out of", "Grade (Auto)"].map((h, i) => (
                  <th key={i} style={{ padding: "11px 14px", textAlign: "left", color: COLORS.textSecondary, fontWeight: 600, fontSize: 12, textTransform: "uppercase" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={r.student_id} style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                  <td style={{ padding: "12px 14px", color: COLORS.textMuted, fontSize: 13 }}>{r.id}</td>
                  <td style={{ padding: "12px 14px", fontWeight: 600 }}>{r.name}</td>
                  <td style={{ padding: "12px 14px" }}><input type="number" value={r.mark} onChange={e => updateMark(i, e.target.value)} style={{ width: 80, padding: "6px 10px", borderRadius: 6, border: `1px solid ${COLORS.border}`, fontSize: 14, outline: "none" }} /></td>
                  <td style={{ padding: "12px 14px", color: COLORS.textMuted }}>100</td>
                  <td style={{ padding: "12px 14px" }}><span style={{ padding: "3px 10px", borderRadius: 20, fontSize: 12, fontWeight: 600, background: COLORS.success + "18", color: COLORS.success }}>{gradeOf(r.mark)}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </SectionCard>
    </div>
  );
};

const LectureExamApps = () => {
  const [apps, setApps] = useState(null);
  const [error, setError] = useState("");
  const [updating, setUpdating] = useState(null);

  const load = () => api.allExamApps().then(setApps).catch(err => setError(err.message));
  useEffect(() => { load(); }, []);

  const setStatus = async (id, status) => {
    setUpdating(id);
    try {
      await api.updateExamStatus(id, status);
      setApps(rows => rows.map(a => a.id === id ? { ...a, status } : a));
    } catch (err) {
      setError(err.message);
    } finally {
      setUpdating(null);
    }
  };

  if (error) return <div style={{ color: COLORS.danger, fontSize: 14 }}>{error}</div>;
  if (!apps) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading applications…</div>;

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>Exam Applications</h2>
      <SectionCard title="Student Exam Applications">
        {apps.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No applications yet.</div> : (
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
            <thead>
              <tr style={{ background: COLORS.bg }}>
                {["Index No.", "Name", "Type", "Year/Sem", "Fee", "Status", ""].map((h, i) => (
                  <th key={i} style={{ padding: "11px 14px", textAlign: "left", color: COLORS.textSecondary, fontWeight: 600, fontSize: 12, textTransform: "uppercase" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {apps.map(a => (
                <tr key={a.id} style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                  <td style={{ padding: "12px 14px", color: COLORS.textMuted, fontSize: 13 }}>{a.index_number}</td>
                  <td style={{ padding: "12px 14px", fontWeight: 600 }}>{a.full_name}</td>
                  <td style={{ padding: "12px 14px" }}>{EXAM_TYPES.find(t => t.id === a.exam_type)?.label || a.exam_type}</td>
                  <td style={{ padding: "12px 14px" }}>Y{a.year}/S{a.semester}</td>
                  <td style={{ padding: "12px 14px" }}>{a.total_fee > 0 ? `LKR ${Number(a.total_fee).toLocaleString()}` : "Free"}</td>
                  <td style={{ padding: "12px 14px" }}>
                    <span style={{ padding: "3px 10px", borderRadius: 20, fontSize: 12, fontWeight: 600, background: (a.status === "approved" ? COLORS.success : a.status === "rejected" ? COLORS.danger : COLORS.warning) + "18", color: a.status === "approved" ? COLORS.success : a.status === "rejected" ? COLORS.danger : COLORS.warning }}>{a.status}</span>
                  </td>
                  <td style={{ padding: "12px 14px" }}>
                    {a.status !== "approved" && a.status !== "rejected" && (
                      <div style={{ display: "flex", gap: 6 }}>
                        <button disabled={updating === a.id} onClick={() => setStatus(a.id, "approved")} style={{ background: COLORS.success, color: "#fff", border: "none", borderRadius: 6, padding: "5px 10px", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>Approve</button>
                        <button disabled={updating === a.id} onClick={() => setStatus(a.id, "rejected")} style={{ background: COLORS.danger + "18", color: COLORS.danger, border: "none", borderRadius: 6, padding: "5px 10px", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>Reject</button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </SectionCard>
    </div>
  );
};

const LecturePostNotice = () => {
  const [title, setTitle] = useState("");
  const [audience, setAudience] = useState("All Students & Lecturers");
  const [content, setContent] = useState("");
  const [posting, setPosting] = useState(false);
  const [error, setError] = useState("");
  const [posted, setPosted] = useState(null);

  const AUDIENCE_MAP = { "All Students & Lecturers": "all", "Students Only": "student", "Lecturers Only": "lecturer" };

  const load = () => api.notices().then(setPosted).catch(() => setPosted([]));
  useEffect(() => { load(); }, []);

  const handlePublish = async () => {
    if (!title.trim() || !content.trim()) { setError("Title and content are required."); return; }
    setPosting(true);
    setError("");
    try {
      await api.createNotice({ title: title.trim(), content: content.trim(), audience: AUDIENCE_MAP[audience] });
      setTitle("");
      setContent("");
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setPosting(false);
    }
  };

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>Post Notice</h2>
      <SectionCard title="Create New Notice">
        <Field label="Notice Title" placeholder="e.g. Assignment Submission Deadline Extended" value={title} onChange={setTitle} />
        <Field label="Target Audience" type="select" options={["All Students & Lecturers", "Students Only", "Lecturers Only"]} value={audience} onChange={setAudience} />
        <Field label="Notice Content" type="textarea" placeholder="Write your notice here..." value={content} onChange={setContent} />
        {error && <div style={{ color: COLORS.danger, fontSize: 13, marginBottom: 12, fontWeight: 600 }}>{error}</div>}
        <div style={{ display: "flex", gap: 12 }}>
          <button onClick={handlePublish} disabled={posting} style={{ background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.primaryLight})`, color: "#fff", border: "none", borderRadius: 10, padding: "12px 28px", fontWeight: 700, fontSize: 14, cursor: posting ? "default" : "pointer", opacity: posting ? 0.7 : 1 }}>{posting ? "Publishing…" : "Publish Notice"}</button>
        </div>
      </SectionCard>
      <SectionCard title="Posted Notices">
        {!posted ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading…</div> : posted.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No notices posted yet.</div> : (
          <Table headers={["Title", "Posted By", "Date"]} rows={posted.map(n => [n.title, n.posted_by_name, new Date(n.created_at).toLocaleDateString()])} />
        )}
      </SectionCard>
    </div>
  );
};

const LecturePostAssignment = () => {
  const [classes, setClasses] = useState([]);
  const [courseId, setCourseId] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [deadline, setDeadline] = useState("");
  const [posting, setPosting] = useState(false);
  const [error, setError] = useState("");
  const [posted, setPosted] = useState(null);

  useEffect(() => {
    api.myClasses().then(cs => { setClasses(cs); if (cs.length) setCourseId(String(cs[0].course_id)); }).catch(err => setError(err.message));
  }, []);

  const load = () => { if (courseId) api.courseAssignments(courseId).then(setPosted).catch(() => setPosted([])); };
  useEffect(() => { load(); }, [courseId]);

  const handlePublish = async () => {
    if (!title.trim() || !deadline) { setError("Title and deadline are required."); return; }
    setPosting(true);
    setError("");
    try {
      await api.createAssignment({ courseId, title: title.trim(), description: description.trim(), deadline });
      setTitle("");
      setDescription("");
      setDeadline("");
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setPosting(false);
    }
  };

  const selectedClass = classes.find(c => String(c.course_id) === String(courseId));

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>Post Assignment</h2>
      <SectionCard title="Create New Assignment">
        <div style={{ marginBottom: 18 }}>
          <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Module</label>
          <select value={courseId} onChange={e => setCourseId(e.target.value)} style={{ width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, background: "#fff" }}>
            {classes.map(c => <option key={c.course_id} value={c.course_id}>{c.code} — {c.name}</option>)}
          </select>
        </div>
        <Field label="Assignment Title" placeholder="e.g. Assignment 2 — Sorting Algorithms" value={title} onChange={setTitle} />
        <Field label="Description" type="textarea" placeholder="Instructions for the assignment…" value={description} onChange={setDescription} />
        <div style={{ marginBottom: 18 }}>
          <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Deadline</label>
          <input type="datetime-local" value={deadline} onChange={e => setDeadline(e.target.value)} style={{ width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14 }} />
        </div>
        {error && <div style={{ color: COLORS.danger, fontSize: 13, marginBottom: 12, fontWeight: 600 }}>{error}</div>}
        <button onClick={handlePublish} disabled={posting} style={{ background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.accent})`, color: "#fff", border: "none", borderRadius: 10, padding: "12px 28px", fontWeight: 700, fontSize: 14, cursor: posting ? "default" : "pointer", opacity: posting ? 0.7 : 1 }}>{posting ? "Publishing…" : "Post Assignment"}</button>
      </SectionCard>
      <SectionCard title={selectedClass ? `Assignments — ${selectedClass.code}` : "Assignments"}>
        {!posted ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading…</div> : posted.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No assignments posted for this module yet.</div> : (
          <Table headers={["Title", "Deadline", "Submissions"]} rows={posted.map(a => [a.title, new Date(a.deadline).toLocaleString(), String(a.submission_count)])} />
        )}
      </SectionCard>
    </div>
  );
};

const StudentMaterials = () => {
  const [materials, setMaterials] = useState(null);
  const [error, setError] = useState("");
  const [filterYear, setFilterYear] = useState("");
  const [filterSemester, setFilterSemester] = useState("");
  const [filterCode, setFilterCode] = useState("");

  useEffect(() => { api.myMaterials().then(setMaterials).catch(err => setError(err.message)); }, []);

  const onYearChange = (v) => { setFilterYear(v); setFilterSemester(""); setFilterCode(""); };
  const onSemesterChange = (v) => { setFilterSemester(v); setFilterCode(""); };

  if (error) return <div style={{ color: COLORS.danger, fontSize: 14 }}>{error}</div>;
  if (!materials) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading lecture materials…</div>;

  // Cascading options: semesters depend on the chosen year, subjects depend on
  // the chosen year + semester — mirrors the Results download filters.
  const yearOptions = [...new Set(materials.map(m => m.year))].filter(y => y != null).sort((a, b) => a - b);
  const semesterOptions = [...new Set(
    materials.filter(m => !filterYear || String(m.year) === String(filterYear)).map(m => m.semester)
  )].filter(s => s != null).sort((a, b) => a - b);
  const subjectOptions = materials
    .filter(m =>
      (!filterYear || String(m.year) === String(filterYear)) &&
      (!filterSemester || String(m.semester) === String(filterSemester))
    )
    .reduce((acc, m) => (acc.some(s => s.code === m.code) ? acc : [...acc, { code: m.code, name: m.course_name }]), [])
    .sort((a, b) => a.code.localeCompare(b.code));

  const filtered = materials.filter(m =>
    (!filterYear || String(m.year) === String(filterYear)) &&
    (!filterSemester || String(m.semester) === String(filterSemester)) &&
    (!filterCode || m.code === filterCode)
  );

  const selectStyle = { width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, background: "#fff" };

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>Lecture Materials</h2>

      {materials.length === 0 ? (
        <SectionCard title="Lecture Materials">
          <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No lecture materials posted for your registered courses yet.</div>
        </SectionCard>
      ) : (
        <>
          <SectionCard title="Find Lecture Notes">
            <p style={{ fontSize: 13, color: COLORS.textMuted, marginTop: 0, marginBottom: 16 }}>
              Choose a Year, Semester and Subject to find and download that subject's lecture notes (PDF) — or leave a filter on "All" to browse everything.
            </p>
            <div style={{ display: "flex", gap: 14, flexWrap: "wrap" }}>
              <div style={{ flex: "1 1 160px", minWidth: 160 }}>
                <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Year</label>
                <select value={filterYear} onChange={e => onYearChange(e.target.value)} style={selectStyle}>
                  <option value="">All Years</option>
                  {yearOptions.map(y => <option key={y} value={y}>Year {y}</option>)}
                </select>
              </div>
              <div style={{ flex: "1 1 160px", minWidth: 160 }}>
                <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Semester</label>
                <select value={filterSemester} onChange={e => onSemesterChange(e.target.value)} style={selectStyle}>
                  <option value="">All Semesters</option>
                  {semesterOptions.map(s => <option key={s} value={s}>Semester {s}</option>)}
                </select>
              </div>
              <div style={{ flex: "2 1 240px", minWidth: 200 }}>
                <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Subject</label>
                <select value={filterCode} onChange={e => setFilterCode(e.target.value)} style={selectStyle}>
                  <option value="">All Subjects</option>
                  {subjectOptions.map(s => <option key={s.code} value={s.code}>{s.code} — {s.name}</option>)}
                </select>
              </div>
            </div>
          </SectionCard>

          {filtered.length === 0 ? (
            <SectionCard title="Lecture Materials">
              <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No lecture materials found for the selected filters.</div>
            </SectionCard>
          ) : (
            filtered.map((m) => (
              <SectionCard key={m.id} title="">
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 16, flexWrap: "wrap" }}>
                  <div style={{ flex: 1, minWidth: 260 }}>
                    <h3 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 6 }}>{m.title}</h3>
                    <div style={{ fontSize: 13, color: COLORS.primary, fontWeight: 600, marginBottom: 8 }}>
                      {m.code} — {m.course_name}{m.year ? ` · Year ${m.year} / Semester ${m.semester}` : ""}
                    </div>
                    {m.description && <p style={{ fontSize: 13, color: COLORS.textSecondary, lineHeight: 1.6, margin: "0 0 10px" }}>{m.description}</p>}
                    <div style={{ fontSize: 12, color: COLORS.textMuted }}>Uploaded {new Date(m.uploaded_at).toLocaleDateString()}</div>
                  </div>
                  <a href={fileUrl(m.file_path)} target="_blank" rel="noreferrer" download={m.original_name}
                    style={{ display: "inline-flex", alignItems: "center", gap: 8, background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.accent})`, color: "#fff", borderRadius: 8, padding: "9px 16px", fontWeight: 700, fontSize: 12.5, textDecoration: "none" }}>
                    <Icon name="modules" size={14} color="#fff" />
                    {m.original_name.length > 20 ? m.original_name.slice(0, 20) + "…" : m.original_name}
                  </a>
                </div>
              </SectionCard>
            ))
          )}
        </>
      )}
    </div>
  );
};

const LectureUploadMaterials = () => {
  const [classes, setClasses] = useState([]);
  const [courseId, setCourseId] = useState("");
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [file, setFile] = useState(null);
  const [posting, setPosting] = useState(false);
  const [error, setError] = useState("");
  const [posted, setPosted] = useState(null);

  useEffect(() => {
    api.myClasses().then(cs => { setClasses(cs); if (cs.length) setCourseId(String(cs[0].course_id)); }).catch(err => setError(err.message));
  }, []);

  const load = () => { if (courseId) api.courseMaterials(courseId).then(setPosted).catch(() => setPosted([])); };
  useEffect(() => { load(); }, [courseId]);

  const handleUpload = async () => {
    if (!title.trim() || !file) { setError("Title and a file are required."); return; }
    setPosting(true);
    setError("");
    try {
      const form = new FormData();
      form.append("courseId", courseId);
      form.append("title", title.trim());
      form.append("description", description.trim());
      form.append("file", file);
      await api.uploadMaterial(form);
      setTitle("");
      setDescription("");
      setFile(null);
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setPosting(false);
    }
  };

  const selectedClass = classes.find(c => String(c.course_id) === String(courseId));

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>Upload Lecture Materials</h2>
      <SectionCard title="Upload New Material">
        <div style={{ marginBottom: 18 }}>
          <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Module</label>
          <select value={courseId} onChange={e => setCourseId(e.target.value)} style={{ width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, background: "#fff" }}>
            {classes.map(c => <option key={c.course_id} value={c.course_id}>{c.code} — {c.name}</option>)}
          </select>
        </div>
        <Field label="Title" placeholder="e.g. Lecture 5 — Sorting Algorithms (Slides)" value={title} onChange={setTitle} />
        <Field label="Description (optional)" type="textarea" placeholder="Any notes for students about this material…" value={description} onChange={setDescription} />
        <div style={{ marginBottom: 18 }}>
          <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>File</label>
          <label style={{ display: "inline-flex", alignItems: "center", gap: 8, background: "#fff", color: COLORS.primary, border: `1.5px solid ${COLORS.primary}`, borderRadius: 8, padding: "10px 16px", fontWeight: 700, fontSize: 13, cursor: "pointer" }}>
            <Icon name="report" size={14} color={COLORS.primary} />
            {file ? file.name.slice(0, 30) : "Choose File (PDF, PPT, DOC, ZIP…)"}
            <input type="file" style={{ display: "none" }} onChange={e => setFile(e.target.files[0])} />
          </label>
        </div>
        {error && <div style={{ color: COLORS.danger, fontSize: 13, marginBottom: 12, fontWeight: 600 }}>{error}</div>}
        <button onClick={handleUpload} disabled={posting} style={{ background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.accent})`, color: "#fff", border: "none", borderRadius: 10, padding: "12px 28px", fontWeight: 700, fontSize: 14, cursor: posting ? "default" : "pointer", opacity: posting ? 0.7 : 1 }}>{posting ? "Uploading…" : "Upload Material"}</button>
      </SectionCard>
      <SectionCard title={selectedClass ? `Materials — ${selectedClass.code}` : "Materials"}>
        {!posted ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading…</div> : posted.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No materials uploaded for this module yet.</div> : (
          <Table headers={["Title", "File", "Uploaded"]} rows={posted.map(m => [m.title, m.original_name, new Date(m.uploaded_at).toLocaleDateString()])} />
        )}
      </SectionCard>
    </div>
  );
};

const LectureWellbeing = () => {
  const [checkins, setCheckins] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api.wellbeingReports().then(setCheckins).catch(err => setError(err.message));
  }, []);

  if (error) return <div style={{ color: COLORS.danger, fontSize: 14 }}>{error}</div>;
  if (!checkins) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading…</div>;

  const oneWeekAgo = Date.now() - 7 * 86400000;
  const thisWeek = checkins.filter(c => new Date(c.created_at).getTime() >= oneWeekAgo);
  const counselingRequests = checkins.filter(c => c.wants_counselor).length;

  const flagged = checkins
    .map(c => {
      let risk = null, concern = "";
      if (c.wants_counselor) { risk = "Medium"; concern = "Requested counselling"; }
      if (c.mood && c.mood <= 2) { risk = "High"; concern = "Low mood reported"; }
      if (c.stress_level && c.stress_level >= 4) { risk = risk === "High" ? "High" : "Medium"; concern = concern ? concern + " · High stress" : "High stress reported"; }
      return risk ? { ...c, risk, concern } : null;
    })
    .filter(Boolean)
    .slice(0, 10);

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>Student Wellbeing</h2>
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 24 }}>
        <StatCard label="Check-ins This Week" value={String(thisWeek.length)} icon="wellbeing" color={COLORS.success} />
        <StatCard label="Students Flagged" value={String(flagged.length)} icon="overview" color={COLORS.danger} />
        <StatCard label="Counselling Requests" value={String(counselingRequests)} icon="counseling" color={COLORS.warning} />
      </div>
      <SectionCard title="Flagged Students">
        {flagged.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No students currently flagged.</div> : flagged.map((s, i) => (
          <div key={i} style={{ background: COLORS.bg, borderRadius: 10, padding: 16, marginBottom: 12, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
            <div>
              <div style={{ fontWeight: 700, fontSize: 14, color: COLORS.textPrimary }}>{s.full_name} <span style={{ fontSize: 12, color: COLORS.textMuted }}>({s.index_number})</span></div>
              <div style={{ fontSize: 13, color: COLORS.textSecondary, marginTop: 4 }}>{s.concern}</div>
            </div>
            <span style={{ fontSize: 11, fontWeight: 700, padding: "3px 9px", borderRadius: 20, background: s.risk === "High" ? COLORS.danger + "18" : COLORS.warning + "18", color: s.risk === "High" ? COLORS.danger : COLORS.warning }}>{s.risk}</span>
          </div>
        ))}
      </SectionCard>
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════════════════════
// ADMIN PORTAL PAGES
// ═══════════════════════════════════════════════════════════════════════════════

const ACTIVITY_ICONS = { registration: "registration", payment: "payment", notice: "post", exam: "exam" };
const ACTIVITY_COLORS = { registration: COLORS.accent, payment: COLORS.success, notice: COLORS.primary, exam: COLORS.warning };

const AdminDashboard = () => {
  const [stats, setStats] = useState(null);
  const [enrollment, setEnrollment] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([api.adminDashboard(), api.allStudents()])
      .then(([dash, students]) => {
        setStats(dash);
        const byBatch = {};
        students.forEach(s => { const b = s.batch || "Unassigned"; byBatch[b] = (byBatch[b] || 0) + 1; });
        const total = students.length || 1;
        setEnrollment(Object.entries(byBatch).map(([batch, count]) => ({ dept: batch, count, pct: Math.round((count / total) * 100) })).sort((a, b) => b.count - a.count));
      })
      .catch(err => setError(err.message));
  }, []);

  if (error) return <div style={{ color: COLORS.danger, fontSize: 14 }}>{error}</div>;
  if (!stats) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading dashboard…</div>;

  const timeAgo = (dateStr) => {
    const diffMs = Date.now() - new Date(dateStr).getTime();
    const mins = Math.floor(diffMs / 60000);
    if (mins < 1) return "just now";
    if (mins < 60) return `${mins}m ago`;
    const hrs = Math.floor(mins / 60);
    if (hrs < 24) return `${hrs}h ago`;
    return `${Math.floor(hrs / 24)}d ago`;
  };

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <h2 style={{ margin: 0, fontSize: 24, fontWeight: 700, color: COLORS.textPrimary }}>Admin Dashboard</h2>
        <p style={{ color: COLORS.textMuted, marginTop: 4 }}>System overview · Academic Year 2024/25</p>
      </div>

      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 24 }}>
        <StatCard label="Total Students" value={String(stats.totalStudents)} icon="students" color={COLORS.accent} />
        <StatCard label="Total Lecturers" value={String(stats.totalLecturers)} icon="classes" color={COLORS.primary} />
        <StatCard label="Total Courses" value={String(stats.totalCourses)} icon="catalog" color={COLORS.success} />
        <StatCard label="Total Batches" value={String(stats.totalBatches)} icon="modules" color={COLORS.accentGold} />
        <StatCard label="Active Semesters" value={String(stats.activeSemesters)} icon="registration" color={COLORS.warning} />
      </div>

      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 24 }}>
        <StatCard label="Overall Attendance" value={`${stats.attendancePct}%`} icon="attendance" color={stats.attendancePct >= 75 ? COLORS.success : COLORS.danger} />
        <StatCard label="Overall Pass Rate" value={`${stats.passRate}%`} icon="results" color={stats.passRate >= 75 ? COLORS.success : COLORS.warning} />
        <StatCard label="Pending Registrations" value={String(stats.pendingRegs)} icon="registration" color={COLORS.warning} />
        <StatCard label="Pending Payments" value={String(stats.pendingPayments)} icon="payment" color={COLORS.danger} />
        <StatCard label="Open Counselling Requests" value={String(stats.openCounseling)} icon="counseling" color={COLORS.success} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 24 }}>
        <SectionCard title="Enrollment by Combination">
          {enrollment.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No students yet.</div> : enrollment.map((d, i) => (
            <div key={i} style={{ marginBottom: 12 }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5, fontSize: 13 }}>
                <span style={{ color: COLORS.textSecondary }}>{d.dept}</span>
                <span style={{ fontWeight: 600, color: COLORS.textPrimary }}>{d.count} students</span>
              </div>
              <div style={{ height: 8, background: COLORS.border, borderRadius: 99 }}>
                <div style={{ width: `${d.pct}%`, height: "100%", borderRadius: 99, background: `linear-gradient(90deg, ${COLORS.primary}, ${COLORS.accent})` }} />
              </div>
            </div>
          ))}
        </SectionCard>

        <SectionCard title="Recent Activity">
          {!stats.recentActivity || stats.recentActivity.length === 0 ? (
            <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No recent activity.</div>
          ) : stats.recentActivity.map((a, i) => (
            <div key={i} style={{ display: "flex", alignItems: "flex-start", gap: 10, padding: "10px 0", borderBottom: i < stats.recentActivity.length - 1 ? `1px solid ${COLORS.border}` : "none" }}>
              <div style={{ width: 28, height: 28, borderRadius: 8, background: (ACTIVITY_COLORS[a.type] || COLORS.primary) + "15", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                <Icon name={ACTIVITY_ICONS[a.type] || "overview"} size={14} color={ACTIVITY_COLORS[a.type] || COLORS.primary} />
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, color: COLORS.textPrimary }}><strong>{a.who}</strong> {a.detail}</div>
                <div style={{ fontSize: 11, color: COLORS.textMuted, marginTop: 2 }}>{timeAgo(a.at)}</div>
              </div>
            </div>
          ))}
        </SectionCard>
      </div>
    </div>
  );
};

const AdminAllStudents = () => {
  const [students, setStudents] = useState(null);
  const [error, setError] = useState("");
  const [search, setSearch] = useState("");
  const [combFilter, setCombFilter] = useState("All Combinations");
  const [yearFilter, setYearFilter] = useState("All Years");
  const [busyId, setBusyId] = useState(null);

  const load = () => api.allStudents().then(setStudents).catch(err => setError(err.message));
  useEffect(() => { load(); }, []);

  const toggleStatus = async (userId, currentStatus) => {
    setBusyId(userId);
    try {
      if (currentStatus === "suspended") await api.activateStudent(userId);
      else await api.suspendStudent(userId);
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  };

  if (error) return <div style={{ color: COLORS.danger, fontSize: 14 }}>{error}</div>;
  if (!students) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading students…</div>;

  const filtered = students.filter(s => {
    const matchesSearch = !search || s.full_name.toLowerCase().includes(search.toLowerCase()) || s.index_number.toLowerCase().includes(search.toLowerCase());
    const matchesComb = combFilter === "All Combinations" || (s.batch && combFilter.startsWith(s.batch));
    const matchesYear = yearFilter === "All Years" || String(s.current_year) === yearFilter.replace("Year ", "");
    return matchesSearch && matchesComb && matchesYear;
  });

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
        <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, margin: 0 }}>All Students</h2>
      </div>
      <SectionCard title="">
        <div style={{ display: "flex", gap: 12, marginBottom: 18 }}>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search students…" style={{ flex: 1, padding: "9px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, outline: "none" }} />
          <select value={combFilter} onChange={e => setCombFilter(e.target.value)} style={{ padding: "9px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14 }}>
            <option>All Combinations</option><option>C1 — Applied Physics</option><option>C2 — Chemical Technology</option><option>C3 — Computer Science</option>
          </select>
          <select value={yearFilter} onChange={e => setYearFilter(e.target.value)} style={{ padding: "9px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14 }}>
            <option>All Years</option><option>Year 1</option><option>Year 2</option><option>Year 3</option><option>Year 4</option>
          </select>
        </div>
        {filtered.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14, padding: "20px 0" }}>No students match your filters.</div> : (
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
            <thead>
              <tr style={{ background: COLORS.bg }}>
                {["Index No.", "Name", "Combination", "Year", "Status", ""].map((h, i) => (
                  <th key={i} style={{ padding: "11px 14px", textAlign: "left", color: COLORS.textSecondary, fontWeight: 600, fontSize: 12, textTransform: "uppercase" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(s => (
                <tr key={s.id} style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                  <td style={{ padding: "12px 14px", color: COLORS.textMuted, fontSize: 13 }}>{s.index_number}</td>
                  <td style={{ padding: "12px 14px", fontWeight: 600 }}>{s.full_name}</td>
                  <td style={{ padding: "12px 14px" }}>{s.batch || "—"}</td>
                  <td style={{ padding: "12px 14px" }}>Year {s.current_year}</td>
                  <td style={{ padding: "12px 14px" }}>
                    <span style={{ padding: "3px 10px", borderRadius: 20, fontSize: 12, fontWeight: 600, background: (s.status === "active" ? COLORS.success : s.status === "suspended" ? COLORS.danger : COLORS.warning) + "18", color: s.status === "active" ? COLORS.success : s.status === "suspended" ? COLORS.danger : COLORS.warning }}>{s.status}</span>
                  </td>
                  <td style={{ padding: "12px 14px" }}>
                    <button disabled={busyId === s.user_id} onClick={() => toggleStatus(s.user_id, s.status)} style={{ background: s.status === "suspended" ? COLORS.success + "18" : COLORS.danger + "18", color: s.status === "suspended" ? COLORS.success : COLORS.danger, border: "none", borderRadius: 6, padding: "5px 12px", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
                      {s.status === "suspended" ? "Activate" : "Suspend"}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </SectionCard>
    </div>
  );
};

const AdminNewRegistrations = () => {
  const [pending, setPending] = useState(null);
  const [error, setError] = useState("");
  const [busyId, setBusyId] = useState(null);

  const load = () => api.pendingRegistrations().then(setPending).catch(err => setError(err.message));
  useEffect(() => { load(); }, []);

  const handle = async (userId, action) => {
    setBusyId(userId);
    try {
      if (action === "activate") await api.activateStudent(userId);
      else await api.suspendStudent(userId);
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setBusyId(null);
    }
  };

  if (error) return <div style={{ color: COLORS.danger, fontSize: 14 }}>{error}</div>;
  if (!pending) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading…</div>;

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>New Registrations</h2>
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 24 }}>
        <StatCard label="Pending Review" value={String(pending.length)} icon="registration" color={COLORS.warning} />
      </div>
      <SectionCard title="New Student Applications">
        {pending.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No pending registrations.</div> : (
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
            <thead>
              <tr style={{ background: COLORS.bg }}>
                {["Index No.", "Name", "Combination", "Year", "Email", ""].map((h, i) => (
                  <th key={i} style={{ padding: "11px 14px", textAlign: "left", color: COLORS.textSecondary, fontWeight: 600, fontSize: 12, textTransform: "uppercase" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {pending.map(s => (
                <tr key={s.id} style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                  <td style={{ padding: "12px 14px", color: COLORS.textMuted, fontSize: 13 }}>{s.index_number}</td>
                  <td style={{ padding: "12px 14px", fontWeight: 600 }}>{s.full_name}</td>
                  <td style={{ padding: "12px 14px" }}>{s.batch || "—"}</td>
                  <td style={{ padding: "12px 14px" }}>Year {s.current_year}</td>
                  <td style={{ padding: "12px 14px", color: COLORS.textMuted, fontSize: 13 }}>{s.email || "—"}</td>
                  <td style={{ padding: "12px 14px" }}>
                    <div style={{ display: "flex", gap: 6 }}>
                      <button disabled={busyId === s.user_id} onClick={() => handle(s.user_id, "activate")} style={{ background: COLORS.success, color: "#fff", border: "none", borderRadius: 6, padding: "5px 12px", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>Approve</button>
                      <button disabled={busyId === s.user_id} onClick={() => handle(s.user_id, "suspend")} style={{ background: COLORS.danger + "18", color: COLORS.danger, border: "none", borderRadius: 6, padding: "5px 12px", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>Reject</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </SectionCard>
    </div>
  );
};

const AdminAttendanceReports = () => {
  const [rows, setRows] = useState(null);
  const [students, setStudents] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([api.attendanceReports(), api.allStudents()])
      .then(([att, studs]) => { setRows(att); setStudents(studs); })
      .catch(err => setError(err.message));
  }, []);

  if (error) return <div style={{ color: COLORS.danger, fontSize: 14 }}>{error}</div>;
  if (!rows) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading attendance reports…</div>;

  const batchByIndex = {};
  students.forEach(s => { batchByIndex[s.index_number] = s.batch; });

  const byBatch = {};
  rows.forEach(r => {
    const batch = batchByIndex[r.index_number] || "Unassigned";
    if (!byBatch[batch]) byBatch[batch] = { present: 0, total: 0 };
    byBatch[batch].total += Number(r.total_sessions);
    byBatch[batch].present += Number(r.present_count);
  });
  const batchSummary = Object.entries(byBatch).map(([batch, v]) => ({ batch, pct: v.total ? Math.round((v.present / v.total) * 100) : 0 }));

  const belowThreshold = rows.filter(r => r.attendance_pct < 75);

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>Attendance Reports</h2>
      <SectionCard title="Attendance Summary by Combination">
        {batchSummary.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No attendance data yet.</div> : batchSummary.map((b, i) => (
          <ProgressBar key={i} value={b.pct} label={b.batch} color={b.pct >= 85 ? COLORS.success : b.pct >= 70 ? COLORS.accentGold : COLORS.warning} />
        ))}
      </SectionCard>
      <SectionCard title="Students Below 75% Attendance">
        {belowThreshold.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No students below the threshold.</div> : (
          <Table
            headers={["Index No.", "Name", "Module", "Attendance %"]}
            rows={belowThreshold.map(r => [r.index_number, r.full_name, `${r.code} — ${r.course_name}`, `${r.attendance_pct}%`])}
            badge
          />
        )}
      </SectionCard>
    </div>
  );
};

const AdminResultsOverview = () => {
  const [rows, setRows] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api.resultsOverview().then(setRows).catch(err => setError(err.message));
  }, []);

  if (error) return <div style={{ color: COLORS.danger, fontSize: 14 }}>{error}</div>;
  if (!rows) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading results…</div>;

  const graded = rows.filter(r => r.grade);
  const passCount = graded.filter(r => r.grade !== "F").length;
  const passRate = graded.length ? ((passCount / graded.length) * 100).toFixed(1) : "0.0";
  const gpaMap = { "A+": 4.0, "A": 4.0, "A-": 3.7, "B+": 3.3, "B": 3.0, "B-": 2.7, "C+": 2.3, "C": 2.0, "C-": 1.7, "D": 1.0, "F": 0.0 };
  const avgGpa = graded.length ? (graded.reduce((s, r) => s + (gpaMap[r.grade] || 0), 0) / graded.length).toFixed(2) : "0.00";
  const distinctions = graded.filter(r => r.grade === "A+" || r.grade === "A").length;

  const gradeCounts = {};
  graded.forEach(r => { gradeCounts[r.grade] = (gradeCounts[r.grade] || 0) + 1; });
  const gradeOrder = ["A+", "A", "A-", "B+", "B", "B-", "C+", "C", "C-", "D", "F"];
  const gradeDist = gradeOrder.filter(g => gradeCounts[g]).map(g => ({ grade: g, pct: Math.round((gradeCounts[g] / graded.length) * 100) }));

  const byModule = {};
  rows.forEach(r => {
    if (!byModule[r.code]) byModule[r.code] = { name: r.course_name, total: 0, pass: 0, sum: 0, graded: 0 };
    byModule[r.code].total++;
    if (r.grade) {
      byModule[r.code].graded++;
      if (r.grade !== "F") byModule[r.code].pass++;
      if (r.marks != null) byModule[r.code].sum += r.marks;
    }
  });

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>Results Overview</h2>
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 24 }}>
        <StatCard label="Pass Rate" value={`${passRate}%`} icon="check" color={COLORS.success} />
        <StatCard label="Average GPA" value={avgGpa} icon="results" color={COLORS.accentGold} />
        <StatCard label="Distinctions (A/A+)" value={String(distinctions)} icon="trend" color={COLORS.accent} />
      </div>
      <SectionCard title="Grade Distribution">
        {gradeDist.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No published results yet.</div> : (
          <div style={{ display: "flex", gap: 8, alignItems: "flex-end", height: 140 }}>
            {gradeDist.map((g, i) => (
              <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 6 }}>
                <div style={{ fontSize: 11, fontWeight: 700, color: COLORS.textSecondary }}>{g.pct}%</div>
                <div style={{ width: "100%", height: `${Math.max(g.pct * 1.2, 4)}px`, background: g.grade === "F" ? COLORS.danger : g.pct > 20 ? COLORS.primary : COLORS.accent, borderRadius: "4px 4px 0 0" }} />
                <div style={{ fontSize: 13, fontWeight: 700, color: COLORS.textSecondary }}>{g.grade}</div>
              </div>
            ))}
          </div>
        )}
      </SectionCard>
      <SectionCard title="Results by Module">
        {Object.keys(byModule).length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No results yet.</div> : (
          <Table
            headers={["Module Code", "Module Name", "Students", "Pass Rate", "Avg Mark"]}
            rows={Object.entries(byModule).map(([code, m]) => [
              code, m.name, String(m.total),
              m.graded ? `${Math.round((m.pass / m.graded) * 100)}%` : "—",
              m.graded ? (m.sum / m.graded).toFixed(1) : "—",
            ])}
          />
        )}
      </SectionCard>
    </div>
  );
};

const AdminExamApps = () => {
  const [apps, setApps] = useState(null);
  const [error, setError] = useState("");
  const [updating, setUpdating] = useState(null);

  const load = () => api.allExamApps().then(setApps).catch(err => setError(err.message));
  useEffect(() => { load(); }, []);

  const setStatus = async (id, status) => {
    setUpdating(id);
    try {
      await api.updateExamStatus(id, status);
      setApps(rows => rows.map(a => a.id === id ? { ...a, status } : a));
    } catch (err) {
      setError(err.message);
    } finally {
      setUpdating(null);
    }
  };

  if (error) return <div style={{ color: COLORS.danger, fontSize: 14 }}>{error}</div>;
  if (!apps) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading applications…</div>;

  const pending = apps.filter(a => a.status !== "approved" && a.status !== "rejected").length;
  const approved = apps.filter(a => a.status === "approved").length;
  const rejected = apps.filter(a => a.status === "rejected").length;

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>Exam Applications</h2>
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 24 }}>
        <StatCard label="Total Applications" value={String(apps.length)} icon="exam" color={COLORS.accent} />
        <StatCard label="Pending Review" value={String(pending)} icon="overview" color={COLORS.warning} />
        <StatCard label="Approved" value={String(approved)} icon="check" color={COLORS.success} />
        <StatCard label="Rejected" value={String(rejected)} icon="overview" color={COLORS.danger} />
      </div>
      <SectionCard title="Application Management">
        {apps.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No applications yet.</div> : (
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
            <thead>
              <tr style={{ background: COLORS.bg }}>
                {["Index No.", "Name", "Type", "Year/Sem", "Fee", "Status", ""].map((h, i) => (
                  <th key={i} style={{ padding: "11px 14px", textAlign: "left", color: COLORS.textSecondary, fontWeight: 600, fontSize: 12, textTransform: "uppercase" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {apps.map(a => (
                <tr key={a.id} style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                  <td style={{ padding: "12px 14px", color: COLORS.textMuted, fontSize: 13 }}>{a.index_number}</td>
                  <td style={{ padding: "12px 14px", fontWeight: 600 }}>{a.full_name}</td>
                  <td style={{ padding: "12px 14px" }}>{EXAM_TYPES.find(t => t.id === a.exam_type)?.label || a.exam_type}</td>
                  <td style={{ padding: "12px 14px" }}>Y{a.year}/S{a.semester}</td>
                  <td style={{ padding: "12px 14px" }}>{a.total_fee > 0 ? `LKR ${Number(a.total_fee).toLocaleString()}` : "Free"}</td>
                  <td style={{ padding: "12px 14px" }}>
                    <span style={{ padding: "3px 10px", borderRadius: 20, fontSize: 12, fontWeight: 600, background: (a.status === "approved" ? COLORS.success : a.status === "rejected" ? COLORS.danger : COLORS.warning) + "18", color: a.status === "approved" ? COLORS.success : a.status === "rejected" ? COLORS.danger : COLORS.warning }}>{a.status}</span>
                  </td>
                  <td style={{ padding: "12px 14px" }}>
                    {a.status !== "approved" && a.status !== "rejected" && (
                      <div style={{ display: "flex", gap: 6 }}>
                        <button disabled={updating === a.id} onClick={() => setStatus(a.id, "approved")} style={{ background: COLORS.success, color: "#fff", border: "none", borderRadius: 6, padding: "5px 10px", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>Approve</button>
                        <button disabled={updating === a.id} onClick={() => setStatus(a.id, "rejected")} style={{ background: COLORS.danger + "18", color: COLORS.danger, border: "none", borderRadius: 6, padding: "5px 10px", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>Reject</button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </SectionCard>
    </div>
  );
};

// ── Course data from FAS-SHB-2023-2024 handbook ──────────────────────────────
const COURSE_DATA = {
  "Year 1": {
    color: "#1E3A5F",
    semesters: [
      {
        label: "Semester I",
        minCredits: "C1:18, C2:18, C3:18",
        courses: [
          { code: "PST 11201", name: "Mechanics and Properties of Matter", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST 11202", name: "Introduction to Electricity and Magnetism", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST 11103", name: "Physics Laboratory 1-I", cre: 1, c1: "C", c2: "C", c3: "C" },
          { code: "PST 11204", name: "General Chemistry", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST 11205", name: "Fundamentals of Organic Chemistry", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST 11106", name: "Inorganic Chemistry Laboratory I", cre: 1, c1: "C", c2: "C", c3: "C" },
          { code: "PST 11107", name: "Structured Programming", cre: 1, c1: "C", c2: "C", c3: "C" },
          { code: "PST 11208", name: "Computer Hardware and Software", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST 11109", name: "Computer Laboratory 1-I", cre: 1, c1: "C", c2: "C", c3: "C" },
          { code: "PST 11210", name: "Calculus and Differential Equations", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST-EGP-1101", name: "General English I (Non-GPA)", cre: 2, c1: "C", c2: "C", c3: "C" },
        ],
      },
      {
        label: "Semester II",
        minCredits: "C1:18, C2:18, C3:18",
        courses: [
          { code: "PST 12201", name: "Physics of Heat and Waves", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST 12102", name: "Semi-Conductor Physics", cre: 1, c1: "C", c2: "C", c3: "C" },
          { code: "PST 12103", name: "AC Theory & Circuits", cre: 1, c1: "C", c2: "C", c3: "C" },
          { code: "PST 12104", name: "Physics Laboratory 1-II", cre: 1, c1: "C", c2: "C", c3: "C" },
          { code: "PST 12205", name: "Fundamentals of Physical Chemistry", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST 12206", name: "Fundamentals of Analytical Chemistry", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST 12107", name: "Organic Chemistry Laboratory I", cre: 1, c1: "C", c2: "C", c3: "C" },
          { code: "PST 12108", name: "Object Oriented Programming", cre: 1, c1: "C", c2: "C", c3: "C" },
          { code: "PST 12209", name: "Fundamentals of Statistics", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST 12110", name: "Computer Laboratory 1-II", cre: 1, c1: "C", c2: "C", c3: "C" },
          { code: "PST 12211", name: "Database Management Systems", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST-EGP-1201", name: "General English II (Non-GPA)", cre: 2, c1: "C", c2: "C", c3: "C" },
        ],
      },
    ],
  },
  "Year 2": {
    color: "#2D6A4F",
    semesters: [
      {
        label: "Semester I",
        minCredits: "C1:19, C2:20, C3:19",
        courses: [
          { code: "PST 21201", name: "Electronics", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST 21202", name: "Geometrical and Physical Optics", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST 21103", name: "Physics Laboratory 2-I", cre: 1, c1: "C", c2: "C", c3: "C" },
          { code: "PST 21204", name: "Organic Chemistry", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST 21205", name: "Industrial Chemistry and Technology I (Organic)", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST 21106", name: "Organic Chemistry Laboratory II", cre: 1, c1: "C", c2: "C", c3: "C" },
          { code: "PST 21207", name: "Data Structures & Algorithms", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST 21208", name: "Computer Architecture and Assembly Language", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST 21209", name: "Statistics for Experimental Analysis", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST 21110", name: "Computer Laboratory 2-I", cre: 1, c1: "C", c2: "C", c3: "C" },
          { code: "PST 21111", name: "Physical Chemistry Laboratory I", cre: 1, c1: "E", c2: "C", c3: "E" },
          { code: "PST-EAP-2101", name: "Academic English I (Non-GPA)", cre: 2, c1: "C", c2: "C", c3: "C" },
        ],
      },
      {
        label: "Semester II",
        minCredits: "C1:22, C2:22, C3:21",
        courses: [
          { code: "PST 22201", name: "Physics of Electromagnetic Radiation and Introduction to the Laser", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST 22202", name: "Quantum Physics, Atomic & Nuclear Physics", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST 22103", name: "Physics Laboratory 2-II", cre: 1, c1: "C", c2: "C", c3: "C" },
          { code: "PST 22204", name: "Chemistry of Elements", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST 22205", name: "Physical Chemistry", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST 22106", name: "Inorganic Chemistry Laboratory II", cre: 1, c1: "C", c2: "C", c3: "C" },
          { code: "PST 22107", name: "Analytical Chemistry Laboratory I", cre: 1, c1: "E", c2: "C", c3: "E" },
          { code: "PST 22208", name: "Software Engineering", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST 22209", name: "Statistical Methodology", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST 22110", name: "Computer Laboratory 2-II", cre: 1, c1: "C", c2: "C", c3: "C" },
          { code: "PST 22211", name: "Operating Systems", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST 22112", name: "Leadership and Communication", cre: 1, c1: "E", c2: "E", c3: "E" },
          { code: "PST 22213", name: "Biology for Physical Sciences", cre: 2, c1: "E", c2: "E", c3: "E" },
          { code: "PST 22114", name: "Soft Skill Development", cre: 1, c1: "E", c2: "E", c3: "E" },
          { code: "PST 22215", name: "Mathematical Methods", cre: 2, c1: "C", c2: "E", c3: "E" },
          { code: "PST 22116", name: "Introduction to Astronomy", cre: 1, c1: "C", c2: "E", c3: "E" },
          { code: "PST 22217", name: "Industrial Metrology", cre: 2, c1: "E", c2: "E", c3: "E" },
          { code: "PST 22218", name: "Management Information Systems", cre: 2, c1: "E", c2: "E", c3: "C" },
          { code: "PST 22219", name: "Molecular Spectroscopy", cre: 2, c1: "E", c2: "C", c3: "E" },
          { code: "PST-EAP-2201", name: "Academic English II (Non-GPA)", cre: 2, c1: "C", c2: "C", c3: "C" },
        ],
      },
    ],
  },
  "Year 3": {
    color: "#7B2D8B",
    semesters: [
      {
        label: "Semester I",
        minCredits: "C1: 17 (Gen.Physics) / 19 (Sp.App.Physics), C2: 14, C3: 15",
        courses: [
          { code: "PST 31201", name: "Solid State Physics", cre: 2, c1: "C", c2: "", c3: "" },
          { code: "PST 31202", name: "Nuclear Physics & Applications", cre: 2, c1: "C", c2: "", c3: "" },
          { code: "PST 31203", name: "Quantum Mechanics", cre: 2, c1: "C", c2: "", c3: "" },
          { code: "PST 31104", name: "Material Physics", cre: 1, c1: "C", c2: "", c3: "" },
          { code: "PST 31205", name: "Special Relativity (General — Physics)", cre: 2, c1: "C", c2: "", c3: "" },
          { code: "PST 31105", name: "Special Relativity (Special — Applied Physics)", cre: 2, c1: "C", c2: "", c3: "" },
          { code: "PST 31206", name: "Optical Fiber & Telecommunication", cre: 2, c1: "C", c2: "", c3: "" },
          { code: "PST 31107", name: "Introduction to Nanotechnology", cre: 1, c1: "C", c2: "E", c3: "" },
          { code: "PST 31108", name: "Physics Laboratory 3-I", cre: 1, c1: "C", c2: "", c3: "" },
          { code: "PST 31209", name: "The Origin and Evolution of the Universe", cre: 2, c1: "C", c2: "", c3: "" },
          { code: "PST 31210", name: "Multimedia and Hypermedia Systems Development", cre: 2, c1: "E", c2: "", c3: "C" },
          { code: "PST 31211", name: "Mathematical Programming", cre: 2, c1: "C", c2: "E", c3: "E" },
          { code: "PST 31212", name: "Numerical Methods", cre: 2, c1: "E", c2: "E", c3: "E" },
          { code: "PST 31213", name: "Economics", cre: 2, c1: "E", c2: "E", c3: "" },
          { code: "PST 31014", name: "Industrial Visit", cre: 0, c1: "C", c2: "C", c3: "C" },
          { code: "PST-EBP-3101", name: "Business English (Non-GPA)", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST 31216", name: "Biochemistry-I", cre: 2, c1: "", c2: "C", c3: "" },
          { code: "PST 31217", name: "Electroanalytical Techniques", cre: 2, c1: "", c2: "C", c3: "" },
          { code: "PST 31218", name: "Industrial Chemistry and Technology II (Inorganic)", cre: 2, c1: "", c2: "C", c3: "" },
          { code: "PST 31219", name: "Environmental Chemistry", cre: 2, c1: "", c2: "C", c3: "" },
          { code: "PST 31120", name: "Coordination Chemistry", cre: 1, c1: "", c2: "C", c3: "" },
          { code: "PST 31121", name: "Laboratory Quality Control and Assurance", cre: 1, c1: "", c2: "C", c3: "" },
          { code: "PST 31122", name: "Physical Chemistry Laboratory II", cre: 1, c1: "", c2: "C", c3: "" },
          { code: "PST 31123", name: "Analytical Chemistry Laboratory II", cre: 1, c1: "", c2: "C", c3: "" },
          { code: "PST 31215", name: "Agile Software Development", cre: 2, c1: "", c2: "", c3: "E" },
          { code: "PST 31224", name: "Artificial Intelligence & Expert Systems", cre: 2, c1: "", c2: "", c3: "C" },
          { code: "PST 31225", name: "Software Project Management", cre: 2, c1: "", c2: "", c3: "C" },
          { code: "PST 31226", name: "Software Quality Assurances", cre: 2, c1: "", c2: "", c3: "C" },
          { code: "PST 31227", name: "Object Oriented Analysis and Design", cre: 2, c1: "", c2: "", c3: "C" },
          { code: "PST 31128", name: "Computer Laboratory 3-I", cre: 1, c1: "", c2: "", c3: "C" },
          { code: "PST 31229", name: "Advanced Database Management Systems", cre: 2, c1: "", c2: "", c3: "C" },
          { code: "PST 31230", name: "Social and Professional Issues in Computing", cre: 2, c1: "", c2: "", c3: "E" },
        ],
      },
      {
        label: "Semester II",
        minCredits: "C1(App.Phy):12, C2(Chem.Tech):13, C3(Com.Sci&Tech):13 — plus 8cr. Gen. degree exit project",
        courses: [
          { code: "PST 32801", name: "Project Work (Industrial Exposure): B.Sc. Thesis — Major in Applied Physics", cre: 8, c1: "C", c2: "", c3: "" },
          { code: "PST 32802", name: "Project Work (Industrial Exposure): B.Sc. Thesis — Major in Chemical Technology", cre: 8, c1: "", c2: "C", c3: "" },
          { code: "PST 32803", name: "Project Work (Industrial Exposure): B.Sc. Thesis — Major in Computer Science & Technology", cre: 8, c1: "", c2: "", c3: "C" },
          { code: "PST 32201", name: "Statistical Physics", cre: 2, c1: "C", c2: "", c3: "" },
          { code: "PST 32102", name: "Interaction of Radiation with Matter", cre: 1, c1: "C", c2: "", c3: "" },
          { code: "PST 32203", name: "Atmospheric Physics & Applications", cre: 2, c1: "C", c2: "", c3: "" },
          { code: "PST 32104", name: "Advanced Electronics", cre: 1, c1: "C", c2: "", c3: "" },
          { code: "PST 32205", name: "Solid State Devices", cre: 2, c1: "C", c2: "", c3: "" },
          { code: "PST 32206", name: "Astrophysics", cre: 2, c1: "C", c2: "", c3: "" },
          { code: "PST 32207", name: "Atomic and Molecular Spectroscopy", cre: 2, c1: "E", c2: "", c3: "" },
          { code: "PST 32108", name: "Current Topics in Physics", cre: 1, c1: "C", c2: "", c3: "" },
          { code: "PST 32109", name: "Human Resource Management", cre: 1, c1: "E", c2: "E", c3: "E" },
          { code: "PST 32210", name: "Statistics in Quality Control", cre: 2, c1: "E", c2: "E", c3: "E" },
          { code: "PST 32111", name: "Physics Laboratory 3-II", cre: 1, c1: "C", c2: "", c3: "" },
          { code: "PST 32212", name: "Graph Theory", cre: 2, c1: "E", c2: "", c3: "E" },
          { code: "PST 32213", name: "Resource Efficient and Cleaner Production", cre: 2, c1: "E", c2: "E", c3: "" },
          { code: "PST 32214", name: "Chemistry of Drug Design and Drug Action", cre: 2, c1: "", c2: "C", c3: "" },
          { code: "PST 32215", name: "Polymer Chemistry and Technology", cre: 2, c1: "", c2: "C", c3: "" },
          { code: "PST 32216", name: "Surface and Colloid Chemistry", cre: 2, c1: "", c2: "C", c3: "" },
          { code: "PST 32217", name: "Biochemistry II", cre: 2, c1: "", c2: "C", c3: "" },
          { code: "PST 32118", name: "Advanced Organic Chemistry", cre: 1, c1: "", c2: "C", c3: "" },
          { code: "PST 32219", name: "Introduction to Organic Electronics", cre: 2, c1: "", c2: "E", c3: "" },
          { code: "PST 32220", name: "Structures and Properties of Solids", cre: 2, c1: "", c2: "C", c3: "" },
          { code: "PST 32121", name: "Advanced Inorganic Chemistry Laboratory", cre: 1, c1: "", c2: "C", c3: "" },
          { code: "PST 32122", name: "Biochemistry Laboratory", cre: 1, c1: "", c2: "C", c3: "" },
          { code: "PST 32223", name: "Organometallic Chemistry", cre: 2, c1: "", c2: "E", c3: "" },
          { code: "PST 32224", name: "Artificial Neural Networks", cre: 2, c1: "", c2: "", c3: "C" },
          { code: "PST 32225", name: "Digital Image Processing", cre: 2, c1: "", c2: "", c3: "C" },
          { code: "PST 32226", name: "Data Mining and Applications", cre: 2, c1: "", c2: "", c3: "C" },
          { code: "PST 32227", name: "Data Communication and Computer Networks", cre: 2, c1: "", c2: "", c3: "C" },
          { code: "PST 32228", name: "Computer Graphics & Visualization", cre: 2, c1: "", c2: "", c3: "C" },
          { code: "PST 32229", name: "Project in Computer Science and Technology (Mini Project)", cre: 2, c1: "", c2: "", c3: "C" },
          { code: "PST 32130", name: "Computer Laboratory 3-II", cre: 1, c1: "", c2: "", c3: "C" },
          { code: "PST 32231", name: "Human Computer Interactions", cre: 2, c1: "", c2: "", c3: "E" },
          { code: "PST 32232", name: "Bioinformatics", cre: 2, c1: "", c2: "", c3: "E" },
          { code: "PST 32133", name: "Current Topics in Computer Technology", cre: 1, c1: "", c2: "", c3: "E" },
        ],
      },
    ],
  },
  "Year 4": {
    color: "#B5451B",
    semesters: [
      {
        label: "Semester I — B.Sc. Special (Honours)",
        minCredits: "C1(App.Phy):19, C2(Chem.Tech):14, C3(Com.Sci&Tech):10",
        courses: [
          { code: "PST 41201", name: "Research Methodology and Scientific Communication", cre: 2, c1: "C", c2: "C", c3: "C" },
          { code: "PST 41202", name: "Computational Physics", cre: 2, c1: "C", c2: "", c3: "" },
          { code: "PST 41203", name: "Robotics", cre: 2, c1: "E", c2: "", c3: "E" },
          { code: "PST 41204", name: "Remote Sensing & GIS", cre: 2, c1: "C", c2: "", c3: "" },
          { code: "PST 41205", name: "Geophysics", cre: 2, c1: "C", c2: "", c3: "" },
          { code: "PST 41206", name: "Medical and Bio Physics", cre: 2, c1: "C", c2: "", c3: "" },
          { code: "PST 41207", name: "Advanced Nanotechnology", cre: 2, c1: "E", c2: "E", c3: "" },
          { code: "PST 41208", name: "Data Acquisition and Signal Processing Methods", cre: 2, c1: "C", c2: "", c3: "" },
          { code: "PST 41209", name: "Advanced Laser Physics", cre: 2, c1: "E", c2: "", c3: "" },
          { code: "PST 41210", name: "Automation", cre: 2, c1: "E", c2: "", c3: "" },
          { code: "PST 41211", name: "Astronomical Instruments and Data Reduction & Analysis", cre: 2, c1: "C", c2: "", c3: "" },
          { code: "PST 41212", name: "Electrochemical Power Conversion", cre: 2, c1: "E", c2: "E", c3: "" },
          { code: "PST 41013", name: "Literature Search Seminar in Applied Physics", cre: 1, c1: "C", c2: "", c3: "" },
          { code: "PST 41014", name: "Independent Research / Project in Applied Physics", cre: 2, c1: "C", c2: "", c3: "" },
          { code: "PST 41215", name: "Industrial Management", cre: 2, c1: "E", c2: "E", c3: "E" },
          { code: "PST 41216", name: "Classical Mechanics", cre: 2, c1: "C", c2: "", c3: "" },
          { code: "PST 41235", name: "Critical Thinking", cre: 2, c1: "E", c2: "E", c3: "E" },
          { code: "PST 41217", name: "Natural Products Chemistry", cre: 2, c1: "", c2: "C", c3: "" },
          { code: "PST 41218", name: "Biotechnology", cre: 2, c1: "", c2: "C", c3: "" },
          { code: "PST 41219", name: "Advanced Solid State Chemistry", cre: 2, c1: "", c2: "C", c3: "" },
          { code: "PST 41120", name: "Bioinorganic Chemistry", cre: 1, c1: "", c2: "C", c3: "" },
          { code: "PST 41221", name: "Instrumental Analysis", cre: 2, c1: "", c2: "C", c3: "" },
          { code: "PST 41222", name: "Applied Molecular Modeling", cre: 2, c1: "", c2: "E", c3: "" },
          { code: "PST 41223", name: "State of Matter", cre: 2, c1: "", c2: "E", c3: "" },
          { code: "PST 41124", name: "Literature Search Seminar in Chemical Technology", cre: 1, c1: "", c2: "C", c3: "" },
          { code: "PST 41225", name: "Independent Research / Project in Chemical Technology", cre: 2, c1: "", c2: "C", c3: "" },
          { code: "PST 41226", name: "Computer Applications in Instrumentation", cre: 2, c1: "", c2: "E", c3: "" },
          { code: "PST 41227", name: "Web Services", cre: 2, c1: "", c2: "", c3: "C" },
          { code: "PST 41228", name: "Computer System Security", cre: 2, c1: "", c2: "", c3: "C" },
          { code: "PST 41229", name: "Advanced Computer Networks", cre: 2, c1: "", c2: "", c3: "C" },
          { code: "PST 41230", name: "Internet of Things (IoT)", cre: 2, c1: "", c2: "", c3: "E" },
          { code: "PST 41231", name: "Natural Language Processing", cre: 2, c1: "", c2: "", c3: "E" },
          { code: "PST 41232", name: "Cloud Computing", cre: 2, c1: "", c2: "", c3: "C" },
          { code: "PST 41233", name: "Business Process Management Systems", cre: 2, c1: "", c2: "", c3: "E" },
          { code: "PST 41234", name: "Mobile Computing", cre: 2, c1: "", c2: "", c3: "E" },
        ],
      },
      {
        label: "Semester II — Project / Industrial Training",
        minCredits: "C1(App.Phy):11, C2(Chem.Tech):8, C3(Com.Sci&Tech):14",
        courses: [
          { code: "PST 42801", name: "Project Work (Industrial Exposure): B.Sc. Thesis in Applied Physics", cre: 8, c1: "C", c2: "", c3: "" },
          { code: "PST 42102", name: "Literature Search Seminar in Applied Physics", cre: 1, c1: "C", c2: "", c3: "" },
          { code: "PST 42203", name: "Independent Research / Project in Applied Physics", cre: 2, c1: "C", c2: "", c3: "" },
          { code: "PST 42804", name: "Project Work (Industrial Exposure): B.Sc. Thesis in Chemical Technology", cre: 8, c1: "", c2: "C", c3: "" },
          { code: "PST 42803", name: "Project: B.Sc. Thesis in Computer Science and Technology", cre: 8, c1: "", c2: "", c3: "C" },
          { code: "PST 42606", name: "Industrial Training", cre: 6, c1: "", c2: "", c3: "C" },
        ],
      },
    ],
  },
};

const AdminCourseCatalog = ({ portal }) => {
  const [activeYear, setActiveYear] = useState("Year 1");
  const [activeSem, setActiveSem] = useState(0);
  const [search, setSearch] = useState("");
  const [track, setTrack] = useState(""); // "" | "c1" | "c2" | "c3" — only relevant for Year 3/4
  const typeColor = { C: { bg: COLORS.success + "18", text: COLORS.success }, E: { bg: COLORS.accentGold + "18", text: "#B45309" }, NC: { bg: COLORS.accent + "15", text: COLORS.accent }, "": { bg: COLORS.border, text: COLORS.textMuted } };
  const TRACKS = [
    { key: "c1", label: "Physics", sub: "Applied Physics", col: "C1 (Phy)" },
    { key: "c2", label: "Chemistry", sub: "Chemical Technology", col: "C2 (Chem)" },
    { key: "c3", label: "Computer Science", sub: "Computer Science & Technology", col: "C3 (Com)" },
  ];

  const yearData = COURSE_DATA[activeYear];
  const semData = yearData.semesters[activeSem];
  const needsTrack = activeYear === "Year 3" || activeYear === "Year 4";

  const bySearch = semData.courses.filter(c =>
    c.code.toLowerCase().includes(search.toLowerCase()) ||
    c.name.toLowerCase().includes(search.toLowerCase())
  );
  // For Year 3/4, only show courses that are compulsory or elective for the chosen track.
  const filtered = needsTrack && track ? bySearch.filter(c => c[track]) : needsTrack ? [] : bySearch;

  return (
    <div>
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 24 }}>
        <div>
          <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, margin: 0 }}>Course Catalog</h2>
          <p style={{ color: COLORS.textMuted, marginTop: 4, fontSize: 13 }}>FAS-SHB-2023-2024 · Physical Sciences</p>
        </div>
        {portal === "admin" && (
          <button style={{ background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.primaryLight})`, color: "#fff", border: "none", borderRadius: 10, padding: "10px 22px", fontWeight: 700, fontSize: 14, cursor: "pointer" }}>+ Add Course</button>
        )}
      </div>

      {/* Year tabs */}
      <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
        {Object.keys(COURSE_DATA).map((yr) => (
          <button key={yr} onClick={() => { setActiveYear(yr); setActiveSem(0); setSearch(""); setTrack(""); }}
            style={{ padding: "9px 22px", borderRadius: 10, border: `2px solid ${activeYear === yr ? COURSE_DATA[yr].color : COLORS.border}`, background: activeYear === yr ? COURSE_DATA[yr].color : "#fff", color: activeYear === yr ? "#fff" : COLORS.textSecondary, fontWeight: 700, fontSize: 14, cursor: "pointer", transition: "all 0.2s" }}>
            {yr}
          </button>
        ))}
      </div>

      {/* Semester tabs */}
      <div style={{ display: "flex", gap: 8, marginBottom: 20, flexWrap: "wrap" }}>
        {yearData.semesters.map((sem, i) => (
          <button key={i} onClick={() => { setActiveSem(i); setSearch(""); }}
            style={{ padding: "7px 16px", borderRadius: 8, border: `1px solid ${activeSem === i ? yearData.color : COLORS.border}`, background: activeSem === i ? yearData.color + "15" : "#fff", color: activeSem === i ? yearData.color : COLORS.textSecondary, fontWeight: activeSem === i ? 700 : 500, fontSize: 13, cursor: "pointer" }}>
            {sem.label}
          </button>
        ))}
      </div>

      {/* Special subject (track) picker — Year 3/4 only */}
      {needsTrack && (
        <div style={{ marginBottom: 20 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 10 }}>Special Subject — pick one to see its modules</div>
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            {TRACKS.map(t => (
              <div key={t.key} onClick={() => setTrack(t.key)} style={{ flex: "1 1 200px", cursor: "pointer", padding: "12px 16px", borderRadius: 12, border: `2px solid ${track === t.key ? yearData.color : COLORS.border}`, background: track === t.key ? yearData.color + "10" : "#fff" }}>
                <div style={{ fontWeight: 700, fontSize: 14, color: COLORS.textPrimary }}>{t.label}</div>
                <div style={{ fontSize: 12, color: COLORS.textMuted, marginTop: 2 }}>{t.sub}</div>
              </div>
            ))}
          </div>
          {!track && (
            <div style={{ marginTop: 12, fontSize: 12.5, color: COLORS.warning, display: "flex", alignItems: "center", gap: 6 }}>
              <Icon name="alert" size={13} color={COLORS.warning} /> Year 3 and 4 split into three special subjects — pick one to see its modules instead of everything mixed together.
            </div>
          )}
        </div>
      )}

      {/* Info bar */}
      <div style={{ background: yearData.color + "10", border: `1px solid ${yearData.color}30`, borderRadius: 10, padding: "12px 18px", marginBottom: 20, display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 10 }}>
        <div>
          <span style={{ fontWeight: 700, color: yearData.color, fontSize: 14 }}>{semData.label}</span>
          <span style={{ fontSize: 13, color: COLORS.textSecondary, marginLeft: 12 }}>Minimum Credits: {semData.minCredits}</span>
        </div>
        <div style={{ display: "flex", gap: 16, fontSize: 12 }}>
          {[["C", "Compulsory", COLORS.success], ["E", "Elective", "#B45309"], ["NC", "Non-Credit", COLORS.accent]].map(([k, v, c]) => (
            <span key={k} style={{ display: "flex", alignItems: "center", gap: 5, color: COLORS.textSecondary }}>
              <span style={{ width: 18, height: 18, borderRadius: 4, background: c + "20", border: `1px solid ${c}40`, display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 700, color: c }}>{k}</span>
              {v}
            </span>
          ))}
        </div>
      </div>

      {/* Search */}
      <div style={{ marginBottom: 16 }}>
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by code or course name…"
          style={{ width: "100%", padding: "10px 16px", borderRadius: 10, border: `1px solid ${COLORS.border}`, fontSize: 14, outline: "none", boxSizing: "border-box" }} />
      </div>

      {/* Table */}
      {needsTrack && !track ? (
        <div style={{ background: COLORS.card, borderRadius: 14, boxShadow: "0 2px 12px rgba(30,58,95,0.08)", padding: 48, textAlign: "center", color: COLORS.textMuted, fontSize: 14 }}>
          Pick a special subject above to see its modules.
        </div>
      ) : (
        <div style={{ background: COLORS.card, borderRadius: 14, boxShadow: "0 2px 12px rgba(30,58,95,0.08)", overflow: "hidden" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
            <thead>
              <tr style={{ background: yearData.color }}>
                {(needsTrack ? ["Code", "Course Name", "Credits", "Status"] : ["Code", "Course Name", "Credits", "C1 (Phy)", "C2 (Chem)", "C3 (Com)"]).map((h, i) => (
                  <th key={i} style={{ padding: "12px 14px", textAlign: "left", color: "#fff", fontWeight: 600, fontSize: 12, textTransform: "uppercase", letterSpacing: "0.04em", whiteSpace: "nowrap" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((c, i) => (
                <tr key={i} style={{ borderBottom: `1px solid ${COLORS.border}`, background: i % 2 === 0 ? "#fff" : COLORS.bg + "80" }}>
                  <td style={{ padding: "11px 14px", fontWeight: 700, color: yearData.color, whiteSpace: "nowrap", fontSize: 13 }}>{c.code}</td>
                  <td style={{ padding: "11px 14px", color: COLORS.textPrimary, lineHeight: 1.4 }}>{c.name}</td>
                  <td style={{ padding: "11px 14px", fontWeight: 700, color: COLORS.textPrimary, textAlign: "center" }}>{c.cre}</td>
                  {(needsTrack ? [c[track]] : [c.c1, c.c2, c.c3]).map((val, j) => (
                    <td key={j} style={{ padding: "11px 14px", textAlign: "center" }}>
                      {val ? (
                        <span style={{ display: "inline-flex", alignItems: "center", justifyContent: "center", width: 28, height: 24, borderRadius: 6, fontSize: 11, fontWeight: 700, background: (typeColor[val] || typeColor[""]).bg, color: (typeColor[val] || typeColor[""]).text, border: `1px solid ${(typeColor[val] || typeColor[""]).text}30` }}>{val}</span>
                      ) : <span style={{ color: COLORS.border }}>—</span>}
                    </td>
                  ))}
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td colSpan={needsTrack ? 4 : 6} style={{ padding: 32, textAlign: "center", color: COLORS.textMuted }}>No courses match your search.</td></tr>
              )}
            </tbody>
          </table>
          <div style={{ padding: "12px 16px", borderTop: `1px solid ${COLORS.border}`, fontSize: 13, color: COLORS.textMuted, display: "flex", justifyContent: "space-between" }}>
            <span>Showing {filtered.length} of {needsTrack ? bySearch.filter(c => c[track]).length : semData.courses.length} courses</span>
            <span style={{ color: yearData.color, fontWeight: 600 }}>Total credits (without electives): {filtered.filter(c => c.cre > 0 && (needsTrack ? c[track] === "C" : (c.c1 === "C" || c.c2 === "C" || c.c3 === "C"))).reduce((s, c) => s + c.cre, 0)}</span>
          </div>
        </div>
      )}
    </div>
  );
};

const AdminPaymentManagement = () => {
  const [payments, setPayments] = useState(null);
  const [error, setError] = useState("");
  const [updating, setUpdating] = useState(null);

  const load = () => api.allPayments().then(setPayments).catch(err => setError(err.message));
  useEffect(() => { load(); }, []);

  const setStatus = async (id, status) => {
    setUpdating(id);
    try {
      await api.verifyPayment(id, status);
      setPayments(rows => rows.map(p => p.id === id ? { ...p, status } : p));
    } catch (err) {
      setError(err.message);
    } finally {
      setUpdating(null);
    }
  };

  if (error) return <div style={{ color: COLORS.danger, fontSize: 14 }}>{error}</div>;
  if (!payments) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading payments…</div>;

  const revenue = payments.filter(p => p.status === "verified").reduce((s, p) => s + Number(p.amount || 0), 0);
  const outstanding = payments.filter(p => p.status === "pending").reduce((s, p) => s + Number(p.amount || 0), 0);

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>Payment Management</h2>
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 24 }}>
        <StatCard label="Revenue (Verified)" value={`LKR ${revenue.toLocaleString()}`} icon="trend" color={COLORS.success} />
        <StatCard label="Outstanding (Pending Slips)" value={`LKR ${outstanding.toLocaleString()}`} icon="payment" color={COLORS.danger} />
        <StatCard label="Transactions" value={String(payments.length)} icon="overview" color={COLORS.accent} />
      </div>
      <SectionCard title="Recent Transactions">
        {payments.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No transactions yet.</div> : (
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
            <thead>
              <tr style={{ background: COLORS.bg }}>
                {["Index No.", "Student", "Purpose", "Method", "Amount", "Date", "Status", ""].map((h, i) => (
                  <th key={i} style={{ padding: "11px 14px", textAlign: "left", color: COLORS.textSecondary, fontWeight: 600, fontSize: 12, textTransform: "uppercase" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {payments.map(p => (
                <tr key={p.id} style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                  <td style={{ padding: "12px 14px", color: COLORS.textMuted, fontSize: 13 }}>{p.index_number}</td>
                  <td style={{ padding: "12px 14px", fontWeight: 600 }}>{p.full_name}</td>
                  <td style={{ padding: "12px 14px" }}>{p.purpose.replace(/_/g, " ")}</td>
                  <td style={{ padding: "12px 14px" }}>{p.method === "bank_slip" ? "Bank Slip" : "Card"}</td>
                  <td style={{ padding: "12px 14px" }}>LKR {Number(p.amount).toLocaleString()}</td>
                  <td style={{ padding: "12px 14px", color: COLORS.textMuted, fontSize: 13 }}>{new Date(p.created_at).toLocaleDateString()}</td>
                  <td style={{ padding: "12px 14px" }}>
                    <span style={{ padding: "3px 10px", borderRadius: 20, fontSize: 12, fontWeight: 600, background: (p.status === "verified" ? COLORS.success : p.status === "rejected" ? COLORS.danger : COLORS.warning) + "18", color: p.status === "verified" ? COLORS.success : p.status === "rejected" ? COLORS.danger : COLORS.warning }}>{p.status}</span>
                  </td>
                  <td style={{ padding: "12px 14px" }}>
                    {p.status === "pending" && (
                      <div style={{ display: "flex", gap: 6 }}>
                        <button disabled={updating === p.id} onClick={() => setStatus(p.id, "verified")} style={{ background: COLORS.success, color: "#fff", border: "none", borderRadius: 6, padding: "5px 10px", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>Verify</button>
                        <button disabled={updating === p.id} onClick={() => setStatus(p.id, "rejected")} style={{ background: COLORS.danger + "18", color: COLORS.danger, border: "none", borderRadius: 6, padding: "5px 10px", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>Reject</button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </SectionCard>
    </div>
  );
};

const AdminNotices = () => {
  const [title, setTitle] = useState("");
  const [audience, setAudience] = useState("All Students & Lecturers");
  const [content, setContent] = useState("");
  const [posting, setPosting] = useState(false);
  const [error, setError] = useState("");
  const [notices, setNotices] = useState(null);

  const AUDIENCE_MAP = { "All Students & Lecturers": "all", "All Students": "student", "All Lecturers": "lecturer" };

  const load = () => api.notices().then(setNotices).catch(() => setNotices([]));
  useEffect(() => { load(); }, []);

  const handlePublish = async () => {
    if (!title.trim() || !content.trim()) { setError("Title and content are required."); return; }
    setPosting(true);
    setError("");
    try {
      await api.createNotice({ title: title.trim(), content: content.trim(), audience: AUDIENCE_MAP[audience] });
      setTitle("");
      setContent("");
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setPosting(false);
    }
  };

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>Notices</h2>
      <SectionCard title="Create Notice">
        <Field label="Title" placeholder="Notice title…" value={title} onChange={setTitle} />
        <Field label="Audience" type="select" value={audience} onChange={setAudience} options={["All Students & Lecturers", "All Students", "All Lecturers"]} />
        <Field label="Content" type="textarea" placeholder="Write notice content here…" value={content} onChange={setContent} />
        {error && <div style={{ color: COLORS.danger, fontSize: 13, marginBottom: 12, fontWeight: 600 }}>{error}</div>}
        <button onClick={handlePublish} disabled={posting} style={{ background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.accent})`, color: "#fff", border: "none", borderRadius: 10, padding: "12px 28px", fontWeight: 700, fontSize: 14, cursor: posting ? "default" : "pointer", opacity: posting ? 0.7 : 1 }}>{posting ? "Publishing…" : "Publish"}</button>
      </SectionCard>
      <SectionCard title="Active Notices">
        {!notices ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading…</div> : notices.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No notices posted yet.</div> : (
          <Table headers={["Title", "Posted By", "Date"]} rows={notices.map(n => [n.title, n.posted_by_name, new Date(n.created_at).toLocaleDateString()])} />
        )}
      </SectionCard>
    </div>
  );
};

const AdminWellbeingReports = () => {
  const [checkins, setCheckins] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    api.wellbeingReports().then(setCheckins).catch(err => setError(err.message));
  }, []);

  if (error) return <div style={{ color: COLORS.danger, fontSize: 14 }}>{error}</div>;
  if (!checkins) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading…</div>;

  const oneWeekAgo = Date.now() - 7 * 86400000;
  const thisWeek = checkins.filter(c => new Date(c.created_at).getTime() >= oneWeekAgo);
  const counselingRequests = checkins.filter(c => c.wants_counselor).length;

  // Average mood per day for the last 7 days (mood is 1-5; shown as %).
  const dayLabels = ["S", "M", "T", "W", "T", "F", "S"];
  const trend = Array.from({ length: 7 }, (_, i) => {
    const dayStart = new Date(Date.now() - (6 - i) * 86400000);
    dayStart.setHours(0, 0, 0, 0);
    const dayEnd = new Date(dayStart.getTime() + 86400000);
    const dayCheckins = checkins.filter(c => { const t = new Date(c.created_at).getTime(); return t >= dayStart.getTime() && t < dayEnd.getTime(); });
    const avgPct = dayCheckins.length ? Math.round((dayCheckins.reduce((s, c) => s + (c.mood || 0), 0) / dayCheckins.length / 5) * 100) : 0;
    return { pct: avgPct, label: dayLabels[dayStart.getDay()] };
  });

  const flagged = checkins
    .map(c => {
      let risk = null, reason = "";
      if (c.mood && c.mood <= 2) { risk = "High"; reason = "Low mood reported"; }
      if (c.wants_counselor) { risk = risk || "Pending"; reason = reason ? reason + " · Requested counselling" : "Self-referred for counselling"; }
      return risk ? { ...c, risk, reason } : null;
    })
    .filter(Boolean)
    .slice(0, 10);

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>Wellbeing Reports</h2>
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 24 }}>
        <StatCard label="Check-ins This Week" value={String(thisWeek.length)} icon="wellbeing" color={COLORS.success} />
        <StatCard label="Students Flagged" value={String(flagged.length)} icon="overview" color={COLORS.danger} />
        <StatCard label="Counselling Requests" value={String(counselingRequests)} icon="counseling" color={COLORS.accent} />
      </div>
      <SectionCard title="Mood Trend — Last 7 Days">
        {checkins.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No check-ins yet.</div> : (
          <div style={{ display: "flex", gap: 6, alignItems: "flex-end", height: 100, marginBottom: 8 }}>
            {trend.map((v, i) => (
              <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
                <div style={{ fontSize: 10, color: COLORS.textMuted }}>{v.pct}%</div>
                <div style={{ width: "100%", height: `${Math.max(v.pct * 0.8, 3)}px`, background: v.pct > 78 ? COLORS.success : v.pct > 50 ? COLORS.accentGold : COLORS.danger, borderRadius: "4px 4px 0 0" }} />
                <div style={{ fontSize: 10, color: COLORS.textMuted }}>{v.label}</div>
              </div>
            ))}
          </div>
        )}
      </SectionCard>
      <SectionCard title="Flagged Student Check-ins">
        {flagged.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No students currently flagged.</div> : (
          <Table
            headers={["Index No.", "Name", "Reason", "Risk Level"]}
            rows={flagged.map(f => [f.index_number, f.full_name, f.reason, f.risk])}
            badge
          />
        )}
      </SectionCard>
    </div>
  );
};

const AdminCounseling = () => {
  const [sessions, setSessions] = useState(null);
  const [error, setError] = useState("");
  const [editing, setEditing] = useState(null); // session id being scheduled
  const [counselorName, setCounselorName] = useState("");
  const [scheduledAt, setScheduledAt] = useState("");
  const [saving, setSaving] = useState(false);

  const load = () => api.allCounseling().then(setSessions).catch(err => setError(err.message));
  useEffect(() => { load(); }, []);

  const startScheduling = (session) => {
    setEditing(session.id);
    setCounselorName(session.counselor_name || "");
    setScheduledAt(session.scheduled_at ? session.scheduled_at.slice(0, 16) : "");
  };

  const saveSchedule = async (id) => {
    setSaving(true);
    try {
      await api.updateCounseling(id, { counselor_name: counselorName, scheduled_at: scheduledAt || null, status: "scheduled" });
      setEditing(null);
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const setStatus = async (id, status) => {
    try {
      await api.updateCounseling(id, { status });
      load();
    } catch (err) {
      setError(err.message);
    }
  };

  if (error) return <div style={{ color: COLORS.danger, fontSize: 14 }}>{error}</div>;
  if (!sessions) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading sessions…</div>;

  const thisMonth = sessions.filter(s => new Date(s.created_at).getMonth() === new Date().getMonth()).length;
  const pending = sessions.filter(s => s.status === "requested").length;

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>Counselling Sessions</h2>
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 24 }}>
        <StatCard label="Sessions This Month" value={String(thisMonth)} icon="counseling" color={COLORS.accent} />
        <StatCard label="Pending Requests" value={String(pending)} icon="overview" color={COLORS.warning} />
      </div>
      <SectionCard title="Counselling Requests">
        {sessions.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No requests yet.</div> : (
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
            <thead>
              <tr style={{ background: COLORS.bg }}>
                {["Requested", "Student", "Counsellor", "Scheduled For", "Status", ""].map((h, i) => (
                  <th key={i} style={{ padding: "11px 14px", textAlign: "left", color: COLORS.textSecondary, fontWeight: 600, fontSize: 12, textTransform: "uppercase" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {sessions.map(s => (
                <tr key={s.id} style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                  <td style={{ padding: "12px 14px", color: COLORS.textMuted, fontSize: 13 }}>{new Date(s.created_at).toLocaleDateString()}</td>
                  <td style={{ padding: "12px 14px", fontWeight: 600 }}>{s.full_name} <span style={{ color: COLORS.textMuted, fontWeight: 400, fontSize: 12 }}>({s.index_number})</span></td>
                  <td style={{ padding: "12px 14px" }}>{s.counselor_name || "—"}</td>
                  <td style={{ padding: "12px 14px", color: COLORS.textMuted, fontSize: 13 }}>{s.scheduled_at ? new Date(s.scheduled_at).toLocaleString() : "—"}</td>
                  <td style={{ padding: "12px 14px" }}>
                    <span style={{ padding: "3px 10px", borderRadius: 20, fontSize: 12, fontWeight: 600, background: (s.status === "completed" ? COLORS.success : s.status === "cancelled" ? COLORS.danger : s.status === "scheduled" ? COLORS.accent : COLORS.warning) + "18", color: s.status === "completed" ? COLORS.success : s.status === "cancelled" ? COLORS.danger : s.status === "scheduled" ? COLORS.accent : COLORS.warning }}>{s.status}</span>
                  </td>
                  <td style={{ padding: "12px 14px" }}>
                    {editing === s.id ? (
                      <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                        <input value={counselorName} onChange={e => setCounselorName(e.target.value)} placeholder="Counsellor name" style={{ padding: "5px 8px", borderRadius: 6, border: `1px solid ${COLORS.border}`, fontSize: 12, width: 120 }} />
                        <input type="datetime-local" value={scheduledAt} onChange={e => setScheduledAt(e.target.value)} style={{ padding: "5px 8px", borderRadius: 6, border: `1px solid ${COLORS.border}`, fontSize: 12 }} />
                        <button disabled={saving} onClick={() => saveSchedule(s.id)} style={{ background: COLORS.success, color: "#fff", border: "none", borderRadius: 6, padding: "5px 10px", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>Save</button>
                      </div>
                    ) : (
                      <div style={{ display: "flex", gap: 6 }}>
                        {s.status !== "completed" && s.status !== "cancelled" && (
                          <button onClick={() => startScheduling(s)} style={{ background: COLORS.primary, color: "#fff", border: "none", borderRadius: 6, padding: "5px 10px", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>Schedule</button>
                        )}
                        {s.status === "scheduled" && (
                          <button onClick={() => setStatus(s.id, "completed")} style={{ background: COLORS.success + "18", color: COLORS.success, border: "none", borderRadius: 6, padding: "5px 10px", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>Mark Done</button>
                        )}
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </SectionCard>
    </div>
  );
};

const SETTINGS_SECTIONS = [
  { title: "Institution Details", fields: [
    { key: "institution_name", label: "Institution Name", type: "text", def: "PST Department" },
    { key: "academic_year", label: "Academic Year", type: "select", options: ["2024/2025", "2023/2024"] },
    { key: "current_semester", label: "Semester", type: "select", options: ["Semester 1", "Semester 2"] },
    { key: "contact_email", label: "Contact Email", type: "email", def: "admin@pst.susl.ac.lk" },
  ] },
  { title: "Academic Configuration", fields: [
    { key: "min_attendance_pct", label: "Minimum Attendance (%)", type: "number", def: "75" },
    { key: "gpa_scale", label: "GPA Scale", type: "select", options: ["4.0 Scale", "5.0 Scale"] },
    { key: "pass_mark_pct", label: "Pass Mark (%)", type: "number", def: "50" },
  ] },
  { title: "Registration Fees", fields: [
    { key: "semester_registration_fee", label: "Semester Registration Fee (LKR, flat per semester)", type: "number", def: "300" },
    { key: "semester_registration_late_fee", label: "Late Registration Fine (LKR)", type: "number", def: "500" },
    { key: "semester_registration_deadline", label: "Registration Deadline", type: "date", def: "2025-07-15" },
  ] },
  { title: "Wellbeing Alerts", fields: [
    { key: "wellbeing_attendance_threshold", label: "Alert Threshold — Attendance (%)", type: "number", def: "75" },
    { key: "wellbeing_mood_flag_days", label: "Mood Flag — Consecutive Days", type: "number", def: "3" },
    { key: "wellbeing_auto_refer", label: "Auto-refer to Counsellor", type: "select", options: ["Yes", "No"] },
  ] },
];

const AdminSettings = () => {
  const [values, setValues] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(null); // section title being saved
  const [saved, setSaved] = useState(null);

  useEffect(() => {
    api.settings()
      .then(data => {
        const init = {};
        SETTINGS_SECTIONS.forEach(section => {
          section.fields.forEach(f => { init[f.key] = data[f.key] ?? f.def ?? (f.options ? f.options[0] : ""); });
        });
        setValues(init);
      })
      .catch(err => setError(err.message))
      .finally(() => setLoading(false));
  }, []);

  const saveSection = async (section) => {
    setSaving(section.title);
    setSaved(null);
    try {
      const payload = {};
      section.fields.forEach(f => { payload[f.key] = values[f.key]; });
      await api.updateSettings(payload);
      setSaved(section.title);
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(null);
    }
  };

  if (loading) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading settings…</div>;

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>System Settings</h2>
      {error && <div style={{ color: COLORS.danger, fontSize: 14, marginBottom: 16 }}>{error}</div>}
      {SETTINGS_SECTIONS.map((section, i) => (
        <SectionCard key={i} title={section.title} action={saving === section.title ? "Saving…" : saved === section.title ? "Saved ✓" : "Save Changes"} onAction={saving ? undefined : () => saveSection(section)}>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
            {section.fields.map((f) => (
              <Field key={f.key} label={f.label} type={f.type} options={f.options} value={values[f.key]} onChange={v => { setValues(vs => ({ ...vs, [f.key]: v })); setSaved(null); }} />
            ))}
          </div>
        </SectionCard>
      ))}
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════════════════════
// SEMESTER REGISTRATION
// ═══════════════════════════════════════════════════════════════════════════════

const StudentSemesterReg = () => {
  const [step, setStep] = useState(1);        // 1=select, 2=subjects, 3=payment, 4=success
  const [year, setYear] = useState(String(CURRENT_STUDENT.currentYear));
  const [semester, setSemester] = useState(String(CURRENT_STUDENT.currentSemester));
  const [combination, setCombination] = useState(CURRENT_STUDENT.combination);
  const [selected, setSelected] = useState([]);
  const [payMethod, setPayMethod] = useState("card");
  const [cardData, setCardData] = useState({ number: "", name: "", expiry: "", cvv: "" });
  const [slip, setSlip] = useState(null);
  const [slipName, setSlipName] = useState("");
  const [bankRef, setBankRef] = useState("");

  const needsCombination = year === "3" || year === "4";

  const [liveCourses, setLiveCourses] = useState([]);
  const [coursesError, setCoursesError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState("");

  useEffect(() => {
    if (!year || !semester) { setLiveCourses([]); setSelected([]); return; }
    if (needsCombination && !combination) { setLiveCourses([]); setSelected([]); return; } // wait for track pick first
    const combinationCode = combination ? combination.split(" ")[0] : null; // "C3 — Computer Science & Technology" -> "C3"
    api.courses(year, semester, combinationCode)
      .then(rows => {
        const mapped = rows.map(c => ({ id: c.id, code: c.code, name: c.name, cre: c.credits, elective: !!c.is_elective }));
        setLiveCourses(mapped);
        setSelected(mapped.filter(c => !c.elective).map(c => c.code)); // compulsory subjects are auto-registered
      })
      .catch(err => setCoursesError(err.message));
  }, [year, semester, combination, needsCombination]);

  const courses = liveCourses;
  const selectedCourses = courses.filter(c => selected.includes(c.code));
  const totalCredits = selectedCourses.reduce((sum, c) => sum + c.cre, 0);
  const totalFee = selected.length > 0 ? REGISTRATION_SETTINGS.fee : 0; // flat semester fee, same regardless of subject count

  const [myRegs, setMyRegs] = useState(null);
  const loadHistory = () => api.mySemRegs().then(setMyRegs).catch(() => setMyRegs([]));
  useEffect(() => { loadHistory(); }, []);

  const historyRows = (myRegs || []).map(r => [
    `REG-${String(r.id).padStart(6, "0")}`,
    `Y${r.year} / Sem ${r.semester}`,
    String(r.courses?.length || 0),
    `LKR ${Number(r.total_fee || 0).toLocaleString()}`,
    r.status === "payment_pending" ? "Payment Pending" : r.status === "confirmed" ? "Confirmed" : r.status.charAt(0).toUpperCase() + r.status.slice(1),
  ]);

  const fmtCard = (v) => v.replace(/\D/g, "").slice(0, 16).replace(/(.{4})/g, "$1 ").trim();
  const fmtExpiry = (v) => { const d = v.replace(/\D/g, "").slice(0, 4); return d.length >= 3 ? d.slice(0, 2) + "/" + d.slice(2) : d; };
  const toggleSubject = (code) => {
    const course = liveCourses.find(c => c.code === code);
    if (course && !course.elective) return; // compulsory — can't be deselected
    setSelected(p => p.includes(code) ? p.filter(c => c !== code) : [...p, code]);
  };

  const iStyle = { width: "100%", padding: "11px 14px", borderRadius: 10, border: `1.5px solid ${COLORS.border}`, fontSize: 14, outline: "none", boxSizing: "border-box", fontFamily: "inherit" };
  const lStyle = { display: "block", fontSize: 12, fontWeight: 700, color: COLORS.textSecondary, marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.04em" };

  const steps = ["Select Semester", "Choose Subjects", "Payment & Confirm"];
  const StepBar = () => (
    <div style={{ display: "flex", alignItems: "center", marginBottom: 28 }}>
      {steps.map((s, i) => {
        const num = i + 1; const active = step === num; const done = step > num;
        return (
          <div key={i} style={{ display: "flex", alignItems: "center", flex: i < steps.length - 1 ? 1 : "none" }}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 4 }}>
              <div style={{ width: 32, height: 32, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 13, background: done ? COLORS.success : active ? COLORS.primary : COLORS.border, color: done || active ? "#fff" : COLORS.textMuted, transition: "all 0.3s" }}>{done ? "✓" : num}</div>
              <div style={{ fontSize: 11, fontWeight: active ? 700 : 500, color: active ? COLORS.primary : done ? COLORS.success : COLORS.textMuted, whiteSpace: "nowrap" }}>{s}</div>
            </div>
            {i < steps.length - 1 && <div style={{ flex: 1, height: 2, background: done ? COLORS.success : COLORS.border, margin: "0 8px", marginBottom: 18, transition: "background 0.3s" }} />}
          </div>
        );
      })}
    </div>
  );

  if (step === 4) return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>Semester Registration</h2>
      <div style={{ background: COLORS.card, borderRadius: 20, padding: 48, textAlign: "center", boxShadow: "0 2px 24px rgba(30,58,95,0.10)" }}>
        <div style={{ width: 72, height: 72, borderRadius: "50%", background: COLORS.success + "18", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px" }}>
          <Icon name="check" size={36} color={COLORS.success} />
        </div>
        <h3 style={{ fontSize: 22, fontWeight: 800, color: COLORS.textPrimary, margin: "0 0 10px" }}>Registration Successful!</h3>
        <p style={{ color: COLORS.textMuted, fontSize: 14, marginBottom: 20 }}>
          You have registered for <strong>{selected.length} subject{selected.length !== 1 ? "s" : ""}</strong> in <strong>Year {year}, Semester {semester}</strong>.
        </p>
        <div style={{ background: COLORS.bg, borderRadius: 12, padding: "16px 24px", display: "inline-block", marginBottom: 28, textAlign: "left", minWidth: 280 }}>
          <div style={{ fontSize: 12, color: COLORS.textMuted, marginBottom: 4 }}>Registration Reference</div>
          <div style={{ fontSize: 16, fontWeight: 700, color: COLORS.primary, letterSpacing: "0.05em" }}>REG-{Date.now().toString().slice(-8)}</div>
          <div style={{ fontSize: 12, color: COLORS.textMuted, marginTop: 8 }}>Year {year} · Semester {semester} · {combination}</div>
          <div style={{ fontSize: 12, color: COLORS.textMuted }}>Subjects: {selected.length}</div>
        </div>
        <br />
        <button onClick={() => { setStep(1); setYear(String(CURRENT_STUDENT.currentYear)); setSemester(String(CURRENT_STUDENT.currentSemester)); setCombination(CURRENT_STUDENT.combination); setSelected([]); setSlip(null); setBankRef(""); setCardData({ number: "", name: "", expiry: "", cvv: "" }); }}
          style={{ background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.primaryLight})`, color: "#fff", border: "none", borderRadius: 12, padding: "12px 36px", fontWeight: 700, fontSize: 15, cursor: "pointer" }}>
          New Registration
        </button>
      </div>
      <div style={{ marginTop: 24 }}>
        <SectionCard title="Registration History">
          {historyRows.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No past registrations.</div> : (
            <Table headers={["Reference", "Year / Sem", "Subjects", "Fee", "Status"]} rows={historyRows} badge />
          )}
        </SectionCard>
      </div>
    </div>
  );

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 8 }}>Semester Registration</h2>
      <p style={{ color: COLORS.textMuted, marginBottom: 24, fontSize: 14 }}>Register for your subjects for the upcoming semester · Registration fee: <strong style={{ color: COLORS.primary }}>LKR {REGISTRATION_SETTINGS.fee} flat per semester</strong></p>

      {/* Stats row */}
      {step === 1 && (
        <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 24 }}>
          <StatCard label="Current Year" value={`Year ${CURRENT_STUDENT.currentYear}`} icon="modules" color={COLORS.primary} />
          <StatCard label="Reg. Fee (Flat)" value={`LKR ${REGISTRATION_SETTINGS.fee}`} icon="payment" color={COLORS.accent} />
        </div>
      )}

      <div style={{ background: COLORS.card, borderRadius: 16, padding: "28px 28px 24px", boxShadow: "0 2px 12px rgba(30,58,95,0.08)", marginBottom: 24 }}>
        <StepBar />

        {/* ── STEP 1: Select Semester ── */}
        {step === 1 && (
          <div>
            <h3 style={{ fontSize: 17, fontWeight: 700, color: COLORS.textPrimary, margin: "0 0 6px" }}>Select Academic Year & Semester</h3>
            <p style={{ fontSize: 13, color: COLORS.textMuted, marginBottom: 22 }}>Choose the year and semester you wish to register for.</p>

            <div style={{ display: "grid", gridTemplateColumns: needsCombination ? "1fr 1fr 1fr" : "1fr 1fr", gap: 16, marginBottom: 20 }}>
              <div>
                <label style={lStyle}>Academic Year</label>
                <select value={year} onChange={e => { setYear(e.target.value); setSelected([]); if (e.target.value !== "3" && e.target.value !== "4") setCombination(""); }} style={{ ...iStyle, cursor: "pointer" }}>
                  <option value="">Select Year</option>
                  <option value="1">Year 1</option>
                  <option value="2">Year 2</option>
                  <option value="3">Year 3</option>
                  <option value="4">Year 4</option>
                </select>
              </div>
              <div>
                <label style={lStyle}>Semester</label>
                <select value={semester} onChange={e => { setSemester(e.target.value); setSelected([]); }} style={{ ...iStyle, cursor: "pointer" }}>
                  <option value="">Select Semester</option>
                  <option value="1">Semester I</option>
                  <option value="2">Semester II</option>
                </select>
              </div>
              {needsCombination && (
                <div>
                  <label style={lStyle}>Special Subject (Combination)</label>
                  <select value={combination} onChange={e => { setCombination(e.target.value); setSelected([]); }} style={{ ...iStyle, cursor: "pointer" }}>
                    <option value="">Select Computer Science / Physics / Chemistry</option>
                    <option value="C1 — Applied Physics">C1 — Physics (Applied Physics)</option>
                    <option value="C2 — Chemical Technology">C2 — Chemistry (Chemical Technology)</option>
                    <option value="C3 — Computer Science & Technology">C3 — Computer Science</option>
                  </select>
                </div>
              )}
            </div>
            {needsCombination && !combination && (
              <div style={{ fontSize: 12.5, color: COLORS.warning, marginBottom: 16, marginTop: -8, display: "flex", alignItems: "center", gap: 6 }}>
                <Icon name="alert" size={13} color={COLORS.warning} /> Year 3 and 4 split into three special subjects — pick yours to see its modules.
              </div>
            )}

            {/* Registration deadline notice */}
            <div style={{ background: COLORS.accent + "12", border: `1px solid ${COLORS.accent}40`, borderRadius: 10, padding: "12px 16px", marginBottom: 20, fontSize: 13, color: COLORS.accent }}>
              Semester I 2025/26 registration deadline: <strong>{REGISTRATION_SETTINGS.deadline}</strong>. Late registrations attract an additional LKR {REGISTRATION_SETTINGS.lateFee} fine.
            </div>

            {/* Fee preview */}
            {year && semester && (!needsCombination || combination) && (
              <div style={{ background: COLORS.primary + "08", border: `1px solid ${COLORS.primary}25`, borderRadius: 10, padding: "12px 16px", fontSize: 13, color: COLORS.textSecondary }}>
                <strong style={{ color: COLORS.textPrimary }}>{courses.length} subjects</strong> available for Year {year} Semester {semester}. Registration fee: <strong>LKR {REGISTRATION_SETTINGS.fee}</strong> flat (covers all subjects).
              </div>
            )}

            <div style={{ marginTop: 24, display: "flex", justifyContent: "flex-end" }}>
              <button onClick={() => year && semester && (!needsCombination || combination) && setStep(2)}
                style={{ background: (year && semester && (!needsCombination || combination)) ? `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.primaryLight})` : COLORS.border, color: (year && semester && (!needsCombination || combination)) ? "#fff" : COLORS.textMuted, border: "none", borderRadius: 12, padding: "12px 32px", fontWeight: 700, fontSize: 14, cursor: (year && semester && (!needsCombination || combination)) ? "pointer" : "not-allowed" }}>
                Next: Choose Subjects →
              </button>
            </div>
          </div>
        )}

        {/* ── STEP 2: Choose Subjects ── */}
        {step === 2 && (
          <div>
            <h3 style={{ fontSize: 17, fontWeight: 700, color: COLORS.textPrimary, margin: "0 0 4px" }}>Choose Subjects to Register</h3>
            <p style={{ fontSize: 13, color: COLORS.textMuted, marginBottom: 16 }}>
              Year {year} · Semester {semester} · {combination} · <span style={{ color: COLORS.primary, fontWeight: 600 }}>LKR {REGISTRATION_SETTINGS.fee} flat semester fee</span>
            </p>

            {courses.length === 0 ? (
              <div style={{ textAlign: "center", padding: "32px 0", color: COLORS.textMuted }}>No subjects found for this selection.</div>
            ) : (
              <>
                {(() => {
                  const compulsoryCourses = courses.filter(c => !c.elective);
                  const electiveCourses = courses.filter(c => c.elective);
                  return (
                    <>
                      {compulsoryCourses.length > 0 && (
                        <div style={{ marginBottom: 20 }}>
                          <div style={{ fontSize: 13, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 10 }}>Compulsory Subjects <span style={{ fontWeight: 500, color: COLORS.textMuted }}>— included automatically</span></div>
                          <div style={{ border: `1px solid ${COLORS.border}`, borderRadius: 12, overflow: "hidden" }}>
                            {compulsoryCourses.map((c, i) => (
                              <div key={c.code} style={{ display: "flex", alignItems: "center", gap: 14, padding: "13px 16px", borderBottom: i < compulsoryCourses.length - 1 ? `1px solid ${COLORS.border}` : "none", background: COLORS.success + "06" }}>
                                <div style={{ width: 22, height: 22, borderRadius: 6, background: COLORS.success, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                                  <Icon name="check" size={13} color="#fff" />
                                </div>
                                <div style={{ flex: 1 }}>
                                  <div style={{ fontWeight: 600, fontSize: 14, color: COLORS.textPrimary }}>{c.name}</div>
                                  <div style={{ fontSize: 12, color: COLORS.textMuted, marginTop: 2 }}>{c.code} · {c.cre} Credit{c.cre !== 1 ? "s" : ""}</div>
                                </div>
                                <div style={{ fontSize: 11, fontWeight: 700, color: COLORS.success, textTransform: "uppercase", letterSpacing: "0.03em" }}>Compulsory</div>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}

                      {electiveCourses.length > 0 && (
                        <div>
                          <div style={{ display: "flex", gap: 10, marginBottom: 10, alignItems: "center" }}>
                            <div style={{ fontSize: 13, fontWeight: 700, color: COLORS.textPrimary }}>Elective Subjects <span style={{ fontWeight: 500, color: COLORS.textMuted }}>— pick the ones you want</span></div>
                            <button onClick={() => setSelected([...compulsoryCourses.map(c => c.code), ...electiveCourses.map(c => c.code)])}
                              style={{ marginLeft: "auto", fontSize: 12, fontWeight: 700, padding: "5px 12px", borderRadius: 8, background: COLORS.primary + "10", color: COLORS.primary, border: "none", cursor: "pointer" }}>Select All</button>
                            <button onClick={() => setSelected(compulsoryCourses.map(c => c.code))}
                              style={{ fontSize: 12, fontWeight: 700, padding: "5px 12px", borderRadius: 8, background: COLORS.bg, color: COLORS.textSecondary, border: `1px solid ${COLORS.border}`, cursor: "pointer" }}>Clear Electives</button>
                          </div>
                          <div style={{ border: `1px solid ${COLORS.border}`, borderRadius: 12, overflow: "hidden" }}>
                            {electiveCourses.map((c, i) => {
                              const sel = selected.includes(c.code);
                              return (
                                <div key={c.code} onClick={() => toggleSubject(c.code)}
                                  style={{ display: "flex", alignItems: "center", gap: 14, padding: "13px 16px", borderBottom: i < electiveCourses.length - 1 ? `1px solid ${COLORS.border}` : "none", background: sel ? COLORS.primary + "06" : "#fff", cursor: "pointer", transition: "background 0.15s" }}>
                                  <div style={{ width: 22, height: 22, borderRadius: 6, border: `2px solid ${sel ? COLORS.primary : COLORS.border}`, background: sel ? COLORS.primary : "#fff", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0, transition: "all 0.15s" }}>
                                    {sel && <Icon name="check" size={13} color="#fff" />}
                                  </div>
                                  <div style={{ flex: 1 }}>
                                    <div style={{ fontWeight: 600, fontSize: 14, color: COLORS.textPrimary }}>{c.name}</div>
                                    <div style={{ fontSize: 12, color: COLORS.textMuted, marginTop: 2 }}>{c.code} · {c.cre} Credit{c.cre !== 1 ? "s" : ""}</div>
                                  </div>
                                  <div style={{ fontSize: 11, fontWeight: 700, color: sel ? COLORS.primary : "transparent", textTransform: "uppercase", letterSpacing: "0.03em" }}>
                                    {sel ? "Selected" : ""}
                                  </div>
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      )}
                    </>
                  );
                })()}

                <div style={{ marginTop: 16, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <span style={{ fontSize: 13 }}>
                    <span style={{ color: COLORS.textSecondary }}>{selected.length} subject{selected.length !== 1 ? "s" : ""} selected</span>
                    {selected.length > 0 && <span style={{ fontWeight: 800, color: COLORS.primary, marginLeft: 8 }}>· LKR {totalFee.toLocaleString()}</span>}
                  </span>
                </div>
                <div style={{ height: 16 }} />

                {selected.length > 0 && (
                  <div style={{ padding: "14px 18px", background: COLORS.primary + "08", border: `1px solid ${COLORS.primary}25`, borderRadius: 12, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                    <div style={{ fontSize: 13, color: COLORS.textSecondary }}>{selected.length} subject{selected.length !== 1 ? "s" : ""} · {totalCredits} credit{totalCredits !== 1 ? "s" : ""} · flat semester fee</div>
                    <div style={{ fontSize: 18, fontWeight: 800, color: COLORS.primary }}>Total: LKR {totalFee.toLocaleString()}</div>
                  </div>
                )}
              </>
            )}

            <div style={{ marginTop: 24, display: "flex", gap: 10, justifyContent: "flex-end" }}>
              <button onClick={() => setStep(1)} style={{ background: COLORS.bg, color: COLORS.textSecondary, border: `1px solid ${COLORS.border}`, borderRadius: 12, padding: "12px 24px", fontWeight: 700, fontSize: 14, cursor: "pointer" }}>← Back</button>
              <button onClick={() => selected.length > 0 && setStep(3)}
                style={{ background: selected.length > 0 ? `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.primaryLight})` : COLORS.border, color: selected.length > 0 ? "#fff" : COLORS.textMuted, border: "none", borderRadius: 12, padding: "12px 32px", fontWeight: 700, fontSize: 14, cursor: selected.length > 0 ? "pointer" : "not-allowed" }}>
                Next: Payment & Confirm →
              </button>
            </div>
          </div>
        )}

        {/* ── STEP 3: Payment & Confirm ── */}
        {step === 3 && (
          <div>
            <h3 style={{ fontSize: 17, fontWeight: 700, color: COLORS.textPrimary, margin: "0 0 4px" }}>Payment & Confirmation</h3>
            <p style={{ fontSize: 13, color: COLORS.textMuted, marginBottom: 16 }}>Review your registration and complete payment.</p>

            {/* Summary */}
            <div style={{ background: COLORS.bg, borderRadius: 14, padding: 18, marginBottom: 20 }}>
              <div style={{ fontWeight: 700, fontSize: 13, color: COLORS.textSecondary, marginBottom: 10, textTransform: "uppercase", letterSpacing: "0.05em" }}>Registration Summary</div>
              {[
                ["Year / Semester", `Year ${year} · Semester ${semester}`],
                ["Combination", combination],
                ["Subjects Selected", `${selected.length} subject${selected.length !== 1 ? "s" : ""}`],
                ["Total Credits", `${totalCredits}`],
                ["Semester Registration Fee", `LKR ${REGISTRATION_SETTINGS.fee} (flat)`],
              ].map(([k, v]) => (
                <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: `1px solid ${COLORS.border}`, fontSize: 14 }}>
                  <span style={{ color: COLORS.textSecondary }}>{k}</span>
                  <span style={{ fontWeight: 600, color: COLORS.textPrimary }}>{v}</span>
                </div>
              ))}
              <div style={{ display: "flex", justifyContent: "space-between", padding: "12px 0 0", fontSize: 16, fontWeight: 800 }}>
                <span style={{ color: COLORS.textPrimary }}>Total Fee</span>
                <span style={{ color: COLORS.primary }}>LKR {totalFee.toLocaleString()}</span>
              </div>
            </div>

            {/* Subject list compact */}
            <div style={{ border: `1px solid ${COLORS.border}`, borderRadius: 10, overflow: "hidden", marginBottom: 20 }}>
              <div style={{ padding: "10px 14px", background: COLORS.primary, color: "#fff", fontWeight: 700, fontSize: 12, textTransform: "uppercase", letterSpacing: "0.05em" }}>
                Registered Subjects ({selected.length})
              </div>
              {courses.filter(c => selected.includes(c.code)).map((c, i, arr) => (
                <div key={c.code} style={{ display: "flex", justifyContent: "space-between", padding: "10px 14px", borderBottom: i < arr.length - 1 ? `1px solid ${COLORS.border}` : "none", fontSize: 13 }}>
                  <span style={{ color: COLORS.textPrimary, fontWeight: 500 }}>{c.name}</span>
                  <span style={{ color: COLORS.textMuted }}>{c.code}</span>
                </div>
              ))}
            </div>

            {/* Payment method */}
            <div style={{ fontWeight: 700, fontSize: 13, color: COLORS.textSecondary, marginBottom: 10, textTransform: "uppercase", letterSpacing: "0.05em" }}>Payment Method</div>
            <div style={{ display: "flex", gap: 10, marginBottom: 20 }}>
              {[{ id: "card", label: "Card Payment" }, { id: "slip", label: "Bank Deposit Slip" }].map(m => (
                <button key={m.id} onClick={() => setPayMethod(m.id)}
                  style={{ flex: 1, padding: "11px", borderRadius: 10, border: `2px solid ${payMethod === m.id ? COLORS.primary : COLORS.border}`, background: payMethod === m.id ? COLORS.primary + "10" : "#fff", fontWeight: 700, fontSize: 13, color: payMethod === m.id ? COLORS.primary : COLORS.textSecondary, cursor: "pointer" }}>
                  {m.label}
                </button>
              ))}
            </div>

            {/* Card form */}
            {payMethod === "card" && (
              <div>
                {/* Visual card */}
                <div style={{ background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.accent})`, borderRadius: 16, padding: "22px 24px", marginBottom: 20, color: "#fff", position: "relative", overflow: "hidden" }}>
                  <div style={{ position: "absolute", right: -20, top: -20, width: 120, height: 120, borderRadius: "50%", background: "rgba(255,255,255,0.08)" }} />
                  <div style={{ position: "absolute", right: 20, bottom: -30, width: 100, height: 100, borderRadius: "50%", background: "rgba(255,255,255,0.05)" }} />
                  <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 22 }}>
                    <div style={{ fontWeight: 800, fontSize: 16 }}>UniPay</div>
                    <div style={{ background: "rgba(255,255,255,0.25)", borderRadius: 6, padding: "3px 10px", fontSize: 11, fontWeight: 700 }}>VISA</div>
                  </div>
                  <div style={{ fontFamily: "monospace", fontSize: 17, letterSpacing: "0.18em", marginBottom: 18 }}>{cardData.number || "•••• •••• •••• ••••"}</div>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 13 }}>
                    <div><div style={{ fontSize: 10, opacity: 0.7 }}>CARDHOLDER</div><div style={{ fontWeight: 700 }}>{cardData.name || "YOUR NAME"}</div></div>
                    <div><div style={{ fontSize: 10, opacity: 0.7 }}>EXPIRES</div><div style={{ fontWeight: 700 }}>{cardData.expiry || "MM/YY"}</div></div>
                  </div>
                </div>
                <div style={{ marginBottom: 14 }}>
                  <label style={lStyle}>Card Number</label>
                  <input value={cardData.number} onChange={e => setCardData(p => ({ ...p, number: fmtCard(e.target.value) }))} placeholder="1234 5678 9012 3456" maxLength={19} style={{ ...iStyle, fontFamily: "monospace", letterSpacing: "0.1em" }} />
                </div>
                <div style={{ marginBottom: 14 }}>
                  <label style={lStyle}>Cardholder Name</label>
                  <input value={cardData.name} onChange={e => setCardData(p => ({ ...p, name: e.target.value.toUpperCase() }))} placeholder="AS ON CARD" style={iStyle} />
                </div>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 16 }}>
                  <div>
                    <label style={lStyle}>Expiry</label>
                    <input value={cardData.expiry} onChange={e => setCardData(p => ({ ...p, expiry: fmtExpiry(e.target.value) }))} placeholder="MM/YY" maxLength={5} style={iStyle} />
                  </div>
                  <div>
                    <label style={lStyle}>CVV</label>
                    <input value={cardData.cvv} onChange={e => setCardData(p => ({ ...p, cvv: e.target.value.replace(/\D/g, "").slice(0, 4) }))} placeholder="•••" maxLength={4} type="password" style={iStyle} />
                  </div>
                </div>
                <div style={{ fontSize: 12, color: COLORS.textMuted, textAlign: "center", marginBottom: 16, display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}><Icon name="lock" size={13} color={COLORS.textMuted} /> 256-bit SSL encrypted · PCI DSS compliant</div>
              </div>
            )}

            {/* Slip upload */}
            {payMethod === "slip" && (
              <div style={{ marginBottom: 20 }}>
                <div style={{ background: COLORS.bg, borderRadius: 12, padding: 16, marginBottom: 14 }}>
                  <div style={{ fontWeight: 700, fontSize: 13, color: COLORS.primary, marginBottom: 10, display: "flex", alignItems: "center", gap: 6 }}><Icon name="bank" size={14} color={COLORS.primary} /> Bank Transfer Details</div>
                  {[["Bank", "Bank of Ceylon"], ["Branch", "Colombo Main"], ["Account Name", "PST Department"], ["Account No.", "8001-2345-6789"], ["Amount", `LKR ${totalFee.toLocaleString()}`], ["Reference", "Student ID + SEM REG"]].map(([k, v]) => (
                    <div key={k} style={{ display: "flex", justifyContent: "space-between", fontSize: 13, padding: "5px 0", borderBottom: `1px solid ${COLORS.border}` }}>
                      <span style={{ color: COLORS.textSecondary }}>{k}</span>
                      <span style={{ fontWeight: 600, color: k === "Amount" ? COLORS.primary : COLORS.textPrimary }}>{v}</span>
                    </div>
                  ))}
                </div>
                <label style={lStyle}>Upload Deposit Slip</label>
                <label style={{ display: "block", border: `2px dashed ${slip ? COLORS.success : COLORS.border}`, borderRadius: 12, padding: "20px", textAlign: "center", cursor: "pointer", background: slip ? COLORS.success + "06" : COLORS.bg, marginBottom: 14 }}>
                  <input type="file" accept="image/*,.pdf" onChange={e => { const f = e.target.files[0]; if (f) { setSlip(f); setSlipName(f.name); }}} style={{ display: "none" }} />
                  {slip ? <div><div style={{ width: 32, height: 32, borderRadius: "50%", background: COLORS.success + "18", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto" }}><Icon name="check" size={16} color={COLORS.success} /></div><div style={{ fontWeight: 700, fontSize: 13, color: COLORS.success, marginTop: 6 }}>{slipName}</div><div style={{ fontSize: 12, color: COLORS.textMuted }}>Click to change</div></div>
                    : <div><div style={{ display: "flex", justifyContent: "center", marginBottom: 4 }}><Icon name="report" size={26} color={COLORS.textMuted} /></div><div style={{ fontWeight: 700, fontSize: 13, marginTop: 6 }}>Upload Bank Slip</div><div style={{ fontSize: 12, color: COLORS.textMuted }}>JPG, PNG or PDF · Max 5MB</div></div>}
                </label>
                <label style={lStyle}>Bank Reference / Transaction Number</label>
                <input value={bankRef} onChange={e => setBankRef(e.target.value)} placeholder="e.g. BOC-2025-0619-12345" style={iStyle} />
              </div>
            )}

            {submitError && <div style={{ color: COLORS.danger, fontSize: 13, marginBottom: 10, fontWeight: 600 }}>{submitError}</div>}
            <div style={{ display: "flex", gap: 10, justifyContent: "flex-end", marginTop: 8 }}>
              <button onClick={() => setStep(2)} style={{ background: COLORS.bg, color: COLORS.textSecondary, border: `1px solid ${COLORS.border}`, borderRadius: 12, padding: "12px 24px", fontWeight: 700, fontSize: 14, cursor: "pointer" }}>← Back</button>
              <button onClick={async () => {
                  const cardOk = payMethod === "card" && cardData.number.length >= 19 && cardData.name && cardData.expiry.length === 5 && cardData.cvv.length >= 3;
                  const slipOk = payMethod === "slip" && slip && bankRef;
                  if (!cardOk && !slipOk) return;
                  setSubmitError("");
                  setSubmitting(true);
                  try {
                    await api.createSemReg({
                      year: parseInt(year, 10),
                      semester: parseInt(semester, 10),
                      combination,
                      courseIds: selectedCourses.map(c => c.id),
                    });
                    loadHistory();
                    setStep(4);
                  } catch (err) {
                    setSubmitError(err.message);
                  } finally {
                    setSubmitting(false);
                  }
                }}
                disabled={submitting}
                style={{ background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.primaryLight})`, color: "#fff", border: "none", borderRadius: 12, padding: "12px 32px", fontWeight: 700, fontSize: 14, cursor: submitting ? "default" : "pointer", opacity: submitting ? 0.7 : 1 }}>
                {submitting ? "Submitting…" : payMethod === "card" ? `Pay LKR ${totalFee.toLocaleString()} & Register` : "Submit Slip & Register"}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

// ── Admin: Semester Registration Management ───────────────────────────────────
const AdminSemesterReg = () => {
  const [regs, setRegs] = useState(null);
  const [error, setError] = useState("");
  const [updating, setUpdating] = useState(null);
  const [yearFilter, setYearFilter] = useState("All Years");
  const [statusFilter, setStatusFilter] = useState("All");

  const load = () => api.allSemRegs().then(setRegs).catch(err => setError(err.message));
  useEffect(() => { load(); }, []);

  const setStatus = async (id, status) => {
    setUpdating(id);
    try {
      await api.updateSemRegStatus(id, status);
      setRegs(rows => rows.map(r => r.id === id ? { ...r, status } : r));
    } catch (err) {
      setError(err.message);
    } finally {
      setUpdating(null);
    }
  };

  if (error) return <div style={{ color: COLORS.danger, fontSize: 14 }}>{error}</div>;
  if (!regs) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading registrations…</div>;

  const filtered = regs.filter(r => {
    const matchesYear = yearFilter === "All Years" || String(r.year) === yearFilter.replace("Year ", "");
    const matchesStatus = statusFilter === "All" || r.status === statusFilter;
    return matchesYear && matchesStatus;
  });

  const totalFeeCollected = regs.filter(r => r.status === "confirmed").reduce((s, r) => s + Number(r.total_fee || 0), 0);
  const pendingCount = regs.filter(r => r.status === "pending" || r.status === "payment_pending").length;

  return (
    <div>
      <div style={{ marginBottom: 24 }}>
        <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, margin: 0 }}>Semester Registration</h2>
        <p style={{ color: COLORS.textMuted, marginTop: 4, fontSize: 14 }}>Manage student subject registrations · LKR {REGISTRATION_SETTINGS.fee} flat registration fee per semester</p>
      </div>
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 24 }}>
        <StatCard label="Total Registrations" value={String(regs.length)} icon="registration" color={COLORS.accent} />
        <StatCard label="Pending" value={String(pendingCount)} icon="overview" color={COLORS.warning} />
        <StatCard label="Fee Collected (Confirmed)" value={`LKR ${totalFeeCollected.toLocaleString()}`} icon="payment" color={COLORS.success} />
        <StatCard label="Deadline" value={REGISTRATION_SETTINGS.deadline} icon="attendance" color={COLORS.danger} />
      </div>
      <SectionCard title="Filter Registrations">
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
          <Field label="Academic Year" type="select" value={yearFilter} onChange={setYearFilter} options={["All Years", "Year 1", "Year 2", "Year 3", "Year 4"]} />
          <Field label="Status" type="select" value={statusFilter} onChange={setStatusFilter} options={["All", "pending", "payment_pending", "confirmed", "rejected"]} />
        </div>
      </SectionCard>
      <SectionCard title="Registration Records">
        {filtered.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No registrations match your filters.</div> : (
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
            <thead>
              <tr style={{ background: COLORS.bg }}>
                {["Ref", "Student ID", "Name", "Year/Sem", "Subjects", "Fee", "Status", ""].map((h, i) => (
                  <th key={i} style={{ padding: "11px 14px", textAlign: "left", color: COLORS.textSecondary, fontWeight: 600, fontSize: 12, textTransform: "uppercase" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map(r => (
                <tr key={r.id} style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                  <td style={{ padding: "12px 14px", color: COLORS.textMuted, fontSize: 13 }}>REG-{String(r.id).padStart(6, "0")}</td>
                  <td style={{ padding: "12px 14px", color: COLORS.textMuted, fontSize: 13 }}>{r.index_number}</td>
                  <td style={{ padding: "12px 14px", fontWeight: 600 }}>{r.full_name}</td>
                  <td style={{ padding: "12px 14px" }}>Y{r.year}/S{r.semester}</td>
                  <td style={{ padding: "12px 14px" }}>{r.subject_count}</td>
                  <td style={{ padding: "12px 14px" }}>LKR {Number(r.total_fee || 0).toLocaleString()}</td>
                  <td style={{ padding: "12px 14px" }}>
                    <span style={{ padding: "3px 10px", borderRadius: 20, fontSize: 12, fontWeight: 600, background: (r.status === "confirmed" ? COLORS.success : r.status === "rejected" ? COLORS.danger : COLORS.warning) + "18", color: r.status === "confirmed" ? COLORS.success : r.status === "rejected" ? COLORS.danger : COLORS.warning }}>{r.status}</span>
                  </td>
                  <td style={{ padding: "12px 14px" }}>
                    {r.status !== "confirmed" && r.status !== "rejected" && (
                      <div style={{ display: "flex", gap: 6 }}>
                        <button disabled={updating === r.id} onClick={() => setStatus(r.id, "confirmed")} style={{ background: COLORS.success, color: "#fff", border: "none", borderRadius: 6, padding: "5px 10px", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>Confirm</button>
                        <button disabled={updating === r.id} onClick={() => setStatus(r.id, "rejected")} style={{ background: COLORS.danger + "18", color: COLORS.danger, border: "none", borderRadius: 6, padding: "5px 10px", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>Reject</button>
                      </div>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </SectionCard>
      <div style={{ fontSize: 13, color: COLORS.textMuted, marginTop: 12 }}>
        Registration fees and deadlines are managed in <strong>System Settings</strong>.
      </div>
    </div>
  );
};

const AdminEnrollmentManagement = () => {
  const [tab, setTab] = useState("register"); // register | manage

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 8 }}>Enrollment Management</h2>
      <p style={{ color: COLORS.textMuted, marginBottom: 20, fontSize: 14 }}>Register students for courses directly, and view or edit existing registrations.</p>
      <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
        {[["register", "Register Students for Courses"], ["manage", "View & Edit Registrations"]].map(([k, label]) => (
          <button key={k} onClick={() => setTab(k)}
            style={{ padding: "9px 20px", borderRadius: 10, border: `2px solid ${tab === k ? COLORS.primary : COLORS.border}`, background: tab === k ? COLORS.primary : "#fff", color: tab === k ? "#fff" : COLORS.textSecondary, fontWeight: 700, fontSize: 14, cursor: "pointer" }}>
            {label}
          </button>
        ))}
      </div>
      {tab === "register" ? <AdminRegisterStudentForCourses /> : <AdminViewEditRegistrations />}
    </div>
  );
};

const AdminRegisterStudentForCourses = () => {
  const [students, setStudents] = useState(null);
  const [studentSearch, setStudentSearch] = useState("");
  const [selectedStudent, setSelectedStudent] = useState(null);
  const [year, setYear] = useState("");
  const [semester, setSemester] = useState("");
  const [combination, setCombination] = useState("");
  const [courses, setCourses] = useState([]);
  const [selectedCourseIds, setSelectedCourseIds] = useState([]);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [successMsg, setSuccessMsg] = useState("");

  useEffect(() => {
    api.allStudents().then(setStudents).catch(err => setError(err.message));
  }, []);

  const needsCombination = year === "3" || year === "4";

  useEffect(() => {
    if (!year || !semester) { setCourses([]); return; }
    if (needsCombination && !combination) { setCourses([]); return; }
    api.courses(year, semester, combination || null)
      .then(rows => {
        setCourses(rows);
        setSelectedCourseIds(rows.filter(r => !r.is_elective).map(r => r.id));
      })
      .catch(err => setError(err.message));
  }, [year, semester, combination, needsCombination]);

  const pickStudent = (s) => {
    setSelectedStudent(s);
    setStudentSearch(`${s.index_number} — ${s.full_name}`);
    setYear(String(s.current_year));
    setSemester(String(s.current_semester));
    setCombination(s.batch || "");
    setSuccessMsg("");
  };

  const toggleCourse = (course) => {
    if (!course.is_elective) return;
    setSelectedCourseIds(ids => ids.includes(course.id) ? ids.filter(x => x !== course.id) : [...ids, course.id]);
  };

  const filteredStudents = (students || []).filter(s =>
    studentSearch && (s.full_name.toLowerCase().includes(studentSearch.toLowerCase()) || s.index_number.toLowerCase().includes(studentSearch.toLowerCase()))
  ).slice(0, 8);

  const handleSubmit = async () => {
    if (!selectedStudent || !selectedCourseIds.length) return;
    setSubmitting(true);
    setError("");
    setSuccessMsg("");
    try {
      await api.adminCreateSemReg({
        studentId: selectedStudent.id,
        year: parseInt(year, 10),
        semester: parseInt(semester, 10),
        combination: combination || null,
        courseIds: selectedCourseIds,
      });
      setSuccessMsg(`Registered ${selectedStudent.full_name} for ${selectedCourseIds.length} course${selectedCourseIds.length !== 1 ? "s" : ""}.`);
      setSelectedCourseIds(courses.filter(c => !c.is_elective).map(c => c.id));
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div>
      <SectionCard title="1. Select Student">
        <div style={{ position: "relative" }}>
          <input value={studentSearch} onChange={e => { setStudentSearch(e.target.value); setSelectedStudent(null); }} placeholder="Search by index number or name…"
            style={{ width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, outline: "none", boxSizing: "border-box" }} />
          {studentSearch && !selectedStudent && filteredStudents.length > 0 && (
            <div style={{ position: "absolute", top: "100%", left: 0, right: 0, background: "#fff", border: `1px solid ${COLORS.border}`, borderRadius: 8, marginTop: 4, boxShadow: "0 4px 16px rgba(0,0,0,0.08)", zIndex: 10, maxHeight: 220, overflowY: "auto" }}>
              {filteredStudents.map(s => (
                <div key={s.id} onClick={() => pickStudent(s)} style={{ padding: "10px 14px", cursor: "pointer", borderBottom: `1px solid ${COLORS.border}`, fontSize: 13 }}>
                  <strong>{s.index_number}</strong> — {s.full_name} <span style={{ color: COLORS.textMuted }}>({s.batch || "no batch"}, Year {s.current_year})</span>
                </div>
              ))}
            </div>
          )}
        </div>
        {selectedStudent && (
          <div style={{ marginTop: 14, padding: "10px 14px", background: COLORS.success + "10", borderRadius: 8, fontSize: 13, color: COLORS.textPrimary }}>
            Selected: <strong>{selectedStudent.full_name}</strong> ({selectedStudent.index_number})
          </div>
        )}
      </SectionCard>

      {selectedStudent && (
        <SectionCard title="2. Year, Semester & Combination">
          <div style={{ display: "grid", gridTemplateColumns: needsCombination ? "1fr 1fr 1fr" : "1fr 1fr", gap: 16 }}>
            <div>
              <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Academic Year</label>
              <select value={year} onChange={e => { setYear(e.target.value); if (e.target.value !== "3" && e.target.value !== "4") setCombination(""); }} style={{ width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, background: "#fff" }}>
                <option value="1">Year 1</option><option value="2">Year 2</option><option value="3">Year 3</option><option value="4">Year 4</option>
              </select>
            </div>
            <div>
              <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Semester</label>
              <select value={semester} onChange={e => setSemester(e.target.value)} style={{ width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, background: "#fff" }}>
                <option value="1">Semester I</option><option value="2">Semester II</option>
              </select>
            </div>
            {needsCombination && (
              <div>
                <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Combination</label>
                <select value={combination} onChange={e => setCombination(e.target.value)} style={{ width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, background: "#fff" }}>
                  <option value="">Select</option>
                  <option value="C1">C1 — Physics (Applied Physics)</option>
                  <option value="C2">C2 — Chemistry (Chemical Technology)</option>
                  <option value="C3">C3 — Computer Science</option>
                </select>
              </div>
            )}
          </div>
        </SectionCard>
      )}

      {selectedStudent && year && semester && (!needsCombination || combination) && (
        <SectionCard title="3. Select Courses" action={submitting ? "Registering…" : "Register Student"} onAction={submitting ? undefined : handleSubmit}>
          {successMsg && <div style={{ color: COLORS.success, fontSize: 13, fontWeight: 600, marginBottom: 14, display: "flex", alignItems: "center", gap: 6 }}><Icon name="check" size={14} color={COLORS.success} /> {successMsg}</div>}
          {error && <div style={{ color: COLORS.danger, fontSize: 13, marginBottom: 14, fontWeight: 600 }}>{error}</div>}
          {courses.length === 0 ? (
            <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No courses found for this selection.</div>
          ) : (
            <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
              <thead>
                <tr style={{ background: COLORS.bg }}>
                  {["", "Code", "Name", "Credits", "Type"].map((h, i) => (
                    <th key={i} style={{ padding: "10px 14px", textAlign: "left", color: COLORS.textSecondary, fontWeight: 600, fontSize: 12, textTransform: "uppercase" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {courses.map(c => {
                  const sel = selectedCourseIds.includes(c.id);
                  return (
                    <tr key={c.id} onClick={() => toggleCourse(c)} style={{ borderBottom: `1px solid ${COLORS.border}`, cursor: c.is_elective ? "pointer" : "default", background: sel ? COLORS.primary + "06" : "#fff" }}>
                      <td style={{ padding: "9px 14px" }}><input type="checkbox" checked={sel} disabled={!c.is_elective} readOnly style={{ accentColor: COLORS.primary, width: 15, height: 15 }} /></td>
                      <td style={{ padding: "9px 14px", fontWeight: 700, color: COLORS.primary, fontSize: 13 }}>{c.code}</td>
                      <td style={{ padding: "9px 14px" }}>{c.name}</td>
                      <td style={{ padding: "9px 14px" }}>{c.credits}</td>
                      <td style={{ padding: "9px 14px" }}>
                        <span style={{ padding: "3px 10px", borderRadius: 20, fontSize: 11, fontWeight: 600, background: (c.is_elective ? COLORS.accentGold : COLORS.success) + "18", color: c.is_elective ? "#B45309" : COLORS.success }}>
                          {c.is_elective ? "Optional" : "Compulsory"}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          )}
        </SectionCard>
      )}
    </div>
  );
};

const AdminViewEditRegistrations = () => {
  const [regs, setRegs] = useState(null);
  const [error, setError] = useState("");
  const [editingId, setEditingId] = useState(null);
  const [editCourses, setEditCourses] = useState([]);
  const [editSelected, setEditSelected] = useState([]);
  const [saving, setSaving] = useState(false);

  const load = () => api.allSemRegs().then(setRegs).catch(err => setError(err.message));
  useEffect(() => { load(); }, []);

  const startEdit = async (reg) => {
    setEditingId(reg.id);
    setEditSelected(reg.courses.map(c => c.code));
    try {
      const rows = await api.courses(reg.year, reg.semester, reg.combination || null);
      setEditCourses(rows);
      // Pre-select using course ids matched by code from the fetched catalog
      setEditSelected(rows.filter(c => reg.courses.some(rc => rc.code === c.code)).map(c => c.id));
    } catch (err) {
      setError(err.message);
    }
  };

  const toggleEditCourse = (course) => {
    if (!course.is_elective) return;
    setEditSelected(ids => ids.includes(course.id) ? ids.filter(x => x !== course.id) : [...ids, course.id]);
  };

  const saveEdit = async (id) => {
    setSaving(true);
    try {
      await api.editSemReg(id, editSelected);
      setEditingId(null);
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  if (error) return <div style={{ color: COLORS.danger, fontSize: 14 }}>{error}</div>;
  if (!regs) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading registrations…</div>;

  return (
    <SectionCard title="Course Registrations">
      {regs.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No registrations yet.</div> : (
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
          <thead>
            <tr style={{ background: COLORS.bg }}>
              {["Ref", "Student", "Year/Sem", "Combination", "Subjects", "Status", ""].map((h, i) => (
                <th key={i} style={{ padding: "11px 14px", textAlign: "left", color: COLORS.textSecondary, fontWeight: 600, fontSize: 12, textTransform: "uppercase" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {regs.map(r => (
              <Fragment key={r.id}>
                <tr style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                  <td style={{ padding: "12px 14px", color: COLORS.textMuted, fontSize: 13 }}>REG-{String(r.id).padStart(6, "0")}</td>
                  <td style={{ padding: "12px 14px", fontWeight: 600 }}>{r.full_name} <span style={{ color: COLORS.textMuted, fontWeight: 400, fontSize: 12 }}>({r.index_number})</span></td>
                  <td style={{ padding: "12px 14px" }}>Y{r.year}/S{r.semester}</td>
                  <td style={{ padding: "12px 14px" }}>{r.combination || "—"}</td>
                  <td style={{ padding: "12px 14px" }}>{r.subject_count}</td>
                  <td style={{ padding: "12px 14px" }}>
                    <span style={{ padding: "3px 10px", borderRadius: 20, fontSize: 12, fontWeight: 600, background: (r.status === "confirmed" ? COLORS.success : r.status === "rejected" ? COLORS.danger : COLORS.warning) + "18", color: r.status === "confirmed" ? COLORS.success : r.status === "rejected" ? COLORS.danger : COLORS.warning }}>{r.status}</span>
                  </td>
                  <td style={{ padding: "12px 14px" }}>
                    <button onClick={() => editingId === r.id ? setEditingId(null) : startEdit(r)} style={{ background: COLORS.primary + "10", color: COLORS.primary, border: "none", borderRadius: 6, padding: "5px 12px", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>
                      {editingId === r.id ? "Cancel" : "Edit"}
                    </button>
                  </td>
                </tr>
                {editingId === r.id && (
                  <tr>
                    <td colSpan={7} style={{ padding: "0 14px 16px", background: COLORS.bg }}>
                      <div style={{ background: "#fff", border: `1px solid ${COLORS.border}`, borderRadius: 10, padding: 16, marginTop: 8 }}>
                        <div style={{ fontSize: 13, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 10 }}>Edit Courses</div>
                        {editCourses.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 13 }}>Loading course list…</div> : (
                          <>
                            <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 8, marginBottom: 14 }}>
                              {editCourses.map(c => {
                                const sel = editSelected.includes(c.id);
                                return (
                                  <label key={c.id} style={{ display: "flex", alignItems: "center", gap: 8, padding: "7px 10px", borderRadius: 6, background: sel ? COLORS.primary + "08" : "transparent", cursor: c.is_elective ? "pointer" : "default", fontSize: 13 }}>
                                    <input type="checkbox" checked={sel} disabled={!c.is_elective} onChange={() => toggleEditCourse(c)} style={{ accentColor: COLORS.primary }} />
                                    <span style={{ fontWeight: 700, color: COLORS.primary }}>{c.code}</span> {c.name}
                                    {!c.is_elective && <span style={{ fontSize: 10, color: COLORS.textMuted }}>(compulsory)</span>}
                                  </label>
                                );
                              })}
                            </div>
                            <button onClick={() => saveEdit(r.id)} disabled={saving} style={{ background: COLORS.success, color: "#fff", border: "none", borderRadius: 8, padding: "8px 18px", fontWeight: 700, fontSize: 13, cursor: saving ? "default" : "pointer" }}>
                              {saving ? "Saving…" : "Save Changes"}
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                )}
              </Fragment>
            ))}
          </tbody>
        </table>
      )}
    </SectionCard>
  );
};

const AdminExamTimetable = () => {
  const [year, setYear] = useState("");
  const [semester, setSemester] = useState("");
  const [courses, setCourses] = useState([]);
  const [courseId, setCourseId] = useState("");
  const [examDate, setExamDate] = useState("");
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [venue, setVenue] = useState("");
  const [entries, setEntries] = useState(null);
  const [error, setError] = useState("");
  const [saving, setSaving] = useState(false);

  // ── Upload the whole timetable as a document (PDF/image) ──
  const [docYear, setDocYear] = useState("");
  const [docSemester, setDocSemester] = useState("");
  const [docTitle, setDocTitle] = useState("");
  const [docFile, setDocFile] = useState(null);
  const [documents, setDocuments] = useState(null);
  const [docError, setDocError] = useState("");
  const [docSaving, setDocSaving] = useState(false);

  const loadDocuments = () => api.examTimetableDocuments().then(setDocuments).catch(err => setDocError(err.message));
  useEffect(() => { loadDocuments(); }, []);

  const handleUploadDocument = async () => {
    if (!docYear || !docSemester || !docFile) { setDocError("Year, Semester and a file are required."); return; }
    setDocSaving(true);
    setDocError("");
    try {
      const form = new FormData();
      form.append("year", docYear);
      form.append("semester", docSemester);
      form.append("title", docTitle || `Year ${docYear} Semester ${docSemester} Exam Timetable`);
      form.append("document", docFile);
      await api.uploadExamTimetableDocument(form);
      setDocYear(""); setDocSemester(""); setDocTitle(""); setDocFile(null);
      loadDocuments();
    } catch (err) {
      setDocError(err.message);
    } finally {
      setDocSaving(false);
    }
  };

  const handleDeleteDocument = async (id) => {
    try {
      await api.deleteExamTimetableDocument(id);
      loadDocuments();
    } catch (err) {
      setDocError(err.message);
    }
  };

  const load = () => api.allExamTimetable().then(setEntries).catch(err => setError(err.message));
  useEffect(() => { load(); }, []);

  useEffect(() => {
    if (!year || !semester) { setCourses([]); return; }
    api.courses(year, semester).then(rows => { setCourses(rows); if (rows.length) setCourseId(String(rows[0].id)); }).catch(err => setError(err.message));
  }, [year, semester]);

  const handleAdd = async () => {
    if (!courseId || !examDate || !startTime) { setError("Course, date and start time are required."); return; }
    setSaving(true);
    setError("");
    try {
      await api.createExamTimetableEntry({ courseId, year: parseInt(year, 10), semester: parseInt(semester, 10), examDate, startTime, endTime: endTime || null, venue });
      setExamDate(""); setStartTime(""); setEndTime(""); setVenue("");
      load();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    try {
      await api.deleteExamTimetableEntry(id);
      load();
    } catch (err) {
      setError(err.message);
    }
  };

  const fmtTime = (t) => {
    if (!t) return "—";
    const [h, m] = t.split(":");
    const hour = parseInt(h, 10);
    const ampm = hour >= 12 ? "PM" : "AM";
    const hr12 = hour % 12 === 0 ? 12 : hour % 12;
    return `${hr12}:${m} ${ampm}`;
  };

  const selectStyle = { width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, background: "#fff", boxSizing: "border-box" };

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 24 }}>Exam Timetable</h2>

      <SectionCard title="Upload Exam Timetable Document">
        <p style={{ fontSize: 13, color: COLORS.textMuted, marginTop: 0, marginBottom: 16 }}>
          Upload the official timetable as a PDF or image instead of entering each exam slot by hand — students will see it on their Exam Timetable page.
        </p>
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
          <div>
            <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Academic Year</label>
            <select value={docYear} onChange={e => setDocYear(e.target.value)} style={selectStyle}>
              <option value="">Select Year</option>
              <option value="1">Year 1</option><option value="2">Year 2</option><option value="3">Year 3</option><option value="4">Year 4</option>
            </select>
          </div>
          <div>
            <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Semester</label>
            <select value={docSemester} onChange={e => setDocSemester(e.target.value)} style={selectStyle}>
              <option value="">Select Semester</option>
              <option value="1">Semester I</option><option value="2">Semester II</option>
            </select>
          </div>
        </div>
        <div style={{ marginTop: 16 }}>
          <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Title (optional)</label>
          <input value={docTitle} onChange={e => setDocTitle(e.target.value)} placeholder="e.g. Semester I 2025/26 Exam Timetable" style={{ ...selectStyle, background: "#fff" }} />
        </div>
        <div style={{ marginTop: 16 }}>
          <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Document (PDF or image)</label>
          <input type="file" accept=".pdf,.jpg,.jpeg,.png,.webp" onChange={e => setDocFile(e.target.files[0] || null)} style={selectStyle} />
        </div>
        {docError && <div style={{ color: COLORS.danger, fontSize: 13, marginTop: 14, fontWeight: 600 }}>{docError}</div>}
        <button onClick={handleUploadDocument} disabled={docSaving} style={{ marginTop: 16, background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.accent})`, color: "#fff", border: "none", borderRadius: 10, padding: "11px 24px", fontWeight: 700, fontSize: 14, cursor: docSaving ? "default" : "pointer", opacity: docSaving ? 0.7 : 1 }}>
          {docSaving ? "Uploading…" : "Upload Document"}
        </button>

        {documents && documents.length > 0 && (
          <div style={{ marginTop: 24, borderTop: `1px solid ${COLORS.border}`, paddingTop: 18 }}>
            {documents.map(d => (
              <div key={d.id} style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "10px 14px", background: COLORS.bg, borderRadius: 8, marginBottom: 8 }}>
                <div>
                  <div style={{ fontWeight: 700, fontSize: 14, color: COLORS.textPrimary }}>{d.title}</div>
                  <div style={{ fontSize: 12, color: COLORS.textMuted }}>Year {d.year} · Semester {d.semester} · {d.original_name} · Uploaded {new Date(d.uploaded_at).toLocaleDateString()}</div>
                </div>
                <div style={{ display: "flex", gap: 8 }}>
                  <a href={fileUrl(d.file_path)} target="_blank" rel="noreferrer" style={{ background: COLORS.primary + "18", color: COLORS.primary, border: "none", borderRadius: 6, padding: "6px 12px", fontSize: 12, fontWeight: 600, textDecoration: "none" }}>View</a>
                  <button onClick={() => handleDeleteDocument(d.id)} style={{ background: COLORS.danger + "18", color: COLORS.danger, border: "none", borderRadius: 6, padding: "6px 12px", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>Delete</button>
                </div>
              </div>
            ))}
          </div>
        )}
      </SectionCard>

      <SectionCard title="Add Exam Slot">
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
          <div>
            <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Academic Year</label>
            <select value={year} onChange={e => setYear(e.target.value)} style={{ width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, background: "#fff" }}>
              <option value="">Select Year</option>
              <option value="1">Year 1</option><option value="2">Year 2</option><option value="3">Year 3</option><option value="4">Year 4</option>
            </select>
          </div>
          <div>
            <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Semester</label>
            <select value={semester} onChange={e => setSemester(e.target.value)} style={{ width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, background: "#fff" }}>
              <option value="">Select Semester</option>
              <option value="1">Semester I</option><option value="2">Semester II</option>
            </select>
          </div>
        </div>
        {year && semester && (
          <>
            <div style={{ marginTop: 16, marginBottom: 18 }}>
              <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Course</label>
              <select value={courseId} onChange={e => setCourseId(e.target.value)} style={{ width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, background: "#fff" }}>
                {courses.map(c => <option key={c.id} value={c.id}>{c.code} — {c.name}</option>)}
              </select>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr 1fr", gap: 14 }}>
              <div>
                <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Date</label>
                <input type="date" value={examDate} onChange={e => setExamDate(e.target.value)} style={{ width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, boxSizing: "border-box" }} />
              </div>
              <div>
                <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Start Time</label>
                <input type="time" value={startTime} onChange={e => setStartTime(e.target.value)} style={{ width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, boxSizing: "border-box" }} />
              </div>
              <div>
                <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>End Time</label>
                <input type="time" value={endTime} onChange={e => setEndTime(e.target.value)} style={{ width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, boxSizing: "border-box" }} />
              </div>
              <div>
                <label style={{ display: "block", fontSize: 13, fontWeight: 600, color: COLORS.textSecondary, marginBottom: 6 }}>Venue</label>
                <input value={venue} onChange={e => setVenue(e.target.value)} placeholder="e.g. Hall A-201" style={{ width: "100%", padding: "10px 14px", borderRadius: 8, border: `1px solid ${COLORS.border}`, fontSize: 14, boxSizing: "border-box" }} />
              </div>
            </div>
            {error && <div style={{ color: COLORS.danger, fontSize: 13, marginTop: 14, fontWeight: 600 }}>{error}</div>}
            <button onClick={handleAdd} disabled={saving} style={{ marginTop: 16, background: `linear-gradient(135deg, ${COLORS.primary}, ${COLORS.accent})`, color: "#fff", border: "none", borderRadius: 10, padding: "11px 24px", fontWeight: 700, fontSize: 14, cursor: saving ? "default" : "pointer", opacity: saving ? 0.7 : 1 }}>
              {saving ? "Adding…" : "Add to Timetable"}
            </button>
          </>
        )}
      </SectionCard>

      <SectionCard title="Published Exam Timetable">
        {!entries ? (
          <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading…</div>
        ) : entries.length === 0 ? (
          <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No exam slots published yet.</div>
        ) : (
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 14 }}>
            <thead>
              <tr style={{ background: COLORS.bg }}>
                {["Subject", "Year/Sem", "Date", "Time", "Venue", ""].map((h, i) => (
                  <th key={i} style={{ padding: "11px 14px", textAlign: "left", color: COLORS.textSecondary, fontWeight: 600, fontSize: 12, textTransform: "uppercase" }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {entries.map((e) => (
                <tr key={e.id} style={{ borderBottom: `1px solid ${COLORS.border}` }}>
                  <td style={{ padding: "12px 14px" }}>
                    <div style={{ fontWeight: 700, color: COLORS.primary, fontSize: 13 }}>{e.code}</div>
                    <div style={{ fontSize: 13, color: COLORS.textPrimary }}>{e.course_name}</div>
                  </td>
                  <td style={{ padding: "12px 14px" }}>Y{e.year}/S{e.semester}</td>
                  <td style={{ padding: "12px 14px" }}>{new Date(e.exam_date).toLocaleDateString()}</td>
                  <td style={{ padding: "12px 14px" }}>{fmtTime(e.start_time)}{e.end_time ? ` – ${fmtTime(e.end_time)}` : ""}</td>
                  <td style={{ padding: "12px 14px" }}>{e.venue || "—"}</td>
                  <td style={{ padding: "12px 14px" }}>
                    <button onClick={() => handleDelete(e.id)} style={{ background: COLORS.danger + "18", color: COLORS.danger, border: "none", borderRadius: 6, padding: "5px 10px", fontSize: 12, fontWeight: 600, cursor: "pointer" }}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </SectionCard>
    </div>
  );
};

// ── Lecturer: Semester Registration View ──────────────────────────────────────
const LectureSemesterReg = () => {
  const [classes, setClasses] = useState(null);
  const [regs, setRegs] = useState(null);
  const [error, setError] = useState("");

  useEffect(() => {
    Promise.all([api.myClasses(), api.allSemRegs()])
      .then(([cs, rs]) => { setClasses(cs); setRegs(rs); })
      .catch(err => setError(err.message));
  }, []);

  if (error) return <div style={{ color: COLORS.danger, fontSize: 14 }}>{error}</div>;
  if (!classes || !regs) return <div style={{ color: COLORS.textMuted, fontSize: 14 }}>Loading…</div>;

  const perModule = classes.map(c => {
    const matching = regs.filter(r => (r.courses || []).some(rc => rc.code === c.code));
    const pending = matching.filter(r => r.status === "payment_pending").length;
    return { ...c, registered: matching.length, pending };
  });

  const totalRegistered = perModule.reduce((s, m) => s + m.registered, 0);
  const totalPending = perModule.reduce((s, m) => s + m.pending, 0);

  return (
    <div>
      <h2 style={{ fontSize: 24, fontWeight: 700, color: COLORS.textPrimary, marginBottom: 8 }}>Semester Registration</h2>
      <p style={{ color: COLORS.textMuted, marginBottom: 24, fontSize: 14 }}>View registrations for your modules this semester</p>
      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginBottom: 24 }}>
        <StatCard label="Registered Students" value={String(totalRegistered)} icon="students" color={COLORS.accent} />
        <StatCard label="Pending Payments" value={String(totalPending)} icon="payment" color={COLORS.warning} />
      </div>
      {perModule.length === 0 ? <div style={{ color: COLORS.textMuted, fontSize: 14 }}>No modules assigned.</div> : perModule.map((m) => (
        <SectionCard key={m.course_id} title={`${m.code} — ${m.name}`}>
          <div style={{ display: "flex", gap: 16 }}>
            <div style={{ background: COLORS.bg, borderRadius: 8, padding: "10px 16px", flex: 1, textAlign: "center" }}>
              <div style={{ fontSize: 22, fontWeight: 800, color: COLORS.primary }}>{m.registered}</div>
              <div style={{ fontSize: 12, color: COLORS.textMuted }}>Registered</div>
            </div>
            <div style={{ background: COLORS.bg, borderRadius: 8, padding: "10px 16px", flex: 1, textAlign: "center" }}>
              <div style={{ fontSize: 22, fontWeight: 800, color: COLORS.warning }}>{m.pending}</div>
              <div style={{ fontSize: 12, color: COLORS.textMuted }}>Payment Pending</div>
            </div>
          </div>
        </SectionCard>
      ))}
    </div>
  );
};

// ═══════════════════════════════════════════════════════════════════════════════
// PORTAL CONFIGURATIONS
// ═══════════════════════════════════════════════════════════════════════════════

const PORTALS = {
  student: {
    label: "Student Portal",
    user: "M.D. K. Ridmi",
    role: "21APP5710 · B.Sc. Physical Sciences (C3)",
    color: COLORS.primary,
    menu: [
      { id: "dashboard", label: "Dashboard", icon: "dashboard", component: StudentDashboard },
      { id: "profile", label: "Student Profile", icon: "user", component: StudentProfile },
      { id: "modules", label: "My Modules", icon: "modules", component: StudentModules },
      { id: "coursecatalog", label: "Course Registration", icon: "catalog", component: StudentCourseRegistration },
      { id: "attendance", label: "My Attendance", icon: "attendance", component: StudentAttendance },
      { id: "results", label: "My Results", icon: "results", component: StudentResults },
      { id: "assignments", label: "Assignments", icon: "report", component: StudentAssignments },
      { id: "materials", label: "Lecture Materials", icon: "modules", component: StudentMaterials },
      { id: "examtimetable", label: "Exam Timetable", icon: "attendance", component: StudentExamTimetable },
      { id: "semreg", label: "Semester Registration", icon: "registration", component: StudentSemesterReg },
      { id: "exam", label: "Exam Application", icon: "exam", component: StudentExamApp },
      { id: "notices", label: "Notices", icon: "notices", component: StudentNotices },
      { id: "wellbeing", label: "Wellbeing Check-In", icon: "wellbeing", component: StudentWellbeing },
    ],
  },
  lecture: {
    label: "Lecturer Portal",
    user: "Dr. A. A. Perera",
    role: "Senior Lecturer · PST Dept.",
    color: "#2D6A4F",
    menu: [
      { id: "dashboard", label: "Dashboard", icon: "dashboard", component: LectureDashboard },
      { id: "profile", label: "Lecturer Profile", icon: "user", component: LectureProfile },
      { id: "classes", label: "My Classes", icon: "classes", component: LectureClasses },
      { id: "coursecatalog", label: "Course Catalog", icon: "catalog", component: AdminCourseCatalog },
      { id: "mark", label: "Mark Attendance", icon: "mark", component: LectureMarkAttendance },
      { id: "results", label: "Enter Results", icon: "enter", component: LectureEnterResults },
      { id: "semreg", label: "Semester Registration", icon: "registration", component: LectureSemesterReg },
      { id: "exam", label: "Exam Applications", icon: "exam", component: LectureExamApps },
      { id: "notice", label: "Post Notice", icon: "post", component: LecturePostNotice },
      { id: "assignments", label: "Post Assignment", icon: "report", component: LecturePostAssignment },
      { id: "materials", label: "Upload Materials", icon: "modules", component: LectureUploadMaterials },
      { id: "wellbeing", label: "Student Wellbeing", icon: "wellbeing", component: LectureWellbeing },
    ],
  },
  admin: {
    label: "Admin Portal",
    user: "Admin",
    role: "System Administrator",
    color: "#7B2D8B",
    menu: [
      { id: "dashboard", label: "Dashboard", icon: "dashboard", component: AdminDashboard },
      { id: "students", label: "All Students", icon: "students", component: AdminAllStudents },
      { id: "registrations", label: "New Registrations", icon: "registration", component: AdminNewRegistrations },
      { id: "attendance", label: "Attendance Reports", icon: "report", component: AdminAttendanceReports },
      { id: "results", label: "Results Overview", icon: "results", component: AdminResultsOverview },
      { id: "semreg", label: "Semester Registration", icon: "registration", component: AdminSemesterReg },
      { id: "enrollment", label: "Enrollment Management", icon: "registration", component: AdminEnrollmentManagement },
      { id: "examtimetable", label: "Exam Timetable", icon: "attendance", component: AdminExamTimetable },
      { id: "exam", label: "Exam Applications", icon: "exam", component: AdminExamApps },
      { id: "catalog", label: "Course Catalog", icon: "catalog", component: AdminCourseCatalog },
      { id: "payments", label: "Payment Management", icon: "payment", component: AdminPaymentManagement },
      { id: "notices", label: "Notices", icon: "notices", component: AdminNotices },
      { id: "wellbeing", label: "Wellbeing Reports", icon: "wellbeing", component: AdminWellbeingReports },
      { id: "counseling", label: "Counseling Sessions", icon: "counseling", component: AdminCounseling },
      { id: "settings", label: "System Settings", icon: "settings", component: AdminSettings },
    ],
  },
};

// ═══════════════════════════════════════════════════════════════════════════════
// REGISTRATION & LOGIN SYSTEM
// ═══════════════════════════════════════════════════════════════════════════════

// Shared background wrapper
const AuthBg = ({ children, wide = false }) => (
  <div style={{ minHeight: "100vh", background: `linear-gradient(135deg, ${COLORS.gradStart} 0%, ${COLORS.gradEnd} 55%, ${COLORS.accent}44 100%)`, display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Inter','Segoe UI',sans-serif", padding: 24 }}>
    <div style={{ width: "100%", maxWidth: wide ? 680 : 480 }}>
      {/* Header */}
      <div style={{ textAlign: "center", marginBottom: 28 }}>
        <div style={{ width: 60, height: 60, background: "rgba(255,255,255,0.15)", borderRadius: 16, display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 12px", backdropFilter: "blur(10px)" }}>
          <Icon name="graduation" size={28} color="#fff" />
        </div>
        <h1 style={{ color: "#fff", fontSize: 22, fontWeight: 800, margin: 0 }}>PST Department</h1>
        <p style={{ color: "rgba(255,255,255,0.6)", marginTop: 2, fontSize: 12 }}>Student Management System</p>
      </div>
      <div style={{ background: "rgba(255,255,255,0.96)", borderRadius: 20, padding: 32, boxShadow: "0 24px 64px rgba(0,0,0,0.25)" }}>
        {children}
      </div>
    </div>
  </div>
);

// Shared input style
const iSt = { width: "100%", padding: "11px 14px", borderRadius: 10, border: `1.5px solid ${COLORS.border}`, fontSize: 14, outline: "none", boxSizing: "border-box", fontFamily: "inherit", transition: "border 0.2s" };
const lSt = { display: "block", fontSize: 12, fontWeight: 700, color: COLORS.textSecondary, marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.04em" };

// ── STEP TRACKER ──────────────────────────────────────────────────────────────
const RegStepBar = ({ current, steps, color }) => (
  <div style={{ display: "flex", alignItems: "center", marginBottom: 28 }}>
    {steps.map((s, i) => {
      const done = current > i + 1; const active = current === i + 1;
      return (
        <div key={i} style={{ display: "flex", alignItems: "center", flex: i < steps.length - 1 ? 1 : "none" }}>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 3 }}>
            <div style={{ width: 30, height: 30, borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontWeight: 700, fontSize: 12, background: done ? COLORS.success : active ? (color || COLORS.primary) : COLORS.border, color: done || active ? "#fff" : COLORS.textMuted, transition: "all 0.3s" }}>{done ? "✓" : i + 1}</div>
            <div style={{ fontSize: 10, fontWeight: active ? 700 : 500, color: active ? (color || COLORS.primary) : done ? COLORS.success : COLORS.textMuted, whiteSpace: "nowrap" }}>{s}</div>
          </div>
          {i < steps.length - 1 && <div style={{ flex: 1, height: 2, background: done ? COLORS.success : COLORS.border, margin: "0 6px", marginBottom: 16, transition: "background 0.3s" }} />}
        </div>
      );
    })}
  </div>
);

// ── REGISTRATION SCREEN ───────────────────────────────────────────────────────
const RegisterScreen = ({ onDone, onBack }) => {
  const [step, setStep] = useState(1);
  const [role, setRole] = useState("");
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const [otpSent, setOtpSent] = useState(false);
  const [otpSending, setOtpSending] = useState(false);
  const [otpVerifying, setOtpVerifying] = useState(false);
  const [otpError, setOtpError] = useState("");
  const [otpVerified, setOtpVerified] = useState(false);
  const [credentials, setCredentials] = useState({ regNo: "", password: "", confirmPwd: "" });
  const [showPwd, setShowPwd] = useState(false);
  const [errors, setErrors] = useState({});

  // Personal details
  const [personal, setPersonal] = useState({
    firstName: "", lastName: "", dob: "", gender: "", nic: "", phone: "", email: "", address: "", district: "",
  });
  // Academic details
  const [academic, setAcademic] = useState({
    indexNo: "", year: "", semester: "", combination: "", faculty: "Faculty of Applied Sciences", programme: "", alYear: "", alStream: "", alResults: "",
  });

  const portalColors = { student: COLORS.primary, lecture: "#2D6A4F", admin: "#7B2D8B" };
  const col = portalColors[role] || COLORS.primary;

  const steps = ["Select Role", "Personal Details", "Academic Details", "OTP Verify", "Set Credentials"];

  const pErr = {};
  const validatePersonal = () => {
    if (!personal.firstName.trim()) pErr.firstName = "Required";
    if (!personal.lastName.trim()) pErr.lastName = "Required";
    if (!personal.dob) pErr.dob = "Required";
    if (!personal.gender) pErr.gender = "Required";
    if (!personal.nic.trim()) pErr.nic = "Required";
    if (!personal.phone.trim()) pErr.phone = "Required";
    if (!personal.email.trim() || !personal.email.includes("@")) pErr.email = "Valid email required";
    setErrors(pErr);
    return Object.keys(pErr).length === 0;
  };
  const validateAcademic = () => {
    const aErr = {};
    if (role === "student") {
      if (!academic.indexNo.trim()) aErr.indexNo = "Required";
      if (!academic.year) aErr.year = "Required";
      if (!academic.combination) aErr.combination = "Required";
      if (!academic.programme) aErr.programme = "Required";
    }
    if (role === "lecture") {
      if (!academic.indexNo.trim()) aErr.indexNo = "Required";
      if (!academic.programme) aErr.programme = "Required";
    }
    setErrors(aErr);
    return Object.keys(aErr).length === 0;
  };

  const sendOtp = async () => {
    if (!personal.email) { setOtpError("No email address on file."); return; }
    setOtpSending(true);
    setOtpError("");
    try {
      await api.sendOtp(personal.email);
      setOtpSent(true);
      setOtp(["", "", "", "", "", ""]);
    } catch (err) {
      setOtpError(err.message);
    } finally {
      setOtpSending(false);
    }
  };

  const verifyOtp = async () => {
    const entered = otp.join("");
    if (entered.length !== 6) { setOtpError("Enter the full 6-digit code."); return; }
    setOtpVerifying(true);
    setOtpError("");
    try {
      await api.verifyOtp(personal.email, entered);
      setOtpVerified(true);
      setStep(5);
    } catch (err) {
      setOtpError(err.message);
    } finally {
      setOtpVerifying(false);
    }
  };

  const handleOtpChange = (val, idx) => {
    const d = val.replace(/\D/g, "").slice(0, 1);
    const next = [...otp]; next[idx] = d; setOtp(next);
    if (d && idx < 5) document.getElementById(`otp-${idx + 1}`)?.focus();
    if (!d && idx > 0) document.getElementById(`otp-${idx - 1}`)?.focus();
  };

  const generateRegNo = () => {
    const prefix = role === "student" ? academic.indexNo || `${new Date().getFullYear().toString().slice(2)}APP` : role === "lecture" ? "LEC" : "ADM";
    return role === "student" ? (academic.indexNo || `${new Date().getFullYear().toString().slice(2)}APP${Math.floor(1000 + Math.random() * 9000)}`) : `${prefix}${Math.floor(100 + Math.random() * 900)}`;
  };
  const [autoRegNo] = useState(() => "");

  const [submitError, setSubmitError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const submitRegistration = async () => {
    const cErr = {};
    if (!credentials.password || credentials.password.length < 8) cErr.password = "Minimum 8 characters";
    if (credentials.password !== credentials.confirmPwd) cErr.confirmPwd = "Passwords do not match";
    setErrors(cErr);
    if (Object.keys(cErr).length > 0) return;

    const regNo = credentials.regNo || generateRegNo();

    if (role !== "student") {
      // Lecturer/Admin accounts are created by an administrator, not self-registered —
      // this stays a demo confirmation screen until that admin workflow exists.
      onDone(role, regNo);
      return;
    }

    setSubmitError("");
    setSubmitting(true);
    try {
      await api.registerStudent({
        username: regNo,
        password: credentials.password,
        full_name: `${personal.firstName} ${personal.lastName}`.trim(),
        email: personal.email,
        phone: personal.phone,
        intake_year: academic.alYear ? parseInt(academic.alYear, 10) % 100 : undefined,
        program: academic.programme || "B.Sc. Physical Sciences",
        batch: academic.combination,
        date_of_birth: personal.dob,
        gender: personal.gender,
        nic: personal.nic,
        address: personal.address,
      });
      onDone(role, regNo);
    } catch (err) {
      setSubmitError(err.message);
    } finally {
      setSubmitting(false);
    }
  };

  const inp = (key, val, setter, label, type = "text", opts = null, err = null) => (
    <div key={key}>
      <label style={lSt}>{label}</label>
      {opts ? (
        <select value={val} onChange={e => setter(e.target.value)} style={{ ...iSt, border: `1.5px solid ${err ? COLORS.danger : COLORS.border}`, cursor: "pointer" }}>
          <option value="">Select…</option>
          {opts.map(o => <option key={o} value={o}>{o}</option>)}
        </select>
      ) : (
        <input type={type} value={val} onChange={e => setter(e.target.value)} style={{ ...iSt, border: `1.5px solid ${err ? COLORS.danger : COLORS.border}` }} />
      )}
      {err && <div style={{ fontSize: 11, color: COLORS.danger, marginTop: 3 }}>{err}</div>}
    </div>
  );

  return (
    <AuthBg wide={step >= 2 && step <= 3}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
        <h2 style={{ margin: 0, fontSize: 18, fontWeight: 800, color: COLORS.textPrimary }}>Create Account</h2>
        <button onClick={onBack} style={{ background: "none", border: "none", fontSize: 13, color: COLORS.textMuted, cursor: "pointer" }}>← Back to Sign In</button>
      </div>
      <RegStepBar current={step} steps={steps} color={col} />

      {/* ── STEP 1: Role ── */}
      {step === 1 && (
        <div>
          <p style={{ fontSize: 13, color: COLORS.textMuted, marginBottom: 18 }}>Select the type of account you are registering.</p>
          {[{ id: "student", lbl: "Student", desc: "B.Sc. / Honours degree student", icon: "students" }, { id: "lecture", lbl: "Lecturer / Staff", desc: "Academic or non-academic staff member", icon: "classes" }, { id: "admin", lbl: "Administrator", desc: "System administrator (requires admin approval)", icon: "shieldAdmin" }].map(p => (
            <div key={p.id} onClick={() => setRole(p.id)} style={{ display: "flex", alignItems: "center", gap: 14, padding: "14px 16px", borderRadius: 12, border: `2px solid ${role === p.id ? portalColors[p.id] : COLORS.border}`, background: role === p.id ? portalColors[p.id] + "08" : "#fff", cursor: "pointer", marginBottom: 10, transition: "all 0.2s" }}>
              <div style={{ width: 44, height: 44, background: portalColors[p.id] + "15", borderRadius: 12, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Icon name={p.icon} size={20} color={portalColors[p.id]} /></div>
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, fontSize: 14, color: COLORS.textPrimary }}>{p.lbl}</div>
                <div style={{ fontSize: 12, color: COLORS.textMuted, marginTop: 2 }}>{p.desc}</div>
              </div>
              {role === p.id && <Icon name="check" size={16} color={portalColors[p.id]} />}
            </div>
          ))}
          <button onClick={() => role && setStep(2)} style={{ width: "100%", marginTop: 8, padding: "13px", background: role ? `linear-gradient(135deg, ${col}, ${COLORS.primaryLight})` : COLORS.border, color: role ? "#fff" : COLORS.textMuted, border: "none", borderRadius: 12, fontWeight: 700, fontSize: 15, cursor: role ? "pointer" : "not-allowed" }}>
            Next: Personal Details →
          </button>
        </div>
      )}

      {/* ── STEP 2: Personal Details ── */}
      {step === 2 && (
        <div>
          <div style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "6px 12px", borderRadius: 8, background: col + "12", border: `1px solid ${col}30`, marginBottom: 18 }}>
            <Icon name={role === "student" ? "students" : role === "lecture" ? "classes" : "shieldAdmin"} size={14} color={col} />
            <span style={{ fontSize: 13, fontWeight: 700, color: col }}>{role === "student" ? "Student Registration" : role === "lecture" ? "Lecturer Registration" : "Admin Registration"}</span>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
            {inp("fn", personal.firstName, v => setPersonal(p => ({ ...p, firstName: v })), "First Name", "text", null, errors.firstName)}
            {inp("ln", personal.lastName, v => setPersonal(p => ({ ...p, lastName: v })), "Last Name", "text", null, errors.lastName)}
            {inp("dob", personal.dob, v => setPersonal(p => ({ ...p, dob: v })), "Date of Birth", "date", null, errors.dob)}
            {inp("gen", personal.gender, v => setPersonal(p => ({ ...p, gender: v })), "Gender", "text", ["Male", "Female", "Prefer not to say"], errors.gender)}
            {inp("nic", personal.nic, v => setPersonal(p => ({ ...p, nic: v })), "NIC Number", "text", null, errors.nic)}
            {inp("ph", personal.phone, v => setPersonal(p => ({ ...p, phone: v })), "Mobile Number", "tel", null, errors.phone)}
          </div>
          <div style={{ marginTop: 4 }}>{inp("em", personal.email, v => setPersonal(p => ({ ...p, email: v })), "Email Address", "email", null, errors.email)}</div>
          <div style={{ marginTop: 4 }}>{inp("addr", personal.address, v => setPersonal(p => ({ ...p, address: v })), "Permanent Address", "text", null, errors.address)}</div>
          {inp("dist", personal.district, v => setPersonal(p => ({ ...p, district: v })), "District", "text", ["Colombo", "Gampaha", "Kalutara", "Kandy", "Matale", "Nuwara Eliya", "Galle", "Matara", "Hambantota", "Jaffna", "Kilinochchi", "Mannar", "Vavuniya", "Mullaitivu", "Batticaloa", "Ampara", "Trincomalee", "Kurunegala", "Puttalam", "Anuradhapura", "Polonnaruwa", "Badulla", "Monaragala", "Ratnapura", "Kegalle"], null)}
          <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
            <button onClick={() => setStep(1)} style={{ flex: 1, padding: "12px", background: COLORS.bg, color: COLORS.textSecondary, border: `1px solid ${COLORS.border}`, borderRadius: 12, fontWeight: 700, fontSize: 14, cursor: "pointer" }}>← Back</button>
            <button onClick={() => { if (validatePersonal()) setStep(3); }} style={{ flex: 2, padding: "12px", background: `linear-gradient(135deg, ${col}, ${COLORS.primaryLight})`, color: "#fff", border: "none", borderRadius: 12, fontWeight: 700, fontSize: 14, cursor: "pointer" }}>
              Next: Academic Details →
            </button>
          </div>
        </div>
      )}

      {/* ── STEP 3: Academic Details ── */}
      {step === 3 && (
        <div>
          <p style={{ fontSize: 13, color: COLORS.textMuted, marginBottom: 16 }}>Enter your academic information below.</p>
          {role === "student" && (
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
              <div>
                <label style={lSt}>Index Number</label>
                <input value={academic.indexNo} onChange={e => setAcademic(p => ({ ...p, indexNo: e.target.value.toUpperCase() }))} placeholder="e.g. 21APP5710" style={{ ...iSt, fontFamily: "monospace", letterSpacing: "0.1em", border: `1.5px solid ${errors.indexNo ? COLORS.danger : COLORS.border}` }} />
                {errors.indexNo && <div style={{ fontSize: 11, color: COLORS.danger, marginTop: 3 }}>Required</div>}
                <div style={{ fontSize: 11, color: COLORS.textMuted, marginTop: 4 }}>21=4th Yr · 22=3rd Yr · 23=2nd Yr · 24=1st Yr</div>
              </div>
              {inp("yr", academic.year, v => setAcademic(p => ({ ...p, year: v })), "Current Year", "text", ["Year 1 (1st Year)", "Year 2 (2nd Year)", "Year 3 (3rd Year)", "Year 4 (4th Year)"], errors.year)}
              {inp("sem", academic.semester, v => setAcademic(p => ({ ...p, semester: v })), "Current Semester", "text", ["Semester I", "Semester II"], null)}
              {inp("comb", academic.combination, v => setAcademic(p => ({ ...p, combination: v })), "Combination", "text", ["C1 — Applied Physics", "C2 — Chemical Technology", "C3 — Computer Science & Technology"], errors.combination)}
              {inp("prog", academic.programme, v => setAcademic(p => ({ ...p, programme: v })), "Programme", "text", ["B.Sc. Physical Sciences (General Degree)", "B.Sc. Hons. Applied Physics", "B.Sc. Hons. Chemical Technology", "B.Sc. Hons. Computer Science & Technology"], errors.programme)}
              {inp("fac", academic.faculty, v => setAcademic(p => ({ ...p, faculty: v })), "Faculty", "text", ["Faculty of Applied Sciences"], null)}
              {inp("aly", academic.alYear, v => setAcademic(p => ({ ...p, alYear: v })), "A/L Examination Year", "text", null, null)}
              {inp("als", academic.alStream, v => setAcademic(p => ({ ...p, alStream: v })), "A/L Stream", "text", ["Physical Science", "Biological Science", "Engineering Technology", "Bio Technology"], null)}
            </div>
          )}
          {role === "lecture" && (
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
              {inp("sid", academic.indexNo, v => setAcademic(p => ({ ...p, indexNo: v.toUpperCase() })), "Staff ID", "text", null, errors.indexNo)}
              {inp("prog", academic.programme, v => setAcademic(p => ({ ...p, programme: v })), "Designation", "text", ["Professor", "Associate Professor", "Senior Lecturer", "Lecturer", "Demonstrator", "Instructor", "Non-Academic Staff"], errors.programme)}
              {inp("fac", academic.faculty, v => setAcademic(p => ({ ...p, faculty: v })), "Department", "text", ["Department of Physical Sciences", "Department of Chemistry", "Department of Computer Science"], null)}
              {inp("comb", academic.combination, v => setAcademic(p => ({ ...p, combination: v })), "Teaching Subject Area", "text", ["Applied Physics", "Chemical Technology", "Computer Science & Technology", "Mathematics / Statistics", "General"], null)}
            </div>
          )}
          {role === "admin" && (
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14 }}>
              {inp("prog", academic.programme, v => setAcademic(p => ({ ...p, programme: v })), "Admin Role", "text", ["System Administrator", "Data Entry Operator", "IT Support", "Registry Officer"], errors.programme)}
              {inp("fac", academic.faculty, v => setAcademic(p => ({ ...p, faculty: v })), "Department", "text", ["PST Department Office", "Faculty IT Unit", "Examinations Division", "Student Affairs"], null)}
            </div>
          )}
          <div style={{ display: "flex", gap: 10, marginTop: 22 }}>
            <button onClick={() => setStep(2)} style={{ flex: 1, padding: "12px", background: COLORS.bg, color: COLORS.textSecondary, border: `1px solid ${COLORS.border}`, borderRadius: 12, fontWeight: 700, fontSize: 14, cursor: "pointer" }}>← Back</button>
            {/* TEMP: OTP step skipped for now — change setStep(5) back to setStep(4) to re-enable */}
            <button onClick={() => { if (validateAcademic()) setStep(5); }} style={{ flex: 2, padding: "12px", background: `linear-gradient(135deg, ${col}, ${COLORS.primaryLight})`, color: "#fff", border: "none", borderRadius: 12, fontWeight: 700, fontSize: 14, cursor: "pointer" }}>
              Next: Set Credentials →
            </button>
          </div>
        </div>
      )}

      {/* ── STEP 4: OTP Verification ── */}
      {step === 4 && (
        <div style={{ textAlign: "center" }}>
          <div style={{ width: 60, height: 60, borderRadius: "50%", background: col + "15", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px" }}><Icon name="phone" size={26} color={col} /></div>
          <h3 style={{ fontSize: 17, fontWeight: 700, color: COLORS.textPrimary, margin: "0 0 6px" }}>OTP Verification</h3>
          <p style={{ fontSize: 13, color: COLORS.textMuted, marginBottom: 20 }}>
            {otpSent ? <>A 6-digit code has been sent to <strong>{personal.email || personal.phone}</strong></> : "We will send a one-time code to your registered email or mobile number."}
          </p>

          {!otpSent ? (
            <div>
              <div style={{ background: COLORS.bg, borderRadius: 12, padding: "14px 18px", marginBottom: 20, textAlign: "left" }}>
                <div style={{ fontSize: 12, color: COLORS.textMuted, marginBottom: 4 }}>Send OTP to:</div>
                <div style={{ fontSize: 15, fontWeight: 700, color: COLORS.textPrimary }}>{personal.email}</div>
                {personal.phone && <div style={{ fontSize: 13, color: COLORS.textMuted, marginTop: 2 }}>{personal.phone}</div>}
              </div>
              {otpError && !otpSent && <div style={{ fontSize: 13, color: COLORS.danger, marginBottom: 14, fontWeight: 600, display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}><Icon name="alert" size={14} color={COLORS.danger} /> {otpError}</div>}
              <button onClick={sendOtp} disabled={otpSending} style={{ width: "100%", padding: "13px", background: `linear-gradient(135deg, ${col}, ${COLORS.primaryLight})`, color: "#fff", border: "none", borderRadius: 12, fontWeight: 700, fontSize: 15, cursor: otpSending ? "default" : "pointer", opacity: otpSending ? 0.7 : 1 }}>
                {otpSending ? "Sending…" : "Send OTP Code"}
              </button>
            </div>
          ) : (
            <div>
              <div style={{ display: "flex", gap: 10, justifyContent: "center", marginBottom: 16 }}>
                {otp.map((d, i) => (
                  <input key={i} id={`otp-${i}`} value={d} onChange={e => handleOtpChange(e.target.value, i)}
                    onKeyDown={e => { if (e.key === "Backspace" && !d && i > 0) document.getElementById(`otp-${i - 1}`)?.focus(); }}
                    maxLength={1} style={{ width: 46, height: 54, borderRadius: 10, border: `2px solid ${otpError ? COLORS.danger : otp[i] ? col : COLORS.border}`, textAlign: "center", fontSize: 22, fontWeight: 700, outline: "none", fontFamily: "monospace", color: COLORS.textPrimary, transition: "border 0.15s" }} />
                ))}
              </div>
              {otpError && <div style={{ fontSize: 13, color: COLORS.danger, marginBottom: 12, fontWeight: 600, display: "flex", alignItems: "center", justifyContent: "center", gap: 6 }}><Icon name="alert" size={14} color={COLORS.danger} /> {otpError}</div>}
              {otpVerified && <div style={{ fontSize: 13, color: COLORS.success, marginBottom: 12, fontWeight: 600 }}>✓ OTP Verified!</div>}
              <div style={{ fontSize: 12, color: COLORS.textMuted, marginBottom: 16 }}>
                Didn't receive it? <span onClick={otpSending ? undefined : sendOtp} style={{ color: col, fontWeight: 700, cursor: otpSending ? "default" : "pointer", opacity: otpSending ? 0.6 : 1 }}>{otpSending ? "Sending…" : "Resend OTP"}</span>
              </div>
              <button onClick={verifyOtp} disabled={otpVerifying} style={{ width: "100%", padding: "13px", background: `linear-gradient(135deg, ${col}, ${COLORS.primaryLight})`, color: "#fff", border: "none", borderRadius: 12, fontWeight: 700, fontSize: 15, cursor: otpVerifying ? "default" : "pointer", opacity: otpVerifying ? 0.7 : 1 }}>
                {otpVerifying ? "Verifying…" : "Verify & Continue →"}
              </button>
            </div>
          )}
          <button onClick={() => setStep(3)} style={{ width: "100%", marginTop: 10, padding: "10px", background: "none", border: "none", fontSize: 13, color: COLORS.textMuted, cursor: "pointer" }}>← Back</button>
        </div>
      )}

      {/* ── STEP 5: Set Credentials ── */}
      {step === 5 && (
        <div>
          <div style={{ background: COLORS.success + "10", border: `1px solid ${COLORS.success}30`, borderRadius: 12, padding: "14px 18px", marginBottom: 24, display: "flex", alignItems: "center", gap: 12 }}>
            <div style={{ width: 36, height: 36, borderRadius: "50%", background: COLORS.success + "18", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}><Icon name="check" size={17} color={COLORS.success} /></div>
            <div>
              <div style={{ fontWeight: 700, fontSize: 14, color: COLORS.success }}>Details Confirmed!</div>
              <div style={{ fontSize: 12, color: COLORS.textMuted, marginTop: 2 }}>Set a password to finish creating your account</div>
            </div>
          </div>

          {/* Generated registration number */}
          <div style={{ background: `linear-gradient(135deg, ${col}15, ${COLORS.accent}15)`, border: `1px solid ${col}30`, borderRadius: 14, padding: "18px 20px", marginBottom: 22 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: COLORS.textSecondary, textTransform: "uppercase", letterSpacing: "0.05em", marginBottom: 6 }}>Your Registration Number</div>
            <div style={{ fontSize: 26, fontWeight: 800, color: col, fontFamily: "monospace", letterSpacing: "0.12em" }}>
              {role === "student" ? (academic.indexNo || `23APP${Math.floor(1000 + Math.random() * 9000)}`) : role === "lecture" ? `LEC${Math.floor(100 + Math.random() * 900)}` : `ADM${Math.floor(100 + Math.random() * 900)}`}
            </div>
            <div style={{ fontSize: 12, color: COLORS.textMuted, marginTop: 6 }}>
              {personal.firstName} {personal.lastName} · {role === "student" ? academic.programme || "B.Sc. Physical Sciences" : role === "lecture" ? academic.programme || "Lecturer" : "Administrator"}
            </div>
            <div style={{ fontSize: 11, color: COLORS.danger, marginTop: 8, fontWeight: 600, display: "flex", alignItems: "center", gap: 5 }}><Icon name="alert" size={12} color={COLORS.danger} /> Please save this number — you will need it to sign in.</div>
          </div>

          <div style={{ marginBottom: 14 }}>
            <label style={lSt}>Registration Number (confirm)</label>
            <input value={credentials.regNo} onChange={e => setCredentials(p => ({ ...p, regNo: e.target.value.toUpperCase() }))}
              placeholder={role === "student" ? "e.g. 21APP5710" : role === "lecture" ? "e.g. LEC205" : "e.g. ADM101"}
              style={{ ...iSt, fontFamily: "monospace", letterSpacing: "0.1em" }} />
          </div>
          <div style={{ marginBottom: 14 }}>
            <label style={lSt}>Create Password</label>
            <div style={{ position: "relative" }}>
              <input type={showPwd ? "text" : "password"} value={credentials.password} onChange={e => setCredentials(p => ({ ...p, password: e.target.value }))}
                placeholder="Minimum 8 characters" style={{ ...iSt, paddingRight: 42, border: `1.5px solid ${errors.password ? COLORS.danger : COLORS.border}` }} />
              <button onClick={() => setShowPwd(!showPwd)} style={{ position: "absolute", right: 12, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", display: "flex", color: COLORS.textMuted }}>
                <Icon name={showPwd ? "eyeOff" : "eye"} size={17} color={COLORS.textMuted} />
              </button>
            </div>
            {errors.password && <div style={{ fontSize: 11, color: COLORS.danger, marginTop: 3 }}>{errors.password}</div>}
            {/* Password strength */}
            {credentials.password && (
              <div style={{ marginTop: 8 }}>
                <div style={{ height: 4, borderRadius: 99, background: COLORS.border }}>
                  <div style={{ height: "100%", borderRadius: 99, transition: "width 0.3s, background 0.3s", width: credentials.password.length < 6 ? "25%" : credentials.password.length < 8 ? "50%" : credentials.password.length < 12 ? "75%" : "100%", background: credentials.password.length < 6 ? COLORS.danger : credentials.password.length < 8 ? COLORS.warning : credentials.password.length < 12 ? COLORS.accentGold : COLORS.success }} />
                </div>
                <div style={{ fontSize: 11, color: COLORS.textMuted, marginTop: 3 }}>{credentials.password.length < 6 ? "Weak" : credentials.password.length < 8 ? "Fair" : credentials.password.length < 12 ? "Good" : "Strong"}</div>
              </div>
            )}
          </div>
          <div style={{ marginBottom: 22 }}>
            <label style={lSt}>Confirm Password</label>
            <input type="password" value={credentials.confirmPwd} onChange={e => setCredentials(p => ({ ...p, confirmPwd: e.target.value }))}
              placeholder="Re-enter your password" style={{ ...iSt, border: `1.5px solid ${errors.confirmPwd ? COLORS.danger : COLORS.border}` }} />
            {errors.confirmPwd && <div style={{ fontSize: 11, color: COLORS.danger, marginTop: 3 }}>{errors.confirmPwd}</div>}
          </div>

          {submitError && (
            <div style={{ background: COLORS.danger + "12", border: `1px solid ${COLORS.danger}30`, borderRadius: 8, padding: "10px 14px", marginBottom: 14, fontSize: 13, color: COLORS.danger, fontWeight: 600, display: "flex", alignItems: "center", gap: 6 }}>
              <Icon name="alert" size={14} color={COLORS.danger} /> {submitError}
            </div>
          )}
          <div style={{ display: "flex", gap: 10 }}>
            <button onClick={() => setStep(4)} style={{ flex: 1, padding: "12px", background: COLORS.bg, color: COLORS.textSecondary, border: `1px solid ${COLORS.border}`, borderRadius: 12, fontWeight: 700, fontSize: 14, cursor: "pointer" }}>← Back</button>
            <button onClick={submitRegistration} disabled={submitting} style={{ flex: 2, padding: "12px", background: `linear-gradient(135deg, ${COLORS.success}, #1a7a4e)`, color: "#fff", border: "none", borderRadius: 12, fontWeight: 700, fontSize: 15, cursor: submitting ? "default" : "pointer", opacity: submitting ? 0.7 : 1 }}>
              {submitting ? "Submitting…" : "Complete Registration"}
            </button>
          </div>
        </div>
      )}
    </AuthBg>
  );
};

// ── REGISTRATION SUCCESS SCREEN ────────────────────────────────────────────────
const RegistrationSuccess = ({ portal, regNo, onSignIn }) => {
  const portalColors = { student: COLORS.primary, lecture: "#2D6A4F", admin: "#7B2D8B" };
  const col = portalColors[portal] || COLORS.primary;
  return (
    <AuthBg>
      <div style={{ textAlign: "center" }}>
        <div style={{ width: 72, height: 72, borderRadius: "50%", background: COLORS.success + "18", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px" }}><Icon name="sparkle" size={32} color={COLORS.success} /></div>
        <h2 style={{ fontSize: 22, fontWeight: 800, color: COLORS.textPrimary, margin: "0 0 8px" }}>Registration Complete!</h2>
        <p style={{ fontSize: 14, color: COLORS.textMuted, marginBottom: 24 }}>Your PST Department account has been created successfully.</p>
        <div style={{ background: `linear-gradient(135deg, ${col}12, ${COLORS.accent}12)`, border: `1px solid ${col}30`, borderRadius: 14, padding: "20px 24px", marginBottom: 24 }}>
          <div style={{ fontSize: 12, color: COLORS.textMuted, marginBottom: 6, textTransform: "uppercase", letterSpacing: "0.05em" }}>Your Registration Number</div>
          <div style={{ fontSize: 28, fontWeight: 800, color: col, fontFamily: "monospace", letterSpacing: "0.15em" }}>{regNo}</div>
          <div style={{ fontSize: 12, color: COLORS.textMuted, marginTop: 8 }}>{portal === "student" ? "Student Portal" : portal === "lecture" ? "Lecturer Portal" : "Admin Portal"}</div>
        </div>
        <div style={{ background: COLORS.warning + "15", border: `1px solid ${COLORS.warning}40`, borderRadius: 10, padding: "12px 16px", marginBottom: 22, fontSize: 13, color: "#92400e", textAlign: "left" }}>
          <strong style={{ display: "inline-flex", alignItems: "center", gap: 5 }}><Icon name="alert" size={13} color="#92400e" /> Important:</strong> Please save your Registration Number and Password securely. You will need them to sign in.
        </div>
        <button onClick={onSignIn} style={{ width: "100%", padding: "13px", background: `linear-gradient(135deg, ${col}, ${COLORS.primaryLight})`, color: "#fff", border: "none", borderRadius: 12, fontWeight: 700, fontSize: 15, cursor: "pointer" }}>
          Sign In Now →
        </button>
      </div>
    </AuthBg>
  );
};

// ── LOGIN SCREEN ──────────────────────────────────────────────────────────────
const LoginScreen = ({ onLogin, onRegister }) => {
  const [selected, setSelected] = useState(null);
  const [regNo, setRegNo] = useState("");
  const [password, setPassword] = useState("");
  const [showPwd, setShowPwd] = useState(false);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const col = selected === "student" ? COLORS.primary : selected === "lecture" ? "#2D6A4F" : "#7B2D8B";
  const roleMap = { student: "student", lecture: "lecturer", admin: "admin" };

  const handleLogin = async () => {
    if (!selected) { setError("Please select a portal."); return; }
    if (!regNo.trim()) { setError("Please enter your registration number."); return; }
    if (!password.trim()) { setError("Please enter your password."); return; }
    setError("");
    setLoading(true);
    try {
      const { token, user } = await api.login(regNo.trim(), password, roleMap[selected]);
      setToken(token);
      onLogin(selected, user);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <AuthBg>
      <h2 style={{ fontSize: 18, fontWeight: 800, color: COLORS.textPrimary, marginTop: 0, marginBottom: 18 }}>Sign In to Your Portal</h2>

      {/* Portal selector */}
      <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
        {[{ id: "student", lbl: "Student", icon: "students" }, { id: "lecture", lbl: "Lecturer", icon: "classes" }, { id: "admin", lbl: "Admin", icon: "shieldAdmin" }].map(p => {
          const c = p.id === "student" ? COLORS.primary : p.id === "lecture" ? "#2D6A4F" : "#7B2D8B";
          return (
            <div key={p.id} onClick={() => { setSelected(p.id); setError(""); }}
              style={{ flex: 1, padding: "12px 8px", borderRadius: 12, border: `2px solid ${selected === p.id ? c : COLORS.border}`, background: selected === p.id ? c + "10" : "#fff", cursor: "pointer", textAlign: "center", transition: "all 0.2s" }}>
              <div style={{ display: "flex", justifyContent: "center", marginBottom: 4 }}><Icon name={p.icon} size={19} color={selected === p.id ? c : COLORS.textMuted} /></div>
              <div style={{ fontSize: 12, fontWeight: 700, color: selected === p.id ? c : COLORS.textSecondary }}>{p.lbl}</div>
            </div>
          );
        })}
      </div>

      {/* Credentials */}
      <div style={{ marginBottom: 12 }}>
        <label style={lSt}>Registration Number / Index Number</label>
        <input value={regNo} onChange={e => { setRegNo(e.target.value.toUpperCase()); setError(""); }}
          placeholder={selected === "student" ? "e.g. 21APP5710" : selected === "lecture" ? "e.g. LEC205" : "e.g. ADM101"}
          style={{ ...iSt, fontFamily: "monospace", letterSpacing: "0.08em", border: `1.5px solid ${error ? COLORS.danger : COLORS.border}` }} />
      </div>
      <div style={{ marginBottom: 8 }}>
        <label style={lSt}>Password</label>
        <div style={{ position: "relative" }}>
          <input type={showPwd ? "text" : "password"} value={password} onChange={e => { setPassword(e.target.value); setError(""); }}
            placeholder="Enter your password"
            style={{ ...iSt, paddingRight: 44, border: `1.5px solid ${error ? COLORS.danger : COLORS.border}` }}
            onKeyDown={e => e.key === "Enter" && handleLogin()} />
          <button onClick={() => setShowPwd(!showPwd)} style={{ position: "absolute", right: 12, top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", display: "flex", color: COLORS.textMuted }}>
            <Icon name={showPwd ? "eyeOff" : "eye"} size={17} color={COLORS.textMuted} />
          </button>
        </div>
      </div>
      <div style={{ display: "flex", justifyContent: "flex-end", marginBottom: 16 }}>
        <span style={{ fontSize: 12, color: COLORS.accent, cursor: "pointer", fontWeight: 600 }}>Forgot Password?</span>
      </div>

      {error && (
        <div style={{ background: COLORS.danger + "12", border: `1px solid ${COLORS.danger}30`, borderRadius: 8, padding: "10px 14px", marginBottom: 14, fontSize: 13, color: COLORS.danger, fontWeight: 600, display: "flex", alignItems: "center", gap: 6 }}>
          <Icon name="alert" size={14} color={COLORS.danger} /> {error}
        </div>
      )}

      <button onClick={handleLogin} disabled={loading} style={{ width: "100%", padding: "13px", background: selected ? `linear-gradient(135deg, ${col}, ${COLORS.primaryLight})` : COLORS.border, color: selected ? "#fff" : COLORS.textMuted, border: "none", borderRadius: 12, fontWeight: 700, fontSize: 15, cursor: loading ? "default" : "pointer", opacity: loading ? 0.7 : 1, transition: "all 0.2s", marginBottom: 14 }}>
        {loading ? "Signing In…" : "Sign In →"}
      </button>

      <div style={{ textAlign: "center", borderTop: `1px solid ${COLORS.border}`, paddingTop: 16 }}>
        <span style={{ fontSize: 13, color: COLORS.textMuted }}>Don't have an account? </span>
        <span onClick={onRegister} style={{ fontSize: 13, color: COLORS.accent, fontWeight: 700, cursor: "pointer" }}>Register here →</span>
      </div>
    </AuthBg>
  );
};

// ═══════════════════════════════════════════════════════════════════════════════
// MAIN APP SHELL
// ═══════════════════════════════════════════════════════════════════════════════

const ROLE_TO_PORTAL = { student: "student", lecturer: "lecture", admin: "admin" };

export default function App() {
  const [screen, setScreen] = useState("checking"); // checking | login | register | success | app
  const [portal, setPortal] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);
  const [activePage, setActivePage] = useState("dashboard");
  const [registeredNo, setRegisteredNo] = useState("");
  const [registeredPortal, setRegisteredPortal] = useState("");

  // Restore session on load if a token is already saved (e.g. page refresh).
  useEffect(() => {
    const token = getToken();
    if (!token) { setScreen("login"); return; }
    api.me()
      .then(user => {
        setCurrentUser(user);
        setPortal(ROLE_TO_PORTAL[user.role] || "student");
        setScreen("app");
      })
      .catch(() => { clearToken(); setScreen("login"); });
  }, []);

  const handleSignOut = () => {
    clearToken();
    setPortal(null);
    setCurrentUser(null);
    setScreen("login");
  };

  if (screen === "checking") return (
    <div style={{ height: "100vh", display: "flex", alignItems: "center", justifyContent: "center", background: COLORS.bg, color: COLORS.textMuted, fontSize: 14 }}>Loading…</div>
  );

  if (screen === "register") return (
    <RegisterScreen
      onDone={(role, regNo) => { setRegisteredPortal(role); setRegisteredNo(regNo); setScreen("success"); }}
      onBack={() => setScreen("login")}
    />
  );

  if (screen === "success") return (
    <RegistrationSuccess
      portal={registeredPortal}
      regNo={registeredNo}
      onSignIn={() => setScreen("login")}
    />
  );

  if (screen === "login" || !portal) return (
    <LoginScreen
      onLogin={(p, user) => { setPortal(p); setCurrentUser(user); setActivePage("dashboard"); setScreen("app"); }}
      onRegister={() => setScreen("register")}
    />
  );

  const config = PORTALS[portal];
  const menuItem = config.menu.find((m) => m.id === activePage) || config.menu[0];
  const PageComponent = menuItem.component;
  const displayName = currentUser?.full_name || config.user;
  const displayRole = currentUser
    ? (currentUser.role === "student"
        ? `${currentUser.index_number || currentUser.username} · ${currentUser.program || ""}`
        : currentUser.role === "lecturer"
        ? `${currentUser.designation || "Lecturer"} · ${currentUser.department || "PST Dept."}`
        : "Administrator")
    : config.role;

  return (
    <div style={{ display: "flex", height: "100vh", fontFamily: "'Inter', 'Segoe UI', sans-serif", background: COLORS.bg }}>
      {/* SIDEBAR */}
      <div style={{ width: 248, background: config.color, display: "flex", flexDirection: "column", flexShrink: 0 }}>
        <div style={{ padding: "24px 20px 20px", borderBottom: "1px solid rgba(255,255,255,0.1)" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <Icon name="graduation" size={22} color="#fff" />
            <div>
              <div style={{ color: "#fff", fontWeight: 800, fontSize: 16, letterSpacing: "-0.3px" }}>PST Department</div>
              <div style={{ color: "rgba(255,255,255,0.6)", fontSize: 11 }}>{config.label}</div>
            </div>
          </div>
        </div>
        <div style={{ padding: "16px 20px", borderBottom: "1px solid rgba(255,255,255,0.1)" }}>
          <div style={{ width: 38, height: 38, borderRadius: 10, background: "rgba(255,255,255,0.2)", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 8 }}>
            <Icon name="user" size={18} color="rgba(255,255,255,0.9)" />
          </div>
          <div style={{ color: "#fff", fontWeight: 700, fontSize: 14 }}>{displayName}</div>
          <div style={{ color: "rgba(255,255,255,0.6)", fontSize: 12 }}>{displayRole}</div>
        </div>
        <nav style={{ flex: 1, overflowY: "auto", padding: "12px 10px" }}>
          {config.menu.map((item) => {
            const active = activePage === item.id;
            return (
              <div key={item.id} onClick={() => setActivePage(item.id)} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", borderRadius: 10, cursor: "pointer", marginBottom: 2, background: active ? "rgba(255,255,255,0.18)" : "transparent", transition: "background 0.15s" }}>
                <Icon name={item.icon} size={17} color={active ? "#fff" : "rgba(255,255,255,0.65)"} />
                <span style={{ fontSize: 13.5, fontWeight: active ? 700 : 500, color: active ? "#fff" : "rgba(255,255,255,0.72)" }}>{item.label}</span>
              </div>
            );
          })}
        </nav>
        <div style={{ padding: "12px 10px", borderTop: "1px solid rgba(255,255,255,0.1)" }}>
          <div onClick={handleSignOut} style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", borderRadius: 10, cursor: "pointer" }}>
            <Icon name="signout" size={17} color="rgba(255,255,255,0.65)" />
            <span style={{ fontSize: 13.5, color: "rgba(255,255,255,0.72)" }}>Sign Out</span>
          </div>
        </div>
      </div>

      {/* MAIN CONTENT */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>
        <div style={{ background: COLORS.card, borderBottom: `1px solid ${COLORS.border}`, padding: "14px 28px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <div>
            <div style={{ fontWeight: 700, fontSize: 15, color: COLORS.textPrimary }}>{menuItem.label}</div>
            <div style={{ fontSize: 12, color: COLORS.textMuted }}>Academic Year 2024/25 · PST Department</div>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <div style={{ width: 34, height: 34, borderRadius: 10, background: config.color + "15", display: "flex", alignItems: "center", justifyContent: "center", cursor: "pointer" }}>
              <Icon name="bell" size={16} color={config.color} />
            </div>
          </div>
        </div>
        <div style={{ flex: 1, overflowY: "auto", padding: 28 }}>
          <PageComponent portal={portal} />
        </div>
      </div>
    </div>
  );
}
