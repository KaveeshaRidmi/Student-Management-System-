// Central API client for talking to the Express/MySQL backend.
// Base URL comes from REACT_APP_API_BASE (see .env.example) — defaults to
// localhost:5000 for local dev, matching backend/.env.example's PORT=5000.
const API_BASE = process.env.REACT_APP_API_BASE || "http://localhost:5000/api";

const TOKEN_KEY = "pst_token";
const OFFLINE_ROLE_KEY = "pst_offline_role";

// Turns a server-relative path (e.g. "/uploads/exam_timetable_docs/xyz.pdf")
// returned by the API into an absolute URL the browser can open directly.
export const fileUrl = (path) => {
  if (!path) return "";
  if (/^(https?|data|blob):/i.test(path)) return path;
  return `${API_BASE.replace(/\/api\/?$/, "")}${path}`;
};

export const getToken = () => localStorage.getItem(TOKEN_KEY);
export const setToken = (token) => localStorage.setItem(TOKEN_KEY, token);
export const clearToken = () => {
  localStorage.removeItem(TOKEN_KEY);
  localStorage.removeItem(OFFLINE_ROLE_KEY);
};

// ─── OFFLINE DEMO DATA ─────────────────────────────────────────────────────
// If the backend can't be reached, the app falls back to this data instead
// of showing a wall of errors — handy for demoing the UI without MySQL/Express
// running. Remove the individual fallback arguments below once the backend
// is always expected to be up.
const MOCK_USERS = {
  student: { username: "21APP5710", index_number: "21APP5710", role: "student", full_name: "M.D. K. Ridmi", email: "ridmikavee2000@gmail.com", phone: "071 234 5678", program: "B.Sc. Physical Sciences", batch: "C3", current_year: 4, current_semester: 1, date_of_birth: "2001-04-12", gender: "Female", address: "4/4, Galagoda Atta Road, Pahala Kiripedda, Karandeniya", profile_picture: null, status: "active" },
  lecturer: { username: "L1024", staff_id: "L1024", role: "lecturer", full_name: "Dr. A. A. Perera", email: "perera@example.com", phone: "077 345 6789", designation: "Senior Lecturer", department: "Physical Sciences & Technology", status: "active" },
  admin: { username: "ADMIN01", role: "admin", full_name: "System Administrator", email: "admin@example.com", status: "active" },
};

// Matches the official SUSL PST curriculum, Year 3 / Semester 2,
// Computer Science & Technology track (see database/seed_courses.sql).
// Matches the official SUSL PST curriculum, Year 4 / Semester 1,
// Computer Science & Technology track (see database/seed_courses.sql).
const MOCK_COURSES = [
  { id: 1, code: "PST 41201", name: "Research Methodology and Scientific Communication", credits: 2, year: 4, semester: 1, compulsory_for: "ALL", elective_for: null },
  { id: 2, code: "PST 41227", name: "Web Services", credits: 2, year: 4, semester: 1, compulsory_for: "C3", elective_for: null },
  { id: 3, code: "PST 41228", name: "Computer System Security", credits: 2, year: 4, semester: 1, compulsory_for: "C3", elective_for: null },
  { id: 4, code: "PST 41229", name: "Advanced Computer Networks", credits: 2, year: 4, semester: 1, compulsory_for: "C3", elective_for: null },
  { id: 5, code: "PST 41232", name: "Cloud Computing", credits: 2, year: 4, semester: 1, compulsory_for: "C3", elective_for: null },
  { id: 6, code: "PST 41203", name: "Robotics", credits: 2, year: 4, semester: 1, compulsory_for: null, elective_for: "C1,C3" },
  { id: 7, code: "PST 41230", name: "Internet of Things (IoT)", credits: 2, year: 4, semester: 1, compulsory_for: null, elective_for: "C3" },
  { id: 8, code: "PST 41231", name: "Natural Language Processing", credits: 2, year: 4, semester: 1, compulsory_for: null, elective_for: "C3" },
  { id: 9, code: "PST 41233", name: "Business Process Management Systems", credits: 2, year: 4, semester: 1, compulsory_for: null, elective_for: "C3" },
  { id: 10, code: "PST 41234", name: "Mobile Computing", credits: 2, year: 4, semester: 1, compulsory_for: null, elective_for: "C3" },
  { id: 11, code: "PST 41215", name: "Industrial Management", credits: 2, year: 4, semester: 1, compulsory_for: null, elective_for: "C1,C2,C3" },
  { id: 12, code: "PST 41235", name: "Critical Thinking", credits: 2, year: 4, semester: 1, compulsory_for: null, elective_for: "C1,C2,C3" },
];

// Full PST course catalogue (Year 1 - Year 4, all combinations) — mirrors
// database/seed_courses.sql exactly. Used only as the offline-demo fallback
// for api.courses(year, semester, combination) — i.e. subject browsing for
// Course Registration and Exam Application (Medical / Repeat, which can be
// for any past year & semester). Kept separate from MOCK_COURSES above,
// which represents the specific 8 Year-4/Sem-1 subjects the demo student and
// demo lecturer are actually enrolled in / teaching.
const MOCK_COURSE_CATALOG = [
  { id: 1, code: "PST 11201", name: "Mechanics and Properties of Matter", credits: 2, year: 1, semester: 1, compulsory_for: "ALL", elective_for: null },
  { id: 2, code: "PST 11202", name: "Introduction to Electricity and Magnetism", credits: 2, year: 1, semester: 1, compulsory_for: "ALL", elective_for: null },
  { id: 3, code: "PST 11103", name: "Physics Laboratory 1-I", credits: 1, year: 1, semester: 1, compulsory_for: "ALL", elective_for: null },
  { id: 4, code: "PST 11204", name: "General Chemistry", credits: 2, year: 1, semester: 1, compulsory_for: "ALL", elective_for: null },
  { id: 5, code: "PST 11205", name: "Fundamentals of Organic Chemistry", credits: 2, year: 1, semester: 1, compulsory_for: "ALL", elective_for: null },
  { id: 6, code: "PST 11106", name: "Inorganic Chemistry Laboratory I", credits: 1, year: 1, semester: 1, compulsory_for: "ALL", elective_for: null },
  { id: 7, code: "PST 11107", name: "Structured Programming", credits: 1, year: 1, semester: 1, compulsory_for: "ALL", elective_for: null },
  { id: 8, code: "PST 11208", name: "Computer Hardware and Software", credits: 2, year: 1, semester: 1, compulsory_for: "ALL", elective_for: null },
  { id: 9, code: "PST 11109", name: "Computer Laboratory 1-I", credits: 1, year: 1, semester: 1, compulsory_for: "ALL", elective_for: null },
  { id: 10, code: "PST 11210", name: "Calculus and Differential Equations", credits: 2, year: 1, semester: 1, compulsory_for: "ALL", elective_for: null },
  { id: 11, code: "PST-EGP-1101", name: "General English I (Non-GPA)", credits: 2, year: 1, semester: 1, compulsory_for: "ALL", elective_for: null },
  { id: 12, code: "PST 12201", name: "Physics of Heat and Waves", credits: 2, year: 1, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 13, code: "PST 12102", name: "Semi-Conductor Physics", credits: 1, year: 1, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 14, code: "PST 12103", name: "AC Theory & Circuits", credits: 1, year: 1, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 15, code: "PST 12104", name: "Physics Laboratory 1-II", credits: 1, year: 1, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 16, code: "PST 12205", name: "Fundamentals of Physical Chemistry", credits: 2, year: 1, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 17, code: "PST 12206", name: "Fundamentals of Analytical Chemistry", credits: 2, year: 1, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 18, code: "PST 12107", name: "Organic Chemistry Laboratory I", credits: 1, year: 1, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 19, code: "PST 12108", name: "Object Oriented Programming", credits: 1, year: 1, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 20, code: "PST 12209", name: "Fundamentals of Statistics", credits: 2, year: 1, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 21, code: "PST 12110", name: "Computer Laboratory 1-II", credits: 1, year: 1, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 22, code: "PST 12211", name: "Database Management Systems", credits: 2, year: 1, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 23, code: "PST-EGP-1201", name: "General English II (Non-GPA)", credits: 2, year: 1, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 24, code: "PST 21201", name: "Electronics", credits: 2, year: 2, semester: 1, compulsory_for: "ALL", elective_for: null },
  { id: 25, code: "PST 21202", name: "Geometrical and Physical Optics", credits: 2, year: 2, semester: 1, compulsory_for: "ALL", elective_for: null },
  { id: 26, code: "PST 21103", name: "Physics Laboratory 2-I", credits: 1, year: 2, semester: 1, compulsory_for: "ALL", elective_for: null },
  { id: 27, code: "PST 21204", name: "Organic Chemistry", credits: 2, year: 2, semester: 1, compulsory_for: "ALL", elective_for: null },
  { id: 28, code: "PST 21205", name: "Industrial Chemistry and Technology I (Organic)", credits: 2, year: 2, semester: 1, compulsory_for: "ALL", elective_for: null },
  { id: 29, code: "PST 21106", name: "Organic Chemistry Laboratory II", credits: 1, year: 2, semester: 1, compulsory_for: "ALL", elective_for: null },
  { id: 30, code: "PST 21207", name: "Data Structures & Algorithms", credits: 2, year: 2, semester: 1, compulsory_for: "ALL", elective_for: null },
  { id: 31, code: "PST 21208", name: "Computer Architecture and Assembly Language", credits: 2, year: 2, semester: 1, compulsory_for: "ALL", elective_for: null },
  { id: 32, code: "PST 21209", name: "Statistics for Experimental Analysis", credits: 2, year: 2, semester: 1, compulsory_for: "ALL", elective_for: null },
  { id: 33, code: "PST 21110", name: "Computer Laboratory 2-I", credits: 1, year: 2, semester: 1, compulsory_for: "ALL", elective_for: null },
  { id: 34, code: "PST 21111", name: "Physical Chemistry Laboratory I", credits: 1, year: 2, semester: 1, compulsory_for: "ALL", elective_for: null },
  { id: 35, code: "PST-EAP-2101", name: "Academic English I (Non-GPA)", credits: 2, year: 2, semester: 1, compulsory_for: "ALL", elective_for: null },
  { id: 36, code: "PST 22201", name: "Physics of Electromagnetic Radiation and Introduction to the Laser", credits: 2, year: 2, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 37, code: "PST 22202", name: "Quantum Physics, Atomic & Nuclear Physics", credits: 2, year: 2, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 38, code: "PST 22103", name: "Physics Laboratory 2-II", credits: 1, year: 2, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 39, code: "PST 22204", name: "Chemistry of Elements", credits: 2, year: 2, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 40, code: "PST 22205", name: "Physical Chemistry", credits: 2, year: 2, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 41, code: "PST 22106", name: "Inorganic Chemistry Laboratory II", credits: 1, year: 2, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 42, code: "PST 22107", name: "Analytical Chemistry Laboratory I", credits: 1, year: 2, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 43, code: "PST 22208", name: "Software Engineering", credits: 2, year: 2, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 44, code: "PST 22209", name: "Statistical Methodology", credits: 2, year: 2, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 45, code: "PST 22110", name: "Computer Laboratory 2-II", credits: 1, year: 2, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 46, code: "PST 22211", name: "Operating Systems", credits: 2, year: 2, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 47, code: "PST 22112", name: "Leadership and Communication", credits: 1, year: 2, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 48, code: "PST 22213", name: "Biology for Physical Sciences", credits: 2, year: 2, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 49, code: "PST 22114", name: "Soft Skill Development", credits: 1, year: 2, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 50, code: "PST 22215", name: "Mathematical Methods", credits: 2, year: 2, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 51, code: "PST 22116", name: "Introduction to Astronomy", credits: 1, year: 2, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 52, code: "PST 22217", name: "Industrial Metrology", credits: 2, year: 2, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 53, code: "PST 22218", name: "Management Information Systems", credits: 2, year: 2, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 54, code: "PST 22219", name: "Molecular Spectroscopy", credits: 2, year: 2, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 55, code: "PST-EAP-2201", name: "Academic English II (Non-GPA)", credits: 2, year: 2, semester: 2, compulsory_for: "ALL", elective_for: null },
  { id: 56, code: "PST 31201", name: "Solid State Physics", credits: 2, year: 3, semester: 1, compulsory_for: "C1", elective_for: null },
  { id: 57, code: "PST 31202", name: "Nuclear Physics & Applications", credits: 2, year: 3, semester: 1, compulsory_for: "C1", elective_for: null },
  { id: 58, code: "PST 31203", name: "Quantum Mechanics", credits: 2, year: 3, semester: 1, compulsory_for: "C1", elective_for: null },
  { id: 59, code: "PST 31104", name: "Material Physics", credits: 1, year: 3, semester: 1, compulsory_for: "C1", elective_for: null },
  { id: 60, code: "PST 31205", name: "Special Relativity (General — Physics)", credits: 2, year: 3, semester: 1, compulsory_for: "C1", elective_for: null },
  { id: 61, code: "PST 31105", name: "Special Relativity (Special — Applied Physics)", credits: 2, year: 3, semester: 1, compulsory_for: "C1", elective_for: null },
  { id: 62, code: "PST 31206", name: "Optical Fiber & Telecommunication", credits: 2, year: 3, semester: 1, compulsory_for: "C1", elective_for: null },
  { id: 63, code: "PST 31107", name: "Introduction to Nanotechnology", credits: 1, year: 3, semester: 1, compulsory_for: "C1", elective_for: "C2" },
  { id: 64, code: "PST 31108", name: "Physics Laboratory 3-I", credits: 1, year: 3, semester: 1, compulsory_for: "C1", elective_for: null },
  { id: 65, code: "PST 31209", name: "The Origin and Evolution of the Universe", credits: 2, year: 3, semester: 1, compulsory_for: "C1", elective_for: null },
  { id: 66, code: "PST 31210", name: "Multimedia and Hypermedia Systems Development", credits: 2, year: 3, semester: 1, compulsory_for: "C3", elective_for: "C1" },
  { id: 67, code: "PST 31211", name: "Mathematical Programming", credits: 2, year: 3, semester: 1, compulsory_for: "C1", elective_for: "C2,C3" },
  { id: 68, code: "PST 31212", name: "Numerical Methods", credits: 2, year: 3, semester: 1, compulsory_for: null, elective_for: "C1,C2,C3" },
  { id: 69, code: "PST 31213", name: "Economics", credits: 2, year: 3, semester: 1, compulsory_for: null, elective_for: "C1,C2" },
  { id: 70, code: "PST 31014", name: "Industrial Visit", credits: 0, year: 3, semester: 1, compulsory_for: "C1,C2,C3", elective_for: null },
  { id: 71, code: "PST-EBP-3101", name: "Business English (Non-GPA)", credits: 2, year: 3, semester: 1, compulsory_for: "C1,C2,C3", elective_for: null },
  { id: 72, code: "PST 31216", name: "Biochemistry-I", credits: 2, year: 3, semester: 1, compulsory_for: "C2", elective_for: null },
  { id: 73, code: "PST 31217", name: "Electroanalytical Techniques", credits: 2, year: 3, semester: 1, compulsory_for: "C2", elective_for: null },
  { id: 74, code: "PST 31218", name: "Industrial Chemistry and Technology II (Inorganic)", credits: 2, year: 3, semester: 1, compulsory_for: "C2", elective_for: null },
  { id: 75, code: "PST 31219", name: "Environmental Chemistry", credits: 2, year: 3, semester: 1, compulsory_for: "C2", elective_for: null },
  { id: 76, code: "PST 31120", name: "Coordination Chemistry", credits: 1, year: 3, semester: 1, compulsory_for: "C2", elective_for: null },
  { id: 77, code: "PST 31121", name: "Laboratory Quality Control and Assurance", credits: 1, year: 3, semester: 1, compulsory_for: "C2", elective_for: null },
  { id: 78, code: "PST 31122", name: "Physical Chemistry Laboratory II", credits: 1, year: 3, semester: 1, compulsory_for: "C2", elective_for: null },
  { id: 79, code: "PST 31123", name: "Analytical Chemistry Laboratory II", credits: 1, year: 3, semester: 1, compulsory_for: "C2", elective_for: null },
  { id: 80, code: "PST 31215", name: "Agile Software Development", credits: 2, year: 3, semester: 1, compulsory_for: null, elective_for: "C3" },
  { id: 81, code: "PST 31224", name: "Artificial Intelligence & Expert Systems", credits: 2, year: 3, semester: 1, compulsory_for: "C3", elective_for: null },
  { id: 82, code: "PST 31225", name: "Software Project Management", credits: 2, year: 3, semester: 1, compulsory_for: "C3", elective_for: null },
  { id: 83, code: "PST 31226", name: "Software Quality Assurances", credits: 2, year: 3, semester: 1, compulsory_for: "C3", elective_for: null },
  { id: 84, code: "PST 31227", name: "Object Oriented Analysis and Design", credits: 2, year: 3, semester: 1, compulsory_for: "C3", elective_for: null },
  { id: 85, code: "PST 31128", name: "Computer Laboratory 3-I", credits: 1, year: 3, semester: 1, compulsory_for: "C3", elective_for: null },
  { id: 86, code: "PST 31229", name: "Advanced Database Management Systems", credits: 2, year: 3, semester: 1, compulsory_for: "C3", elective_for: null },
  { id: 87, code: "PST 31230", name: "Social and Professional Issues in Computing", credits: 2, year: 3, semester: 1, compulsory_for: null, elective_for: "C3" },
  { id: 88, code: "PST 32801", name: "Project Work (Industrial Exposure): B.Sc. Thesis — Major in Applied Physics", credits: 8, year: 3, semester: 2, compulsory_for: "C1", elective_for: null },
  { id: 89, code: "PST 32802", name: "Project Work (Industrial Exposure): B.Sc. Thesis — Major in Chemical Technology", credits: 8, year: 3, semester: 2, compulsory_for: "C2", elective_for: null },
  { id: 90, code: "PST 32803", name: "Project Work (Industrial Exposure): B.Sc. Thesis — Major in Computer Science & Technology", credits: 8, year: 3, semester: 2, compulsory_for: "C3", elective_for: null },
  { id: 91, code: "PST 32201", name: "Statistical Physics", credits: 2, year: 3, semester: 2, compulsory_for: "C1", elective_for: null },
  { id: 92, code: "PST 32102", name: "Interaction of Radiation with Matter", credits: 1, year: 3, semester: 2, compulsory_for: "C1", elective_for: null },
  { id: 93, code: "PST 32203", name: "Atmospheric Physics & Applications", credits: 2, year: 3, semester: 2, compulsory_for: "C1", elective_for: null },
  { id: 94, code: "PST 32104", name: "Advanced Electronics", credits: 1, year: 3, semester: 2, compulsory_for: "C1", elective_for: null },
  { id: 95, code: "PST 32205", name: "Solid State Devices", credits: 2, year: 3, semester: 2, compulsory_for: "C1", elective_for: null },
  { id: 96, code: "PST 32206", name: "Astrophysics", credits: 2, year: 3, semester: 2, compulsory_for: "C1", elective_for: null },
  { id: 97, code: "PST 32207", name: "Atomic and Molecular Spectroscopy", credits: 2, year: 3, semester: 2, compulsory_for: null, elective_for: "C1" },
  { id: 98, code: "PST 32108", name: "Current Topics in Physics", credits: 1, year: 3, semester: 2, compulsory_for: "C1", elective_for: null },
  { id: 99, code: "PST 32109", name: "Human Resource Management", credits: 1, year: 3, semester: 2, compulsory_for: null, elective_for: "C1,C2,C3" },
  { id: 100, code: "PST 32210", name: "Statistics in Quality Control", credits: 2, year: 3, semester: 2, compulsory_for: null, elective_for: "C1,C2,C3" },
  { id: 101, code: "PST 32111", name: "Physics Laboratory 3-II", credits: 1, year: 3, semester: 2, compulsory_for: "C1", elective_for: null },
  { id: 102, code: "PST 32212", name: "Graph Theory", credits: 2, year: 3, semester: 2, compulsory_for: null, elective_for: "C1,C3" },
  { id: 103, code: "PST 32213", name: "Resource Efficient and Cleaner Production", credits: 2, year: 3, semester: 2, compulsory_for: null, elective_for: "C1,C2" },
  { id: 104, code: "PST 32214", name: "Chemistry of Drug Design and Drug Action", credits: 2, year: 3, semester: 2, compulsory_for: "C2", elective_for: null },
  { id: 105, code: "PST 32215", name: "Polymer Chemistry and Technology", credits: 2, year: 3, semester: 2, compulsory_for: "C2", elective_for: null },
  { id: 106, code: "PST 32216", name: "Surface and Colloid Chemistry", credits: 2, year: 3, semester: 2, compulsory_for: "C2", elective_for: null },
  { id: 107, code: "PST 32217", name: "Biochemistry II", credits: 2, year: 3, semester: 2, compulsory_for: "C2", elective_for: null },
  { id: 108, code: "PST 32118", name: "Advanced Organic Chemistry", credits: 1, year: 3, semester: 2, compulsory_for: "C2", elective_for: null },
  { id: 109, code: "PST 32219", name: "Introduction to Organic Electronics", credits: 2, year: 3, semester: 2, compulsory_for: null, elective_for: "C2" },
  { id: 110, code: "PST 32220", name: "Structures and Properties of Solids", credits: 2, year: 3, semester: 2, compulsory_for: "C2", elective_for: null },
  { id: 111, code: "PST 32121", name: "Advanced Inorganic Chemistry Laboratory", credits: 1, year: 3, semester: 2, compulsory_for: "C2", elective_for: null },
  { id: 112, code: "PST 32122", name: "Biochemistry Laboratory", credits: 1, year: 3, semester: 2, compulsory_for: "C2", elective_for: null },
  { id: 113, code: "PST 32223", name: "Organometallic Chemistry", credits: 2, year: 3, semester: 2, compulsory_for: null, elective_for: "C2" },
  { id: 114, code: "PST 32224", name: "Artificial Neural Networks", credits: 2, year: 3, semester: 2, compulsory_for: "C3", elective_for: null },
  { id: 115, code: "PST 32225", name: "Digital Image Processing", credits: 2, year: 3, semester: 2, compulsory_for: "C3", elective_for: null },
  { id: 116, code: "PST 32226", name: "Data Mining and Applications", credits: 2, year: 3, semester: 2, compulsory_for: "C3", elective_for: null },
  { id: 117, code: "PST 32227", name: "Data Communication and Computer Networks", credits: 2, year: 3, semester: 2, compulsory_for: "C3", elective_for: null },
  { id: 118, code: "PST 32228", name: "Computer Graphics & Visualization", credits: 2, year: 3, semester: 2, compulsory_for: "C3", elective_for: null },
  { id: 119, code: "PST 32229", name: "Project in Computer Science and Technology (Mini Project)", credits: 2, year: 3, semester: 2, compulsory_for: "C3", elective_for: null },
  { id: 120, code: "PST 32130", name: "Computer Laboratory 3-II", credits: 1, year: 3, semester: 2, compulsory_for: "C3", elective_for: null },
  { id: 121, code: "PST 32231", name: "Human Computer Interactions", credits: 2, year: 3, semester: 2, compulsory_for: null, elective_for: "C3" },
  { id: 122, code: "PST 32232", name: "Bioinformatics", credits: 2, year: 3, semester: 2, compulsory_for: null, elective_for: "C3" },
  { id: 123, code: "PST 32133", name: "Current Topics in Computer Technology", credits: 1, year: 3, semester: 2, compulsory_for: null, elective_for: "C3" },
  { id: 124, code: "PST 41201", name: "Research Methodology and Scientific Communication", credits: 2, year: 4, semester: 1, compulsory_for: "C1,C2,C3", elective_for: null },
  { id: 125, code: "PST 41202", name: "Computational Physics", credits: 2, year: 4, semester: 1, compulsory_for: "C1", elective_for: null },
  { id: 126, code: "PST 41203", name: "Robotics", credits: 2, year: 4, semester: 1, compulsory_for: null, elective_for: "C1,C3" },
  { id: 127, code: "PST 41204", name: "Remote Sensing & GIS", credits: 2, year: 4, semester: 1, compulsory_for: "C1", elective_for: null },
  { id: 128, code: "PST 41205", name: "Geophysics", credits: 2, year: 4, semester: 1, compulsory_for: "C1", elective_for: null },
  { id: 129, code: "PST 41206", name: "Medical and Bio Physics", credits: 2, year: 4, semester: 1, compulsory_for: "C1", elective_for: null },
  { id: 130, code: "PST 41207", name: "Advanced Nanotechnology", credits: 2, year: 4, semester: 1, compulsory_for: null, elective_for: "C1,C2" },
  { id: 131, code: "PST 41208", name: "Data Acquisition and Signal Processing Methods", credits: 2, year: 4, semester: 1, compulsory_for: "C1", elective_for: null },
  { id: 132, code: "PST 41209", name: "Advanced Laser Physics", credits: 2, year: 4, semester: 1, compulsory_for: null, elective_for: "C1" },
  { id: 133, code: "PST 41210", name: "Automation", credits: 2, year: 4, semester: 1, compulsory_for: null, elective_for: "C1" },
  { id: 134, code: "PST 41211", name: "Astronomical Instruments and Data Reduction & Analysis", credits: 2, year: 4, semester: 1, compulsory_for: "C1", elective_for: null },
  { id: 135, code: "PST 41212", name: "Electrochemical Power Conversion", credits: 2, year: 4, semester: 1, compulsory_for: null, elective_for: "C1,C2" },
  { id: 136, code: "PST 41013", name: "Literature Search Seminar in Applied Physics", credits: 1, year: 4, semester: 1, compulsory_for: "C1", elective_for: null },
  { id: 137, code: "PST 41014", name: "Independent Research / Project in Applied Physics", credits: 2, year: 4, semester: 1, compulsory_for: "C1", elective_for: null },
  { id: 138, code: "PST 41215", name: "Industrial Management", credits: 2, year: 4, semester: 1, compulsory_for: null, elective_for: "C1,C2,C3" },
  { id: 139, code: "PST 41216", name: "Classical Mechanics", credits: 2, year: 4, semester: 1, compulsory_for: "C1", elective_for: null },
  { id: 140, code: "PST 41235", name: "Critical Thinking", credits: 2, year: 4, semester: 1, compulsory_for: null, elective_for: "C1,C2,C3" },
  { id: 141, code: "PST 41217", name: "Natural Products Chemistry", credits: 2, year: 4, semester: 1, compulsory_for: "C2", elective_for: null },
  { id: 142, code: "PST 41218", name: "Biotechnology", credits: 2, year: 4, semester: 1, compulsory_for: "C2", elective_for: null },
  { id: 143, code: "PST 41219", name: "Advanced Solid State Chemistry", credits: 2, year: 4, semester: 1, compulsory_for: "C2", elective_for: null },
  { id: 144, code: "PST 41120", name: "Bioinorganic Chemistry", credits: 1, year: 4, semester: 1, compulsory_for: "C2", elective_for: null },
  { id: 145, code: "PST 41221", name: "Instrumental Analysis", credits: 2, year: 4, semester: 1, compulsory_for: "C2", elective_for: null },
  { id: 146, code: "PST 41222", name: "Applied Molecular Modeling", credits: 2, year: 4, semester: 1, compulsory_for: null, elective_for: "C2" },
  { id: 147, code: "PST 41223", name: "State of Matter", credits: 2, year: 4, semester: 1, compulsory_for: null, elective_for: "C2" },
  { id: 148, code: "PST 41124", name: "Literature Search Seminar in Chemical Technology", credits: 1, year: 4, semester: 1, compulsory_for: "C2", elective_for: null },
  { id: 149, code: "PST 41225", name: "Independent Research / Project in Chemical Technology", credits: 2, year: 4, semester: 1, compulsory_for: "C2", elective_for: null },
  { id: 150, code: "PST 41226", name: "Computer Applications in Instrumentation", credits: 2, year: 4, semester: 1, compulsory_for: null, elective_for: "C2" },
  { id: 151, code: "PST 41227", name: "Web Services", credits: 2, year: 4, semester: 1, compulsory_for: "C3", elective_for: null },
  { id: 152, code: "PST 41228", name: "Computer System Security", credits: 2, year: 4, semester: 1, compulsory_for: "C3", elective_for: null },
  { id: 153, code: "PST 41229", name: "Advanced Computer Networks", credits: 2, year: 4, semester: 1, compulsory_for: "C3", elective_for: null },
  { id: 154, code: "PST 41230", name: "Internet of Things (IoT)", credits: 2, year: 4, semester: 1, compulsory_for: null, elective_for: "C3" },
  { id: 155, code: "PST 41231", name: "Natural Language Processing", credits: 2, year: 4, semester: 1, compulsory_for: null, elective_for: "C3" },
  { id: 156, code: "PST 41232", name: "Cloud Computing", credits: 2, year: 4, semester: 1, compulsory_for: "C3", elective_for: null },
  { id: 157, code: "PST 41233", name: "Business Process Management Systems", credits: 2, year: 4, semester: 1, compulsory_for: null, elective_for: "C3" },
  { id: 158, code: "PST 41234", name: "Mobile Computing", credits: 2, year: 4, semester: 1, compulsory_for: null, elective_for: "C3" },
  { id: 159, code: "PST 42801", name: "Project Work (Industrial Exposure): B.Sc. Thesis in Applied Physics", credits: 8, year: 4, semester: 2, compulsory_for: "C1", elective_for: null },
  { id: 160, code: "PST 42102", name: "Literature Search Seminar in Applied Physics", credits: 1, year: 4, semester: 2, compulsory_for: "C1", elective_for: null },
  { id: 161, code: "PST 42203", name: "Independent Research / Project in Applied Physics", credits: 2, year: 4, semester: 2, compulsory_for: "C1", elective_for: null },
  { id: 162, code: "PST 42804", name: "Project Work (Industrial Exposure): B.Sc. Thesis in Chemical Technology", credits: 8, year: 4, semester: 2, compulsory_for: "C2", elective_for: null },
  { id: 163, code: "PST 42803", name: "Project: B.Sc. Thesis in Computer Science and Technology", credits: 8, year: 4, semester: 2, compulsory_for: "C3", elective_for: null },
  { id: 164, code: "PST 42606", name: "Industrial Training", credits: 6, year: 4, semester: 2, compulsory_for: "C3", elective_for: null },
];

// Per-course attendance for the 8 registered modules — a different, non-zero
// percentage per module (matches backend/database/seed-demo-users.js) so
// the dashboard/attendance pages show a realistic, varied picture (~80%
// overall) instead of 0% everywhere.
const MOCK_ATTENDANCE_PLAN = [
  { code: "PST 41201", name: "Research Methodology and Scientific Communication", present: 9, absent: 1, late: 0 },  // 90%
  { code: "PST 41227", name: "Web Services", present: 8, absent: 1, late: 1 },                                       // 80%
  { code: "PST 41228", name: "Computer System Security", present: 7, absent: 3, late: 0 },                           // 70%
  { code: "PST 41229", name: "Advanced Computer Networks", present: 8, absent: 2, late: 0 },                         // 80%
  { code: "PST 41232", name: "Cloud Computing", present: 10, absent: 0, late: 0 },                                   // 100%
  { code: "PST 41230", name: "Internet of Things (IoT)", present: 6, absent: 3, late: 1 },                           // 60%
  { code: "PST 41231", name: "Natural Language Processing", present: 9, absent: 0, late: 1 },                        // 90%
  { code: "PST 41233", name: "Business Process Management Systems", present: 8, absent: 2, late: 0 },                // 80%
];
const MOCK_ATTENDANCE = MOCK_ATTENDANCE_PLAN.flatMap(({ code, name, present, absent, late }) => {
  const statuses = [...Array(present).fill("present"), ...Array(absent).fill("absent"), ...Array(late).fill("late")];
  return statuses.map((status, i) => ({
    id: `${code}-${i}`,
    code,
    course_name: name,
    status,
    session_date: new Date(Date.now() - (statuses.length - i) * 7 * 24 * 60 * 60 * 1000).toISOString().slice(0, 10),
  }));
});

const MOCK_RESULTS = [
  { code: "PST 12211", course_name: "Database Management Systems", year: 1, semester: 2, marks: 96, grade: "A+", credits: 3 },
  { code: "PST 21207", course_name: "Data Structures & Algorithms", year: 2, semester: 1, marks: 90, grade: "A+", credits: 3 },
  { code: "PST 21109", course_name: "Web Development", year: 2, semester: 1, marks: 76, grade: "B+", credits: 2 },
  { code: "PST 22207", course_name: "Software Engineering", year: 2, semester: 2, marks: 66, grade: "B-", credits: 3 },
  { code: "PST 31224", course_name: "Artificial Intelligence & Expert Systems", year: 3, semester: 1, marks: 82, grade: "A", credits: 2 },
  { code: "PST 31227", course_name: "Object Oriented Analysis and Design", year: 3, semester: 1, marks: 71, grade: "B", credits: 2 },
  { code: "PST 32226", course_name: "Data Mining and Applications", year: 3, semester: 2, marks: 88, grade: "A", credits: 2 },
  { code: "PST 32227", course_name: "Data Communication and Computer Networks", year: 3, semester: 2, marks: 65, grade: "B-", credits: 2 },
  // Year 4 / Semester 1 — every subject listed under Course Registration for
  // this year & semester (see MOCK_COURSES above) has a result here too, so
  // My Results / the download filters offer the full subject list.
  { code: "PST 41201", course_name: "Research Methodology and Scientific Communication", year: 4, semester: 1, marks: 79, grade: "B+", credits: 2 },
  { code: "PST 41227", course_name: "Web Services", year: 4, semester: 1, marks: 91, grade: "A+", credits: 2 },
  { code: "PST 41228", course_name: "Computer System Security", year: 4, semester: 1, marks: 84, grade: "A", credits: 2 },
  { code: "PST 41229", course_name: "Advanced Computer Networks", year: 4, semester: 1, marks: 73, grade: "A", credits: 2 },
  { code: "PST 41232", course_name: "Cloud Computing", year: 4, semester: 1, marks: 68, grade: "A-", credits: 2 },
  { code: "PST 41203", course_name: "Robotics", year: 4, semester: 1, marks: 61, grade: "B+", credits: 2 },
  { code: "PST 41230", course_name: "Internet of Things (IoT)", year: 4, semester: 1, marks: 77, grade: "A", credits: 2 },
  { code: "PST 41231", course_name: "Natural Language Processing", year: 4, semester: 1, marks: 85, grade: "A+", credits: 2 },
  { code: "PST 41233", course_name: "Business Process Management Systems", year: 4, semester: 1, marks: 58, grade: "B", credits: 2 },
  { code: "PST 41234", course_name: "Mobile Computing", year: 4, semester: 1, marks: 72, grade: "A", credits: 2 },
  { code: "PST 41215", course_name: "Industrial Management", year: 4, semester: 1, marks: 63, grade: "B+", credits: 2 },
  { code: "PST 41235", course_name: "Critical Thinking", year: 4, semester: 1, marks: 80, grade: "A", credits: 2 },
];

const MOCK_NOTICES = [
  { id: 1, title: "Semester 1 Examination Timetable — 2024/25", content: "The timetable for Semester 1 examinations has been released. Exams begin July 14, 2025. Please verify your module registrations before the application deadline.", posted_by_name: "Examinations Department", created_at: "2025-06-15T00:00:00Z" },
  { id: 2, title: "Library Extended Hours — June", content: "The library will be open until 10:00 PM on weekdays throughout June to support students in exam preparation.", posted_by_name: "Library Services", created_at: "2025-06-14T00:00:00Z" },
  { id: 3, title: "Annual Sports Day Registration", content: "Register now for the Annual Sports Day on July 5, 2025. Registration closes June 25.", posted_by_name: "Student Affairs", created_at: "2025-06-12T00:00:00Z" },
];

const MOCK_SEMREGS = [
  {
    id: 1, year: 4, semester: 1, status: "confirmed", total_fee: 300,
    // 5 compulsory Year 4 / Semester 1 subjects + the 3 optional electives the
    // student picked (PST 41230, 41231, 41233) — matches Course Registration.
    courses: MOCK_COURSES.filter(c => ["PST 41201", "PST 41227", "PST 41228", "PST 41229", "PST 41232", "PST 41230", "PST 41231", "PST 41233"].includes(c.code)),
  },
];

// Auto-generated placeholder lecture-note PDFs (Year 4 / Semester I) for
// offline demo mode — small, self-contained data: URIs so download links
// work even without the backend/DB running.
const LECTURE_NOTE_PDFS = {
  "PST 41201": "data:application/pdf;base64,JVBERi0xLjMKJZOMi54gUmVwb3J0TGFiIEdlbmVyYXRlZCBQREYgZG9jdW1lbnQgKG9wZW5zb3VyY2UpCjEgMCBvYmoKPDwKL0YxIDIgMCBSIC9GMiAzIDAgUiAvRjMgNCAwIFIKPj4KZW5kb2JqCjIgMCBvYmoKPDwKL0Jhc2VGb250IC9IZWx2ZXRpY2EgL0VuY29kaW5nIC9XaW5BbnNpRW5jb2RpbmcgL05hbWUgL0YxIC9TdWJ0eXBlIC9UeXBlMSAvVHlwZSAvRm9udAo+PgplbmRvYmoKMyAwIG9iago8PAovQmFzZUZvbnQgL0hlbHZldGljYS1Cb2xkIC9FbmNvZGluZyAvV2luQW5zaUVuY29kaW5nIC9OYW1lIC9GMiAvU3VidHlwZSAvVHlwZTEgL1R5cGUgL0ZvbnQKPj4KZW5kb2JqCjQgMCBvYmoKPDwKL0Jhc2VGb250IC9IZWx2ZXRpY2EtT2JsaXF1ZSAvRW5jb2RpbmcgL1dpbkFuc2lFbmNvZGluZyAvTmFtZSAvRjMgL1N1YnR5cGUgL1R5cGUxIC9UeXBlIC9Gb250Cj4+CmVuZG9iago1IDAgb2JqCjw8Ci9Db250ZW50cyA5IDAgUiAvTWVkaWFCb3ggWyAwIDAgNTk1LjI3NTYgODQxLjg4OTggXSAvUGFyZW50IDggMCBSIC9SZXNvdXJjZXMgPDwKL0ZvbnQgMSAwIFIgL1Byb2NTZXQgWyAvUERGIC9UZXh0IC9JbWFnZUIgL0ltYWdlQyAvSW1hZ2VJIF0KPj4gL1JvdGF0ZSAwIC9UcmFucyA8PAoKPj4gCiAgL1R5cGUgL1BhZ2UKPj4KZW5kb2JqCjYgMCBvYmoKPDwKL1BhZ2VNb2RlIC9Vc2VOb25lIC9QYWdlcyA4IDAgUiAvVHlwZSAvQ2F0YWxvZwo+PgplbmRvYmoKNyAwIG9iago8PAovQXV0aG9yIChhbm9ueW1vdXMpIC9DcmVhdGlvbkRhdGUgKEQ6MjAyNjA5MDEwMDU4MTYrMDAnMDAnKSAvQ3JlYXRvciAoYW5vbnltb3VzKSAvS2V5d29yZHMgKCkgL01vZERhdGUgKEQ6MjAyNjA5MDEwMDU4MTYrMDAnMDAnKSAvUHJvZHVjZXIgKFJlcG9ydExhYiBQREYgTGlicmFyeSAtIFwob3BlbnNvdXJjZVwpKSAKICAvU3ViamVjdCAodW5zcGVjaWZpZWQpIC9UaXRsZSAodW50aXRsZWQpIC9UcmFwcGVkIC9GYWxzZQo+PgplbmRvYmoKOCAwIG9iago8PAovQ291bnQgMSAvS2lkcyBbIDUgMCBSIF0gL1R5cGUgL1BhZ2VzCj4+CmVuZG9iago5IDAgb2JqCjw8Ci9GaWx0ZXIgWyAvQVNDSUk4NURlY29kZSAvRmxhdGVEZWNvZGUgXSAvTGVuZ3RoIDg1NQo+PgpzdHJlYW0KR2F0PWg7L2FvOyY6aVs4LysqX1tbIUshSmZaRSEjSk1gMmI+KFtDNz9HKzNuXWQ2RllTWDA4JS9rdVlIKWxrZmxiKENYXUdQQnFoLW1cVDdwb1tlTkc5cmMtVWQsZl4kX1NxP1UmNSQ4YXBGYVUjaWUxWyJMam4nciozaXVjbENCPCtzVGNuIWZEWlAsU3BOUEw7aDc7MSYwXFkmXiNYZCItY1kscC8hbExxdFBhVC9mNFtuI2E0XWRfbV0mXFkmOUomOUBgYD8ibEhFN0JdaStCXyk1XjhePFRCXWN0aGAwWCkzKGBqWGxdRUhnNmVANDtDUmdPdFxMdFppUU9sUUkoYkRWN2ZwND4vPG1mPEVGQj1cKGxQPzI5W1MnIVI4SlxuQGlcbWhPNyU/ZShGc1QsVmRTc2IwdWA5K1NkaCgwTGcpU05rJ1BjPFRxaWlrOlVGNGs0OFxdSmIwWj1dJSZ1WCNGQzMnQGlRRUlFNU1TcjdoaG1JY1dRMl9sZnU0M24tLidTTjg/YSwwZDBcMVpLSmVHVWRTaDMsUClyXGgjW2dpMDxzKmIvRj1sQyMjZVUuMlEsUzo2ISNSUEllTUtmNkVQaWtXYldNKCssclQrZWAuYjhyU1FCT0FLV3RrTTUyai5zMGtAIkI3ZEJdS1xGW2llbGBOc2YvNSo/I0BXPS1DOTIvWDJvbzo6bU01bmcoT0cwbC43PnJibiU3LnBibXFtNkQoPlFwWCZQNitAc0s+KzteaF9PMCRsJS9MSiZSKzJLLzZbJEhxW04qUUpfbF8uInEuJWZWOWlLRyxlbWxrJUxAZmY7ZWNGcFMlZ0RCL0xpa08tXWNyaFw9a1VROk1DXUhDbT4rLU9UIjVEUWA2Rl5rdF8uQmdSQ14sQHQwQkAqUnJVaGEkTEloWE9sUCZhOy5uXHBfPmFLSU4wYkhFJ1dxPDReQFNccztPXml0M2MvTFklMW5eb2ptO1JDbiwxWz47K0s5SlMqJWFENTElTXFDczFQWy80M1ZkYWBFPk9WTEVBXWljY0w+UXFgT1BndU4iPTRob0RxVjwoX3FnSz1BXmtjZVBabz4mKj5yWSJSV10/bVBpLVppPDskO25eLDpmckdcMzZuZilQJ1BTIX4+ZW5kc3RyZWFtCmVuZG9iagp4cmVmCjAgMTAKMDAwMDAwMDAwMCA2NTUzNSBmIAowMDAwMDAwMDYxIDAwMDAwIG4gCjAwMDAwMDAxMTIgMDAwMDAgbiAKMDAwMDAwMDIxOSAwMDAwMCBuIAowMDAwMDAwMzMxIDAwMDAwIG4gCjAwMDAwMDA0NDYgMDAwMDAgbiAKMDAwMDAwMDY0OSAwMDAwMCBuIAowMDAwMDAwNzE3IDAwMDAwIG4gCjAwMDAwMDA5NzggMDAwMDAgbiAKMDAwMDAwMTAzNyAwMDAwMCBuIAp0cmFpbGVyCjw8Ci9JRCAKWzw2NDExZDc3ZjA3ZWIzYmY2NjVmOWJlZjk5NWZmOTIxNT48NjQxMWQ3N2YwN2ViM2JmNjY1ZjliZWY5OTVmZjkyMTU+XQolIFJlcG9ydExhYiBnZW5lcmF0ZWQgUERGIGRvY3VtZW50IC0tIGRpZ2VzdCAob3BlbnNvdXJjZSkKCi9JbmZvIDcgMCBSCi9Sb290IDYgMCBSCi9TaXplIDEwCj4+CnN0YXJ0eHJlZgoxOTgyCiUlRU9GCg==",
  "PST 41227": "data:application/pdf;base64,JVBERi0xLjMKJZOMi54gUmVwb3J0TGFiIEdlbmVyYXRlZCBQREYgZG9jdW1lbnQgKG9wZW5zb3VyY2UpCjEgMCBvYmoKPDwKL0YxIDIgMCBSIC9GMiAzIDAgUiAvRjMgNCAwIFIKPj4KZW5kb2JqCjIgMCBvYmoKPDwKL0Jhc2VGb250IC9IZWx2ZXRpY2EgL0VuY29kaW5nIC9XaW5BbnNpRW5jb2RpbmcgL05hbWUgL0YxIC9TdWJ0eXBlIC9UeXBlMSAvVHlwZSAvRm9udAo+PgplbmRvYmoKMyAwIG9iago8PAovQmFzZUZvbnQgL0hlbHZldGljYS1Cb2xkIC9FbmNvZGluZyAvV2luQW5zaUVuY29kaW5nIC9OYW1lIC9GMiAvU3VidHlwZSAvVHlwZTEgL1R5cGUgL0ZvbnQKPj4KZW5kb2JqCjQgMCBvYmoKPDwKL0Jhc2VGb250IC9IZWx2ZXRpY2EtT2JsaXF1ZSAvRW5jb2RpbmcgL1dpbkFuc2lFbmNvZGluZyAvTmFtZSAvRjMgL1N1YnR5cGUgL1R5cGUxIC9UeXBlIC9Gb250Cj4+CmVuZG9iago1IDAgb2JqCjw8Ci9Db250ZW50cyA5IDAgUiAvTWVkaWFCb3ggWyAwIDAgNTk1LjI3NTYgODQxLjg4OTggXSAvUGFyZW50IDggMCBSIC9SZXNvdXJjZXMgPDwKL0ZvbnQgMSAwIFIgL1Byb2NTZXQgWyAvUERGIC9UZXh0IC9JbWFnZUIgL0ltYWdlQyAvSW1hZ2VJIF0KPj4gL1JvdGF0ZSAwIC9UcmFucyA8PAoKPj4gCiAgL1R5cGUgL1BhZ2UKPj4KZW5kb2JqCjYgMCBvYmoKPDwKL1BhZ2VNb2RlIC9Vc2VOb25lIC9QYWdlcyA4IDAgUiAvVHlwZSAvQ2F0YWxvZwo+PgplbmRvYmoKNyAwIG9iago8PAovQXV0aG9yIChhbm9ueW1vdXMpIC9DcmVhdGlvbkRhdGUgKEQ6MjAyNjA5MDEwMDU4MTYrMDAnMDAnKSAvQ3JlYXRvciAoYW5vbnltb3VzKSAvS2V5d29yZHMgKCkgL01vZERhdGUgKEQ6MjAyNjA5MDEwMDU4MTYrMDAnMDAnKSAvUHJvZHVjZXIgKFJlcG9ydExhYiBQREYgTGlicmFyeSAtIFwob3BlbnNvdXJjZVwpKSAKICAvU3ViamVjdCAodW5zcGVjaWZpZWQpIC9UaXRsZSAodW50aXRsZWQpIC9UcmFwcGVkIC9GYWxzZQo+PgplbmRvYmoKOCAwIG9iago8PAovQ291bnQgMSAvS2lkcyBbIDUgMCBSIF0gL1R5cGUgL1BhZ2VzCj4+CmVuZG9iago5IDAgb2JqCjw8Ci9GaWx0ZXIgWyAvQVNDSUk4NURlY29kZSAvRmxhdGVEZWNvZGUgXSAvTGVuZ3RoIDgzMQo+PgpzdHJlYW0KR2F0PWg/VmZFMSdaSnUsLklQWGY7c1ZHSCZndD43SzFTYGomQyIwS2xBTS5BYD9Ual5nRjtIdGhtTHAtWD4jYDRXaS9PYWhzaV9JXihfZChCWGpCPF5vJTcyP1JTX1RgPldEYEBPU0Q7VSk0SjdKTTdSZSRTXCZJTWs+b1wmdDdlTixZbltaOElCYDI3JE9NcyheOTVkLEsvTW8/TyV0XVJYJDxWLFgiRV8zQmNUKE46PCZkJjoka1xTdEttJS1aY2hdN1cpYmM1PihfLWxDQlwyXTAuXF8nNiQjZGkqOixxRUsrX2guMjUiP3BpcklHQl0xNnA1dFQiPilVcGwnVkItY1EkYWtTczEtOGJrcWgtIW9gIlEnaE9AYCU7TUA8dT9qNys3NVYrVD9MNWk0VyNsbGJzZzhIXEsialZoXiQxMnFNVCNCYV8saUlxLzotZEMlVVFFZCooaCxTbSppK0QuOFc1ZlxVTUZcQUltJ1QvWCtjbVQzVG9iYnMvYVAlRD8hcF5dUGtXbEBEWDgyVW9DSyI7YlxmKS07SEBePmZHYFMzSDxeOTVaP1EmcU90TlRbPm1uKlJwSnReSkVca1RsRCMvOU8vNU89ZFk0OjE7O0dNSF5CTlUrLS5wMkpVWSZxOkRRPGU7JyM2MEMyWG5zJSdUZkRWZytGLVpPMWA/XiouLnBGKlUkL3FyWy1zJDskQmNiZiRjRj4rIWwvbC46PXBGaFthJjhiQV1YITlYTGwzSzY7WHJsb04ldW9aWXNAZkU/W2ZCKjk2aT8zSjVXdURFI2VTMU9KVyU0YSxzUjxNNGZfYGpiUCMzUVo7bjhhcDUxM20jWlRbYl1MUTs1TFcsWFFxQnJWLCFfTS8jNFtvQ0FUPmEsVUROQipvbGh1TktATjcsaGZIO0wlJGdkWjhWdEgmaWRPKkRtPDU1PUhZbnBTNShLMEldJUFDcVNbZS80cS01T0lcKTVSTypnI05MUVxGSWs4YFstbi9HdVUxTkEuXjEhNTg7Ry03cidISVkqYVpJQDZnJmElXVFDdW4uXnEkJEBRVCk8MmYjQ2Y0XVtEWkxIQVNuK0lMXF4xUEw9J3ByNCsrYX4+ZW5kc3RyZWFtCmVuZG9iagp4cmVmCjAgMTAKMDAwMDAwMDAwMCA2NTUzNSBmIAowMDAwMDAwMDYxIDAwMDAwIG4gCjAwMDAwMDAxMTIgMDAwMDAgbiAKMDAwMDAwMDIxOSAwMDAwMCBuIAowMDAwMDAwMzMxIDAwMDAwIG4gCjAwMDAwMDA0NDYgMDAwMDAgbiAKMDAwMDAwMDY0OSAwMDAwMCBuIAowMDAwMDAwNzE3IDAwMDAwIG4gCjAwMDAwMDA5NzggMDAwMDAgbiAKMDAwMDAwMTAzNyAwMDAwMCBuIAp0cmFpbGVyCjw8Ci9JRCAKWzxiMTk5YWMxMzNiZjJhZmUxYTVkNDczZmVjM2RkOGUwYz48YjE5OWFjMTMzYmYyYWZlMWE1ZDQ3M2ZlYzNkZDhlMGM+XQolIFJlcG9ydExhYiBnZW5lcmF0ZWQgUERGIGRvY3VtZW50IC0tIGRpZ2VzdCAob3BlbnNvdXJjZSkKCi9JbmZvIDcgMCBSCi9Sb290IDYgMCBSCi9TaXplIDEwCj4+CnN0YXJ0eHJlZgoxOTU4CiUlRU9GCg==",
  "PST 41228": "data:application/pdf;base64,JVBERi0xLjMKJZOMi54gUmVwb3J0TGFiIEdlbmVyYXRlZCBQREYgZG9jdW1lbnQgKG9wZW5zb3VyY2UpCjEgMCBvYmoKPDwKL0YxIDIgMCBSIC9GMiAzIDAgUiAvRjMgNCAwIFIKPj4KZW5kb2JqCjIgMCBvYmoKPDwKL0Jhc2VGb250IC9IZWx2ZXRpY2EgL0VuY29kaW5nIC9XaW5BbnNpRW5jb2RpbmcgL05hbWUgL0YxIC9TdWJ0eXBlIC9UeXBlMSAvVHlwZSAvRm9udAo+PgplbmRvYmoKMyAwIG9iago8PAovQmFzZUZvbnQgL0hlbHZldGljYS1Cb2xkIC9FbmNvZGluZyAvV2luQW5zaUVuY29kaW5nIC9OYW1lIC9GMiAvU3VidHlwZSAvVHlwZTEgL1R5cGUgL0ZvbnQKPj4KZW5kb2JqCjQgMCBvYmoKPDwKL0Jhc2VGb250IC9IZWx2ZXRpY2EtT2JsaXF1ZSAvRW5jb2RpbmcgL1dpbkFuc2lFbmNvZGluZyAvTmFtZSAvRjMgL1N1YnR5cGUgL1R5cGUxIC9UeXBlIC9Gb250Cj4+CmVuZG9iago1IDAgb2JqCjw8Ci9Db250ZW50cyA5IDAgUiAvTWVkaWFCb3ggWyAwIDAgNTk1LjI3NTYgODQxLjg4OTggXSAvUGFyZW50IDggMCBSIC9SZXNvdXJjZXMgPDwKL0ZvbnQgMSAwIFIgL1Byb2NTZXQgWyAvUERGIC9UZXh0IC9JbWFnZUIgL0ltYWdlQyAvSW1hZ2VJIF0KPj4gL1JvdGF0ZSAwIC9UcmFucyA8PAoKPj4gCiAgL1R5cGUgL1BhZ2UKPj4KZW5kb2JqCjYgMCBvYmoKPDwKL1BhZ2VNb2RlIC9Vc2VOb25lIC9QYWdlcyA4IDAgUiAvVHlwZSAvQ2F0YWxvZwo+PgplbmRvYmoKNyAwIG9iago8PAovQXV0aG9yIChhbm9ueW1vdXMpIC9DcmVhdGlvbkRhdGUgKEQ6MjAyNjA5MDEwMDU4MTYrMDAnMDAnKSAvQ3JlYXRvciAoYW5vbnltb3VzKSAvS2V5d29yZHMgKCkgL01vZERhdGUgKEQ6MjAyNjA5MDEwMDU4MTYrMDAnMDAnKSAvUHJvZHVjZXIgKFJlcG9ydExhYiBQREYgTGlicmFyeSAtIFwob3BlbnNvdXJjZVwpKSAKICAvU3ViamVjdCAodW5zcGVjaWZpZWQpIC9UaXRsZSAodW50aXRsZWQpIC9UcmFwcGVkIC9GYWxzZQo+PgplbmRvYmoKOCAwIG9iago8PAovQ291bnQgMSAvS2lkcyBbIDUgMCBSIF0gL1R5cGUgL1BhZ2VzCj4+CmVuZG9iago5IDAgb2JqCjw8Ci9GaWx0ZXIgWyAvQVNDSUk4NURlY29kZSAvRmxhdGVEZWNvZGUgXSAvTGVuZ3RoIDgyNwo+PgpzdHJlYW0KR2F0PWg/VmZFMSdaSnUqJ19jO0NlPSwjYm0iQDtVMkA0KCtadDtYZ0ddPUJxNFJ1OlY7cT5tJUNTc2stMElpYmFPXl9KLmoqVTRlVG9lMiJqMHJiKDUqZzBZS2BZZ15oPnA+QiRLWUBhPlRPR0tKTTdSZTk8YklMJV8nVz8mdDdqLDxiLW0qOUwrXk9SSC1cYmVTb19bSi9FWlFHRCVgRUglN1lCYCJuNnJGSzcmM2lJV2VHS2NoOFo6cHUocUtqI3QsPGlSL14oJls6Pj4kR1k7IyZZPEJFNG1bWT5TIyFSPGQ0TktiJFJzZERsS3Erbj0jZkEsW2pxR1svYGxMQSw0KENlQDM/Wls9dVQ+SC82Pig9Ly80V0IxYmI2NFkmNEdQKE1iNTgyPFlUU2tiR1VGbGMrTWxXYGhjUnEuImBBS2RWPD5jVi5sXlh0K0lGX0s6YEtgLDdKJ05mWFBaYCVydWY0MVQ3JDRVNVpyVjI3USQtPUJUXiIiKUcsci0sVFJIOy00YiFYcThcbk9qSVJSKExES0M7bEIlSlFgT180JnIibSRYPi9WdTorRCsyRF9WUzpSW2ltMlQpUmtBQipNJ1xvWHUpVjxdT24sPksxTWoiRUFHVHBpYWFhLmJhRDpSJmtXIydoRF1YZystPlhSMFQ9UDMhUUgpSDlXLSYibWU6PktVXmN0aWQzPDo4VEE7K1pXUiM6cEYpV0tbQzYkWnNaaGk/QzZZTy1NWVAjOVZtLCsxa14xKzRVTGAuUXIkY2EtOzVqLj5yIVljZmB0MU5cZXRLXlhwMFQ3JGc4KkY6SilVQzU1OkkrX1EnZGNqQEVaKEElRzxjQSYjSUxvUV1naTs/XTQqaDVLalE6VFc5MTJcYU9BZ0hLLm1jJy1iOW9yX2MncGAzWk82MzJyMygrUE40RiRlVHFxLUs1UTUpJjlWZlJgdUooSkpySyZhXDI/aj1ubiNhT1dPRFAmcCdaLHQsRiRdYTEkXWksM0wmOC00b1BAQC5qRjVzbmo5P2BWPWVqYkAqYCI5T1tTUWI3aEBTXWk3S0FcMHQvZXQ3Njsya3NNIkUzaSVCbmg3KWE9TW0nfj5lbmRzdHJlYW0KZW5kb2JqCnhyZWYKMCAxMAowMDAwMDAwMDAwIDY1NTM1IGYgCjAwMDAwMDAwNjEgMDAwMDAgbiAKMDAwMDAwMDExMiAwMDAwMCBuIAowMDAwMDAwMjE5IDAwMDAwIG4gCjAwMDAwMDAzMzEgMDAwMDAgbiAKMDAwMDAwMDQ0NiAwMDAwMCBuIAowMDAwMDAwNjQ5IDAwMDAwIG4gCjAwMDAwMDA3MTcgMDAwMDAgbiAKMDAwMDAwMDk3OCAwMDAwMCBuIAowMDAwMDAxMDM3IDAwMDAwIG4gCnRyYWlsZXIKPDwKL0lEIApbPDRjYzA3NWRjYzFlZDQ5ZDI2NjIzZTkzOTQyMmEwZGNhPjw0Y2MwNzVkY2MxZWQ0OWQyNjYyM2U5Mzk0MjJhMGRjYT5dCiUgUmVwb3J0TGFiIGdlbmVyYXRlZCBQREYgZG9jdW1lbnQgLS0gZGlnZXN0IChvcGVuc291cmNlKQoKL0luZm8gNyAwIFIKL1Jvb3QgNiAwIFIKL1NpemUgMTAKPj4Kc3RhcnR4cmVmCjE5NTQKJSVFT0YK",
  "PST 41229": "data:application/pdf;base64,JVBERi0xLjMKJZOMi54gUmVwb3J0TGFiIEdlbmVyYXRlZCBQREYgZG9jdW1lbnQgKG9wZW5zb3VyY2UpCjEgMCBvYmoKPDwKL0YxIDIgMCBSIC9GMiAzIDAgUiAvRjMgNCAwIFIKPj4KZW5kb2JqCjIgMCBvYmoKPDwKL0Jhc2VGb250IC9IZWx2ZXRpY2EgL0VuY29kaW5nIC9XaW5BbnNpRW5jb2RpbmcgL05hbWUgL0YxIC9TdWJ0eXBlIC9UeXBlMSAvVHlwZSAvRm9udAo+PgplbmRvYmoKMyAwIG9iago8PAovQmFzZUZvbnQgL0hlbHZldGljYS1Cb2xkIC9FbmNvZGluZyAvV2luQW5zaUVuY29kaW5nIC9OYW1lIC9GMiAvU3VidHlwZSAvVHlwZTEgL1R5cGUgL0ZvbnQKPj4KZW5kb2JqCjQgMCBvYmoKPDwKL0Jhc2VGb250IC9IZWx2ZXRpY2EtT2JsaXF1ZSAvRW5jb2RpbmcgL1dpbkFuc2lFbmNvZGluZyAvTmFtZSAvRjMgL1N1YnR5cGUgL1R5cGUxIC9UeXBlIC9Gb250Cj4+CmVuZG9iago1IDAgb2JqCjw8Ci9Db250ZW50cyA5IDAgUiAvTWVkaWFCb3ggWyAwIDAgNTk1LjI3NTYgODQxLjg4OTggXSAvUGFyZW50IDggMCBSIC9SZXNvdXJjZXMgPDwKL0ZvbnQgMSAwIFIgL1Byb2NTZXQgWyAvUERGIC9UZXh0IC9JbWFnZUIgL0ltYWdlQyAvSW1hZ2VJIF0KPj4gL1JvdGF0ZSAwIC9UcmFucyA8PAoKPj4gCiAgL1R5cGUgL1BhZ2UKPj4KZW5kb2JqCjYgMCBvYmoKPDwKL1BhZ2VNb2RlIC9Vc2VOb25lIC9QYWdlcyA4IDAgUiAvVHlwZSAvQ2F0YWxvZwo+PgplbmRvYmoKNyAwIG9iago8PAovQXV0aG9yIChhbm9ueW1vdXMpIC9DcmVhdGlvbkRhdGUgKEQ6MjAyNjA5MDEwMDU4MTYrMDAnMDAnKSAvQ3JlYXRvciAoYW5vbnltb3VzKSAvS2V5d29yZHMgKCkgL01vZERhdGUgKEQ6MjAyNjA5MDEwMDU4MTYrMDAnMDAnKSAvUHJvZHVjZXIgKFJlcG9ydExhYiBQREYgTGlicmFyeSAtIFwob3BlbnNvdXJjZVwpKSAKICAvU3ViamVjdCAodW5zcGVjaWZpZWQpIC9UaXRsZSAodW50aXRsZWQpIC9UcmFwcGVkIC9GYWxzZQo+PgplbmRvYmoKOCAwIG9iago8PAovQ291bnQgMSAvS2lkcyBbIDUgMCBSIF0gL1R5cGUgL1BhZ2VzCj4+CmVuZG9iago5IDAgb2JqCjw8Ci9GaWx0ZXIgWyAvQVNDSUk4NURlY29kZSAvRmxhdGVEZWNvZGUgXSAvTGVuZ3RoIDgyMAo+PgpzdHJlYW0KR2F0PWhkO0lEZSdTYylOJ14jaD43KHE1Sm0lZWlYSk1fJ1tZUWM4SGg3LzxyUjNjaldTVzpFSS1WYlBTKWsvW1xXYDFNSUlldTRJTEktUydOU2RfRG4/Lkc+TnRhIXBFV245Ry4/bks3VGZhSF4hYiEmU1FmLUYiKlBPLV44bmE3Tj1jajpDMUJCcDJBPEk8JDo7Y0FkISY9OSxnQ19TWWpzLSpmLCdIZGZWbjc+bSNUJkdOLy1PKD5MOVc+Qz9Ec11AQzk/NEs8bCpENUNwYGRcQ3VMNyskKGkiW1NFTzppZC08NnJKYXMmMUxIRmRyN3NIUlo7TmBeZEBiTSldLjpePzg1SFpyRlgpbmc+RDssUmU0MU5ZcmYiKWZNMC5WbXBIVWdiPlckKG1MVG8+LChWYzJmSVkvNV8jL284bWAkTkAybktDZ2BIRks+QS1IYitcZGJiNmJIJ0RER0c7O2cuIVNBaCI+PjdaXko6VC81Qm9eKm03JnM+WzFIYEIxcDhuOTgyMSwmIys5WGZjNWZqSD5icHBcVUVNUC9SPUFSLkEpS05JWl4wKDpoSihKbjc+a1FBUHRcZi0xLF9tN1xoZz1qVVNdIjc9UmNOLUptVEUhYSxLOGcuM0dUcGtXI2hFQHBoQU5NMF4vQjQiaCk3QkBUZkpeLTY2b0tgXjFpI0VDblw1TFdWaFtmOytaWShqY09kVlYkJVhHNVxGbUNWXUQ1KUxGTy5xVHJqUyNcbHQoWDwtKV49KSZpbDA7QVJxTFQkT10mcCtRLEBcQ1Q1SlVcPChEW15IKzJnKWZXRzohVzxdVEYmPi4oOi9BdWEqbGheNnJoQkZuNnI3KVFMNSJzWzclVEwnYyxqal1aYHBoM1NoXmwxUmNQZj9HUjM3VVJRIjslXWJTa1VWJEBfW1wvOmJgQyZnMTdhXygvaEFBSHErLlw/R1lgSGhFJyRdbXNSNnFSRVNEN0NkKiVUS05dKTMpVSkuKCVRUi0qJVhuXExWPiVacVlmN1pHQkNqNktybUM5PlBIImNGcz1vbF81UklxSFIuX1I7QSZuXiw7MUhiWicvaSY6YSRKKSh+PmVuZHN0cmVhbQplbmRvYmoKeHJlZgowIDEwCjAwMDAwMDAwMDAgNjU1MzUgZiAKMDAwMDAwMDA2MSAwMDAwMCBuIAowMDAwMDAwMTEyIDAwMDAwIG4gCjAwMDAwMDAyMTkgMDAwMDAgbiAKMDAwMDAwMDMzMSAwMDAwMCBuIAowMDAwMDAwNDQ2IDAwMDAwIG4gCjAwMDAwMDA2NDkgMDAwMDAgbiAKMDAwMDAwMDcxNyAwMDAwMCBuIAowMDAwMDAwOTc4IDAwMDAwIG4gCjAwMDAwMDEwMzcgMDAwMDAgbiAKdHJhaWxlcgo8PAovSUQgCls8YWQyY2M1MjNmZDIzYTIzNTYxNDY3MzdmNjExZTM3MjI+PGFkMmNjNTIzZmQyM2EyMzU2MTQ2NzM3ZjYxMWUzNzIyPl0KJSBSZXBvcnRMYWIgZ2VuZXJhdGVkIFBERiBkb2N1bWVudCAtLSBkaWdlc3QgKG9wZW5zb3VyY2UpCgovSW5mbyA3IDAgUgovUm9vdCA2IDAgUgovU2l6ZSAxMAo+PgpzdGFydHhyZWYKMTk0NwolJUVPRgo=",
  "PST 41232": "data:application/pdf;base64,JVBERi0xLjMKJZOMi54gUmVwb3J0TGFiIEdlbmVyYXRlZCBQREYgZG9jdW1lbnQgKG9wZW5zb3VyY2UpCjEgMCBvYmoKPDwKL0YxIDIgMCBSIC9GMiAzIDAgUiAvRjMgNCAwIFIKPj4KZW5kb2JqCjIgMCBvYmoKPDwKL0Jhc2VGb250IC9IZWx2ZXRpY2EgL0VuY29kaW5nIC9XaW5BbnNpRW5jb2RpbmcgL05hbWUgL0YxIC9TdWJ0eXBlIC9UeXBlMSAvVHlwZSAvRm9udAo+PgplbmRvYmoKMyAwIG9iago8PAovQmFzZUZvbnQgL0hlbHZldGljYS1Cb2xkIC9FbmNvZGluZyAvV2luQW5zaUVuY29kaW5nIC9OYW1lIC9GMiAvU3VidHlwZSAvVHlwZTEgL1R5cGUgL0ZvbnQKPj4KZW5kb2JqCjQgMCBvYmoKPDwKL0Jhc2VGb250IC9IZWx2ZXRpY2EtT2JsaXF1ZSAvRW5jb2RpbmcgL1dpbkFuc2lFbmNvZGluZyAvTmFtZSAvRjMgL1N1YnR5cGUgL1R5cGUxIC9UeXBlIC9Gb250Cj4+CmVuZG9iago1IDAgb2JqCjw8Ci9Db250ZW50cyA5IDAgUiAvTWVkaWFCb3ggWyAwIDAgNTk1LjI3NTYgODQxLjg4OTggXSAvUGFyZW50IDggMCBSIC9SZXNvdXJjZXMgPDwKL0ZvbnQgMSAwIFIgL1Byb2NTZXQgWyAvUERGIC9UZXh0IC9JbWFnZUIgL0ltYWdlQyAvSW1hZ2VJIF0KPj4gL1JvdGF0ZSAwIC9UcmFucyA8PAoKPj4gCiAgL1R5cGUgL1BhZ2UKPj4KZW5kb2JqCjYgMCBvYmoKPDwKL1BhZ2VNb2RlIC9Vc2VOb25lIC9QYWdlcyA4IDAgUiAvVHlwZSAvQ2F0YWxvZwo+PgplbmRvYmoKNyAwIG9iago8PAovQXV0aG9yIChhbm9ueW1vdXMpIC9DcmVhdGlvbkRhdGUgKEQ6MjAyNjA5MDEwMDU4MTYrMDAnMDAnKSAvQ3JlYXRvciAoYW5vbnltb3VzKSAvS2V5d29yZHMgKCkgL01vZERhdGUgKEQ6MjAyNjA5MDEwMDU4MTYrMDAnMDAnKSAvUHJvZHVjZXIgKFJlcG9ydExhYiBQREYgTGlicmFyeSAtIFwob3BlbnNvdXJjZVwpKSAKICAvU3ViamVjdCAodW5zcGVjaWZpZWQpIC9UaXRsZSAodW50aXRsZWQpIC9UcmFwcGVkIC9GYWxzZQo+PgplbmRvYmoKOCAwIG9iago8PAovQ291bnQgMSAvS2lkcyBbIDUgMCBSIF0gL1R5cGUgL1BhZ2VzCj4+CmVuZG9iago5IDAgb2JqCjw8Ci9GaWx0ZXIgWyAvQVNDSUk4NURlY29kZSAvRmxhdGVEZWNvZGUgXSAvTGVuZ3RoIDgxNgo+PgpzdHJlYW0KR2F0PWg5aSdPdSY7S1pOLyo7TGdgLVBvVFluTSFoPXBZTD1lNGtXSEVBPD0nXGcyOlYzKG9URmhtI1BMbTZYcV4tKC4rNTRnNCU+JWdpVkwxcmNPIXBlXGllJypaT09dRT1VYydacGdZPU8lMks1U3NhQy0rTUwsX3IjI3AkLWkhZzxiLW0qOUwrXk9SSC1cYmRyOUxqNk9bO3JHRCVgRUglN1lCYCJOakJkaktSWyNUJkdOLy1PKD5MOWBERD5IMW9oZTRSLi9LN1wkND1fZnI1Xk9bP0QsWztvbzM3R1FdXj1BZCgmKjZTOCYiZmRSVlhUYjtVYTBBUjcoISJnLkg+NyhUL0xrb2lSRz03a1k4UD8ma0YzWC8kQ2NaJCdOJnRgIy1VQTNbbkB1YiliYzZCQyM0RVdJPENANiRgWixoPE1nbCNOcl06VGFtJkNTP1clWkxdUzc4RXUmbU5EKjljcV43XUNbVUU8aDMtbTtgKFpJYGg4VWRTaDMsUCwwPmpsLmJDLG1KJSJYZGU4VGYjSU1fMjxJYl1AbGxaI2InJSpaJVApXSo8T0InX0k6RzQwPT40dXRdTnVKOCsmdUQmb0MoQShTTnEvMicxcTNqOV1tRUM8XmUwTWlULDxxMy1icF08WWlSYVAtK0BBaEluJC04S2o3cjp0Sm4uMl1GL15EbFZkQHAvK0Q9TjktMUg2X3Nuaz5iSC5dJS1RQmUqNUoqY10vaixvUlVCUiNIVSRsZS1LLkE4LDI6Ki5IJDUvNk1pUlFTZzpDIThxU0JhaT8lYC1RZzprc11hQjtnXEZGcnRFYEI2QT5QSjFyRFUrLyRua0MwTTtSJzsqMWgnLS46YXBgWGUxKlw3MkY7SjwuQm5IOC9YWUJcbC5pY2JEKkFva29SYEFwPnBUWGxKLzFbPD06P048c3MvT1tfI2BdLWNKZjJxSVlZKFldXTYzNzRgJC1SWWs4UkxGRkFHIVZSNWkpJTlUIVA+U0pjNmVGJCJcQUFTa0JwN1UwNWNXYChEZ1ZkWy1QTS9UOlRuN09VYGlkPF9cUk5ZP0ElZTReJF9zQjw+Pl5aX34+ZW5kc3RyZWFtCmVuZG9iagp4cmVmCjAgMTAKMDAwMDAwMDAwMCA2NTUzNSBmIAowMDAwMDAwMDYxIDAwMDAwIG4gCjAwMDAwMDAxMTIgMDAwMDAgbiAKMDAwMDAwMDIxOSAwMDAwMCBuIAowMDAwMDAwMzMxIDAwMDAwIG4gCjAwMDAwMDA0NDYgMDAwMDAgbiAKMDAwMDAwMDY0OSAwMDAwMCBuIAowMDAwMDAwNzE3IDAwMDAwIG4gCjAwMDAwMDA5NzggMDAwMDAgbiAKMDAwMDAwMTAzNyAwMDAwMCBuIAp0cmFpbGVyCjw8Ci9JRCAKWzxjYjk2OTZkMWZhMDdjOGExY2I3NGIwYjZjYjAxYzI2Yz48Y2I5Njk2ZDFmYTA3YzhhMWNiNzRiMGI2Y2IwMWMyNmM+XQolIFJlcG9ydExhYiBnZW5lcmF0ZWQgUERGIGRvY3VtZW50IC0tIGRpZ2VzdCAob3BlbnNvdXJjZSkKCi9JbmZvIDcgMCBSCi9Sb290IDYgMCBSCi9TaXplIDEwCj4+CnN0YXJ0eHJlZgoxOTQzCiUlRU9GCg==",
  "PST 41230": "data:application/pdf;base64,JVBERi0xLjMKJZOMi54gUmVwb3J0TGFiIEdlbmVyYXRlZCBQREYgZG9jdW1lbnQgKG9wZW5zb3VyY2UpCjEgMCBvYmoKPDwKL0YxIDIgMCBSIC9GMiAzIDAgUiAvRjMgNCAwIFIKPj4KZW5kb2JqCjIgMCBvYmoKPDwKL0Jhc2VGb250IC9IZWx2ZXRpY2EgL0VuY29kaW5nIC9XaW5BbnNpRW5jb2RpbmcgL05hbWUgL0YxIC9TdWJ0eXBlIC9UeXBlMSAvVHlwZSAvRm9udAo+PgplbmRvYmoKMyAwIG9iago8PAovQmFzZUZvbnQgL0hlbHZldGljYS1Cb2xkIC9FbmNvZGluZyAvV2luQW5zaUVuY29kaW5nIC9OYW1lIC9GMiAvU3VidHlwZSAvVHlwZTEgL1R5cGUgL0ZvbnQKPj4KZW5kb2JqCjQgMCBvYmoKPDwKL0Jhc2VGb250IC9IZWx2ZXRpY2EtT2JsaXF1ZSAvRW5jb2RpbmcgL1dpbkFuc2lFbmNvZGluZyAvTmFtZSAvRjMgL1N1YnR5cGUgL1R5cGUxIC9UeXBlIC9Gb250Cj4+CmVuZG9iago1IDAgb2JqCjw8Ci9Db250ZW50cyA5IDAgUiAvTWVkaWFCb3ggWyAwIDAgNTk1LjI3NTYgODQxLjg4OTggXSAvUGFyZW50IDggMCBSIC9SZXNvdXJjZXMgPDwKL0ZvbnQgMSAwIFIgL1Byb2NTZXQgWyAvUERGIC9UZXh0IC9JbWFnZUIgL0ltYWdlQyAvSW1hZ2VJIF0KPj4gL1JvdGF0ZSAwIC9UcmFucyA8PAoKPj4gCiAgL1R5cGUgL1BhZ2UKPj4KZW5kb2JqCjYgMCBvYmoKPDwKL1BhZ2VNb2RlIC9Vc2VOb25lIC9QYWdlcyA4IDAgUiAvVHlwZSAvQ2F0YWxvZwo+PgplbmRvYmoKNyAwIG9iago8PAovQXV0aG9yIChhbm9ueW1vdXMpIC9DcmVhdGlvbkRhdGUgKEQ6MjAyNjA5MDEwMDU4MTYrMDAnMDAnKSAvQ3JlYXRvciAoYW5vbnltb3VzKSAvS2V5d29yZHMgKCkgL01vZERhdGUgKEQ6MjAyNjA5MDEwMDU4MTYrMDAnMDAnKSAvUHJvZHVjZXIgKFJlcG9ydExhYiBQREYgTGlicmFyeSAtIFwob3BlbnNvdXJjZVwpKSAKICAvU3ViamVjdCAodW5zcGVjaWZpZWQpIC9UaXRsZSAodW50aXRsZWQpIC9UcmFwcGVkIC9GYWxzZQo+PgplbmRvYmoKOCAwIG9iago8PAovQ291bnQgMSAvS2lkcyBbIDUgMCBSIF0gL1R5cGUgL1BhZ2VzCj4+CmVuZG9iago5IDAgb2JqCjw8Ci9GaWx0ZXIgWyAvQVNDSUk4NURlY29kZSAvRmxhdGVEZWNvZGUgXSAvTGVuZ3RoIDg0MQo+PgpzdHJlYW0KR2F0PWg7L2FvOyZCRV0qLklJTFo7c1ZER0BPSExBJSY/SC8icTxtaUlJUnJaMUo/YE1GdW9LZVxNc2JQRFFNOU5XWGh1IXF0a2oqM3NsOVgyI15RLl50VExJNT5cIV1hcWA5ZlVlbE1ucFo3JykkQTxDQT5fNjBVM3JFNXBQZ0NFLUIxNTpXYlFKVWRPXCUvLjMiO3BwJCJFRD9ZOVQ4NGJtLFlsNy1wV0JUJ2wxUiw/dW8sWjRKO0EpOTArKFo7QSRRV082TDwjNmohR1pkbT9qWV8rNjMmb0pJMj5qNzVnVSIqRi5MJTZVVUI3JnBNLHM3TUAuN2s/bTBsNm9mUGpyO0Y/WyJmSjonXCFSLi45aj1wOTZaaVtjUilQOy0iPFxPJU4pVVckKG1EVG8+LChWZG5wXD8laj5CSUJsMDkxJi1OKSVhbGRXRks3UXIhTmxya19dMFM5Mys7ajUmSSRhV2s6R2M+RDtALGg1LDV1c2QxPVJlOGs5X2NtJXNDXS4/VSVmYUAkbz0+XWpccl41LDhHWVg7QFldKD1MRC50IkNMRl5QRT0ub2k6XS45KmBtcXAmLmoodSltSGZqSD5iJSEoTjxiJlJqWG0sY0xfRjosJUtzI29KLVpOczxOLCYnL3RZMUZUIyppZDZSb2cjWGRwUXUzJVdFUlg3Qz88UGYyPWN0RytyVC8uPzBoQiIjR3A3RGIuaCsoUSkpSycqZjNOPi0sQDsiM2ImdURbPCghJC5iXS5NLyksOGo8MkNMNGYyWywxciIxUmctVzFgNStlSSNjJGFiaD8kP3Q0OGgtXydAWExtKEFrWzFARzIjN0o8YjZybktwYFdlYW5kRHRfQ2A3cik4cExrMG9YMkxDST8mTzIoP3NPUWBaTjFDTjIydW02W1VWYCQxZERhX1hfSUo7Kk1SakhLVDg+WixPO1RPMEpqNy8xWztRVl9hNF1eWnFya0tDUWUiKzlTZ29ZWm1qdF9gaSxpQFshImo7aVdxT3IvSTMoOE49VVo5VCFoaD5vPWBTXGE5S2JaOEhCMTdiaFFyZVojcXRGcjtpUzM7O2dNJUs3bzdcXF00PiQ0IURlVVxzbUZfck5gZWRYa2F+PmVuZHN0cmVhbQplbmRvYmoKeHJlZgowIDEwCjAwMDAwMDAwMDAgNjU1MzUgZiAKMDAwMDAwMDA2MSAwMDAwMCBuIAowMDAwMDAwMTEyIDAwMDAwIG4gCjAwMDAwMDAyMTkgMDAwMDAgbiAKMDAwMDAwMDMzMSAwMDAwMCBuIAowMDAwMDAwNDQ2IDAwMDAwIG4gCjAwMDAwMDA2NDkgMDAwMDAgbiAKMDAwMDAwMDcxNyAwMDAwMCBuIAowMDAwMDAwOTc4IDAwMDAwIG4gCjAwMDAwMDEwMzcgMDAwMDAgbiAKdHJhaWxlcgo8PAovSUQgCls8ZjhlZWY0M2UwMjFiMTRjMjdiMzEzMDQzNDViZDFjZDI+PGY4ZWVmNDNlMDIxYjE0YzI3YjMxMzA0MzQ1YmQxY2QyPl0KJSBSZXBvcnRMYWIgZ2VuZXJhdGVkIFBERiBkb2N1bWVudCAtLSBkaWdlc3QgKG9wZW5zb3VyY2UpCgovSW5mbyA3IDAgUgovUm9vdCA2IDAgUgovU2l6ZSAxMAo+PgpzdGFydHhyZWYKMTk2OAolJUVPRgo=",
  "PST 41231": "data:application/pdf;base64,JVBERi0xLjMKJZOMi54gUmVwb3J0TGFiIEdlbmVyYXRlZCBQREYgZG9jdW1lbnQgKG9wZW5zb3VyY2UpCjEgMCBvYmoKPDwKL0YxIDIgMCBSIC9GMiAzIDAgUiAvRjMgNCAwIFIKPj4KZW5kb2JqCjIgMCBvYmoKPDwKL0Jhc2VGb250IC9IZWx2ZXRpY2EgL0VuY29kaW5nIC9XaW5BbnNpRW5jb2RpbmcgL05hbWUgL0YxIC9TdWJ0eXBlIC9UeXBlMSAvVHlwZSAvRm9udAo+PgplbmRvYmoKMyAwIG9iago8PAovQmFzZUZvbnQgL0hlbHZldGljYS1Cb2xkIC9FbmNvZGluZyAvV2luQW5zaUVuY29kaW5nIC9OYW1lIC9GMiAvU3VidHlwZSAvVHlwZTEgL1R5cGUgL0ZvbnQKPj4KZW5kb2JqCjQgMCBvYmoKPDwKL0Jhc2VGb250IC9IZWx2ZXRpY2EtT2JsaXF1ZSAvRW5jb2RpbmcgL1dpbkFuc2lFbmNvZGluZyAvTmFtZSAvRjMgL1N1YnR5cGUgL1R5cGUxIC9UeXBlIC9Gb250Cj4+CmVuZG9iago1IDAgb2JqCjw8Ci9Db250ZW50cyA5IDAgUiAvTWVkaWFCb3ggWyAwIDAgNTk1LjI3NTYgODQxLjg4OTggXSAvUGFyZW50IDggMCBSIC9SZXNvdXJjZXMgPDwKL0ZvbnQgMSAwIFIgL1Byb2NTZXQgWyAvUERGIC9UZXh0IC9JbWFnZUIgL0ltYWdlQyAvSW1hZ2VJIF0KPj4gL1JvdGF0ZSAwIC9UcmFucyA8PAoKPj4gCiAgL1R5cGUgL1BhZ2UKPj4KZW5kb2JqCjYgMCBvYmoKPDwKL1BhZ2VNb2RlIC9Vc2VOb25lIC9QYWdlcyA4IDAgUiAvVHlwZSAvQ2F0YWxvZwo+PgplbmRvYmoKNyAwIG9iago8PAovQXV0aG9yIChhbm9ueW1vdXMpIC9DcmVhdGlvbkRhdGUgKEQ6MjAyNjA5MDEwMDU4MTYrMDAnMDAnKSAvQ3JlYXRvciAoYW5vbnltb3VzKSAvS2V5d29yZHMgKCkgL01vZERhdGUgKEQ6MjAyNjA5MDEwMDU4MTYrMDAnMDAnKSAvUHJvZHVjZXIgKFJlcG9ydExhYiBQREYgTGlicmFyeSAtIFwob3BlbnNvdXJjZVwpKSAKICAvU3ViamVjdCAodW5zcGVjaWZpZWQpIC9UaXRsZSAodW50aXRsZWQpIC9UcmFwcGVkIC9GYWxzZQo+PgplbmRvYmoKOCAwIG9iago8PAovQ291bnQgMSAvS2lkcyBbIDUgMCBSIF0gL1R5cGUgL1BhZ2VzCj4+CmVuZG9iago5IDAgb2JqCjw8Ci9GaWx0ZXIgWyAvQVNDSUk4NURlY29kZSAvRmxhdGVEZWNvZGUgXSAvTGVuZ3RoIDgyMAo+PgpzdHJlYW0KR2F0PWhhX29pZSY7S1kmTUUpRGc/bychQE0sSjUuZGZLUVVUaVAjKWFHI3IiL2ZTWE0uND1RNEc9M2EubF9INkhCRTlBVWhwOysyaT1PRFFfbkR1TDUzNmJdUGxoaGFZQ09zUCo6ZTFHUCJ1cVheaztoOygiaTJUVSNkY2ROMlE7M2M9LywiUzNSaUUncj1KJygxRD5CK1VmQnUzXjxsPEZGWF9ET3A8REtrN0BFRz9ucjtxPDBqYWpgWyJkK3FoOD9rWDRPck5ta2ZFMWJRYjEqSUxBKSQuKEVVRUUvTDNwXjtlMEJKR19AZTdoPSljNlsyMHNFPkFrSyJMUzdpazxlYSVKI1JqN0ZUcHM+PW5kNiVFLEY+MlNNU046N2s+ImNTSl5OVTIuPmAiV148cGhjOj9FKy80XiQpWk0hRU5qZSZKJ2JicVxcKVAnQStCRF4pPSVNKFVgTT51bGUpJFFZMCwzVzo9QVI/VGNPYlhtLkc7Jl8rWXJGR1ZDXF5QZCwlYCkmMVdPaFFTXTEkPVI0N3EpKCl1ajhIZGFsT1xAdS1zZkJbU1NGUCM0WllbMWRBZF4sRXBERyVMVTF1P1tLTVcjQkpzNTBxQWdIWnNOTiJjZEFuNV9KY2VfMXIvQ29KR0A6ZCZFa0RHLiZOSF9ZWSZjRVxdNjFcOmU+W2I9KClHLEI0c3A1TFNnYD9HYzApbTBtal5dY244LVpITTBeY1BaK0k4Xj1QV1ZoWF4uQnJGM0oxSGFtOG5JTlY/SSVPRHB0U2JxcS1WZS5ENlRRJEUoYTZqXXJuc1MmITVnLkEpcjx1LVJaN20iP3EhN0FJKTp0cFleRispUU1iKzkjP2JUQkZFaTFpYDQ0YjtZIzZgMldHRD5iRGlDZzk8KmxjSS5GL3VYZWcxRzpcWERrNDVpbE9mbFBMOE4wRVNiRStAXF1wdSc4JTdPVmdkMy5waSJIJ1hQRyxZKFhpOWxqbC5hNiVqdS91XFQ/Q2BIdWBgZCk/Y11yK1tiN00hVEhvQlNfJTwzKnE3SyNPJFpdY0lFb2olUXUwZUdWajxEUSUxNGhWRHEkYV49a3JKLDl+PmVuZHN0cmVhbQplbmRvYmoKeHJlZgowIDEwCjAwMDAwMDAwMDAgNjU1MzUgZiAKMDAwMDAwMDA2MSAwMDAwMCBuIAowMDAwMDAwMTEyIDAwMDAwIG4gCjAwMDAwMDAyMTkgMDAwMDAgbiAKMDAwMDAwMDMzMSAwMDAwMCBuIAowMDAwMDAwNDQ2IDAwMDAwIG4gCjAwMDAwMDA2NDkgMDAwMDAgbiAKMDAwMDAwMDcxNyAwMDAwMCBuIAowMDAwMDAwOTc4IDAwMDAwIG4gCjAwMDAwMDEwMzcgMDAwMDAgbiAKdHJhaWxlcgo8PAovSUQgCls8MzUyOGYwMmEwZmZmZjNjZTgwMDQ1NzFjM2I0NDczODI+PDM1MjhmMDJhMGZmZmYzY2U4MDA0NTcxYzNiNDQ3MzgyPl0KJSBSZXBvcnRMYWIgZ2VuZXJhdGVkIFBERiBkb2N1bWVudCAtLSBkaWdlc3QgKG9wZW5zb3VyY2UpCgovSW5mbyA3IDAgUgovUm9vdCA2IDAgUgovU2l6ZSAxMAo+PgpzdGFydHhyZWYKMTk0NwolJUVPRgo=",
  "PST 41233": "data:application/pdf;base64,JVBERi0xLjMKJZOMi54gUmVwb3J0TGFiIEdlbmVyYXRlZCBQREYgZG9jdW1lbnQgKG9wZW5zb3VyY2UpCjEgMCBvYmoKPDwKL0YxIDIgMCBSIC9GMiAzIDAgUiAvRjMgNCAwIFIKPj4KZW5kb2JqCjIgMCBvYmoKPDwKL0Jhc2VGb250IC9IZWx2ZXRpY2EgL0VuY29kaW5nIC9XaW5BbnNpRW5jb2RpbmcgL05hbWUgL0YxIC9TdWJ0eXBlIC9UeXBlMSAvVHlwZSAvRm9udAo+PgplbmRvYmoKMyAwIG9iago8PAovQmFzZUZvbnQgL0hlbHZldGljYS1Cb2xkIC9FbmNvZGluZyAvV2luQW5zaUVuY29kaW5nIC9OYW1lIC9GMiAvU3VidHlwZSAvVHlwZTEgL1R5cGUgL0ZvbnQKPj4KZW5kb2JqCjQgMCBvYmoKPDwKL0Jhc2VGb250IC9IZWx2ZXRpY2EtT2JsaXF1ZSAvRW5jb2RpbmcgL1dpbkFuc2lFbmNvZGluZyAvTmFtZSAvRjMgL1N1YnR5cGUgL1R5cGUxIC9UeXBlIC9Gb250Cj4+CmVuZG9iago1IDAgb2JqCjw8Ci9Db250ZW50cyA5IDAgUiAvTWVkaWFCb3ggWyAwIDAgNTk1LjI3NTYgODQxLjg4OTggXSAvUGFyZW50IDggMCBSIC9SZXNvdXJjZXMgPDwKL0ZvbnQgMSAwIFIgL1Byb2NTZXQgWyAvUERGIC9UZXh0IC9JbWFnZUIgL0ltYWdlQyAvSW1hZ2VJIF0KPj4gL1JvdGF0ZSAwIC9UcmFucyA8PAoKPj4gCiAgL1R5cGUgL1BhZ2UKPj4KZW5kb2JqCjYgMCBvYmoKPDwKL1BhZ2VNb2RlIC9Vc2VOb25lIC9QYWdlcyA4IDAgUiAvVHlwZSAvQ2F0YWxvZwo+PgplbmRvYmoKNyAwIG9iago8PAovQXV0aG9yIChhbm9ueW1vdXMpIC9DcmVhdGlvbkRhdGUgKEQ6MjAyNjA5MDEwMDU4MTYrMDAnMDAnKSAvQ3JlYXRvciAoYW5vbnltb3VzKSAvS2V5d29yZHMgKCkgL01vZERhdGUgKEQ6MjAyNjA5MDEwMDU4MTYrMDAnMDAnKSAvUHJvZHVjZXIgKFJlcG9ydExhYiBQREYgTGlicmFyeSAtIFwob3BlbnNvdXJjZVwpKSAKICAvU3ViamVjdCAodW5zcGVjaWZpZWQpIC9UaXRsZSAodW50aXRsZWQpIC9UcmFwcGVkIC9GYWxzZQo+PgplbmRvYmoKOCAwIG9iago8PAovQ291bnQgMSAvS2lkcyBbIDUgMCBSIF0gL1R5cGUgL1BhZ2VzCj4+CmVuZG9iago5IDAgb2JqCjw8Ci9GaWx0ZXIgWyAvQVNDSUk4NURlY29kZSAvRmxhdGVEZWNvZGUgXSAvTGVuZ3RoIDc5OQo+PgpzdHJlYW0KR2F0PWhkO0dGLSdTYylKJ14nNWJXbEUiOWZbLjZRaDUhWTs9IlIrcFV1Jlc+QTZvOV1BKCdLK0dBT1JhOT1kVG01WFpnW3FzRWtJKiIhIVkxZDdyVWkxYm4yOkQ+NDBFV245Ry4/ckhSWigpQ3VKTTdSZTk1czMiTFMpYksmdDdrWFhOMVsyUj1ISikxPEc0TVZkWF4nNk9bO3JGYkROQ0glN1lCYCIlW25rcTY8c18/RkVsJFVIUD5AO0g8aVFnLm07Wzh1XGlXOE1IKDJWSlZbRHJIXjIkK0ooai9wNEBmRGZ0NyM2MjsyOlA5Jz5ML05mQEguN2s/bTBlRUIoYXVIJGcoWlNtYTRVYztxQ19fQzhXYCpbUl9JMG5wXVBgS1BUaC1Mb2ZrVk1UImooK0JCOGtuNlNeT11haltccmRBJWBxXCduIldVNiRgbDIlKWs9Nj04VFZKKiNgbFhASzRYYyJcUWpXKDM6OCIqWkdRXGRIL0MzYShOJTIsYD5AaTtPcksqYUBwaGg/SkkvTlRYLnNNQSVQXCdHSltOZmxfWkRtKVcjdV9da3F1bjU/ZGZjQ0AhMi9EQjBGYEsnSSpMZT1eNz5AcjYyYkZwLzBNR0IhalwmPWk1WGReVEVbZ0hPISNLWSY5MW4kXztCXHAtZ1NPXEI/XlZZKjxfTCFvW2wpST4iUjhsQjFOTzJPKzAsc15BaVNbM0NJbEZiJCc8LHFTTD90SUJdTmhUSlRRMGcnV3FyKj9lS0csZW1DYGghZGZmPUdhR2M6Tk5EO0AqYiVlPWBPcU5rc283TldkZEdzVGRbaF49Pi1JTGJpRF4ranI7RStkT3JIX2JGWVJHZlEjQWdISy5tYzAzYzlvcl8jJ1ExWWkrNkI4ZUMzMik4VD50U21OJUhHZD1gTllxYzcpcnNVLFFaaWBlMEh0IiZFYk4tSU1hP1NOLkNoYU48PVdgaD4wRDtvXXU1MVtNV0lSJjhONF84QnNTN3VwbS0oX3FvP0xZJ0ApUkNgQ0QrQlUlLkgpJGhcOChiK0M6R140RCInS0pocVp+PmVuZHN0cmVhbQplbmRvYmoKeHJlZgowIDEwCjAwMDAwMDAwMDAgNjU1MzUgZiAKMDAwMDAwMDA2MSAwMDAwMCBuIAowMDAwMDAwMTEyIDAwMDAwIG4gCjAwMDAwMDAyMTkgMDAwMDAgbiAKMDAwMDAwMDMzMSAwMDAwMCBuIAowMDAwMDAwNDQ2IDAwMDAwIG4gCjAwMDAwMDA2NDkgMDAwMDAgbiAKMDAwMDAwMDcxNyAwMDAwMCBuIAowMDAwMDAwOTc4IDAwMDAwIG4gCjAwMDAwMDEwMzcgMDAwMDAgbiAKdHJhaWxlcgo8PAovSUQgCls8YTM4NzdkMWU2MjU4OTRiMmM4ODdmYTcwMDViZmZiMTA+PGEzODc3ZDFlNjI1ODk0YjJjODg3ZmE3MDA1YmZmYjEwPl0KJSBSZXBvcnRMYWIgZ2VuZXJhdGVkIFBERiBkb2N1bWVudCAtLSBkaWdlc3QgKG9wZW5zb3VyY2UpCgovSW5mbyA3IDAgUgovUm9vdCA2IDAgUgovU2l6ZSAxMAo+PgpzdGFydHhyZWYKMTkyNgolJUVPRgo=",
};

// 8 Year-4/Semester-I subjects the demo student is registered for (mirrors
// MOCK_SEMREGS / MOCK_ATTENDANCE_PLAN above) — one lecture-note upload and
// one assignment per subject, so "Lecture Materials" and "Assignments" have
// something to show even when the backend/DB isn't running.
const MOCK_MATERIALS_PLAN = [
  { code: "PST 41201", name: "Research Methodology and Scientific Communication", title: "Week 1-3 Notes — Research Design & Literature Review" },
  { code: "PST 41227", name: "Web Services", title: "Week 1-4 Notes — REST vs SOAP & API Design" },
  { code: "PST 41228", name: "Computer System Security", title: "Week 1-3 Notes — Threats, Cryptography & Access Control" },
  { code: "PST 41229", name: "Advanced Computer Networks", title: "Week 1-4 Notes — Routing Protocols & QoS" },
  { code: "PST 41232", name: "Cloud Computing", title: "Week 1-3 Notes — IaaS/PaaS/SaaS & Virtualization" },
  { code: "PST 41230", name: "Internet of Things (IoT)", title: "Week 1-3 Notes — IoT Architecture & Protocols" },
  { code: "PST 41231", name: "Natural Language Processing", title: "Week 1-4 Notes — Text Preprocessing & Embeddings" },
  { code: "PST 41233", name: "Business Process Management Systems", title: "Week 1-3 Notes — BPMN & Workflow Automation" },
];
const MOCK_MATERIALS = MOCK_MATERIALS_PLAN.map(({ code, name, title }, i) => ({
  id: i + 1,
  title,
  description: "Official lecture notes for this module — download and review before the next session.",
  file_path: LECTURE_NOTE_PDFS[code],
  original_name: `${code.replace(/\s+/g, "")}_Lecture_Notes.pdf`,
  uploaded_at: new Date(Date.now() - (MOCK_MATERIALS_PLAN.length - i) * 4 * 24 * 60 * 60 * 1000).toISOString(),
  code,
  course_name: name,
  year: 4,
  semester: 1,
}));

const MOCK_ASSIGNMENTS_PLAN = [
  { code: "PST 41201", name: "Research Methodology and Scientific Communication", title: "Literature Review Draft", days: 10, status: "pending" },
  { code: "PST 41227", name: "Web Services", title: "Assignment 1 — Build a REST API", days: 6, status: "pending" },
  { code: "PST 41228", name: "Computer System Security", title: "Vulnerability Assessment Report", days: -3, status: "submitted" },
  { code: "PST 41229", name: "Advanced Computer Networks", title: "Network Design Case Study", days: 14, status: "pending" },
  { code: "PST 41232", name: "Cloud Computing", title: "Cloud Deployment Proposal", days: -8, status: "submitted_late" },
  { code: "PST 41230", name: "Internet of Things (IoT)", title: "Sensor Network Prototype Report", days: 4, status: "pending" },
  { code: "PST 41231", name: "Natural Language Processing", title: "Text Classification Mini-Project", days: 9, status: "pending" },
  { code: "PST 41233", name: "Business Process Management Systems", title: "BPMN Process Model Assignment", days: -1, status: "submitted" },
];
const MOCK_ASSIGNMENTS = MOCK_ASSIGNMENTS_PLAN.map(({ code, name, title, days, status }, i) => ({
  id: i + 1,
  title,
  description: "See the module handout on Lecture Materials for the full assignment brief and marking rubric.",
  deadline: new Date(Date.now() + days * 24 * 60 * 60 * 1000).toISOString(),
  code,
  course_name: name,
  status,
  submission_id: status === "pending" ? null : i + 1,
  submitted_at: status === "pending" ? null : new Date(Date.now() + (days + (status === "submitted_late" ? 2 : -1)) * 24 * 60 * 60 * 1000).toISOString(),
}));

// Year 4 / Semester I published exam timetable — a single downloadable PDF
// document (as used by "Download Exam Timetable (PDF)") plus per-subject
// exam-schedule entries (date/time/venue) for the student's 8 registered
// Y4S1 courses, so the Exam Timetable page has real data in offline demo
// mode instead of "No exam dates have been published yet."
const Y4S1_TIMETABLE_PDF = "data:application/pdf;base64,JVBERi0xLjMKJZOMi54gUmVwb3J0TGFiIEdlbmVyYXRlZCBQREYgZG9jdW1lbnQgKG9wZW5zb3VyY2UpCjEgMCBvYmoKPDwKL0YxIDIgMCBSIC9GMiAzIDAgUiAvRjMgNCAwIFIKPj4KZW5kb2JqCjIgMCBvYmoKPDwKL0Jhc2VGb250IC9IZWx2ZXRpY2EgL0VuY29kaW5nIC9XaW5BbnNpRW5jb2RpbmcgL05hbWUgL0YxIC9TdWJ0eXBlIC9UeXBlMSAvVHlwZSAvRm9udAo+PgplbmRvYmoKMyAwIG9iago8PAovQmFzZUZvbnQgL0hlbHZldGljYS1Cb2xkIC9FbmNvZGluZyAvV2luQW5zaUVuY29kaW5nIC9OYW1lIC9GMiAvU3VidHlwZSAvVHlwZTEgL1R5cGUgL0ZvbnQKPj4KZW5kb2JqCjQgMCBvYmoKPDwKL0Jhc2VGb250IC9IZWx2ZXRpY2EtT2JsaXF1ZSAvRW5jb2RpbmcgL1dpbkFuc2lFbmNvZGluZyAvTmFtZSAvRjMgL1N1YnR5cGUgL1R5cGUxIC9UeXBlIC9Gb250Cj4+CmVuZG9iago1IDAgb2JqCjw8Ci9Db250ZW50cyA5IDAgUiAvTWVkaWFCb3ggWyAwIDAgNTk1LjI3NTYgODQxLjg4OTggXSAvUGFyZW50IDggMCBSIC9SZXNvdXJjZXMgPDwKL0ZvbnQgMSAwIFIgL1Byb2NTZXQgWyAvUERGIC9UZXh0IC9JbWFnZUIgL0ltYWdlQyAvSW1hZ2VJIF0KPj4gL1JvdGF0ZSAwIC9UcmFucyA8PAoKPj4gCiAgL1R5cGUgL1BhZ2UKPj4KZW5kb2JqCjYgMCBvYmoKPDwKL1BhZ2VNb2RlIC9Vc2VOb25lIC9QYWdlcyA4IDAgUiAvVHlwZSAvQ2F0YWxvZwo+PgplbmRvYmoKNyAwIG9iago8PAovQXV0aG9yIChhbm9ueW1vdXMpIC9DcmVhdGlvbkRhdGUgKEQ6MjAyNjA5MDEwMTM2NDUrMDAnMDAnKSAvQ3JlYXRvciAoYW5vbnltb3VzKSAvS2V5d29yZHMgKCkgL01vZERhdGUgKEQ6MjAyNjA5MDEwMTM2NDUrMDAnMDAnKSAvUHJvZHVjZXIgKFJlcG9ydExhYiBQREYgTGlicmFyeSAtIFwob3BlbnNvdXJjZVwpKSAKICAvU3ViamVjdCAodW5zcGVjaWZpZWQpIC9UaXRsZSAodW50aXRsZWQpIC9UcmFwcGVkIC9GYWxzZQo+PgplbmRvYmoKOCAwIG9iago8PAovQ291bnQgMSAvS2lkcyBbIDUgMCBSIF0gL1R5cGUgL1BhZ2VzCj4+CmVuZG9iago5IDAgb2JqCjw8Ci9GaWx0ZXIgWyAvQVNDSUk4NURlY29kZSAvRmxhdGVEZWNvZGUgXSAvTGVuZ3RoIDEwNzkKPj4Kc3RyZWFtCkdhdCVjZ01ZYiIlIzQ2SidZSVpZOVUwL2FbKEBCYSR1SmltaE0pJ0U7JmdtJWs8aVkjbUo/T09tM0l0JFVsKytSTzwrPXJvU0tGXiJyJmBBSiM8SWNBSE0mKCRsRmIxIURGJSphVzkuXi1cTzJzZ11RUGk6YlBVOjFfNSIoPUc1JCFmSSZmUiIsSkI0QmJVXEgucC89NFRHdFBqXHApO0o3QGRCJjg/ZClrY2UwWC9xUClhUTMudTk6SSpdakMiYWxjXVJCNUxKKEBBL1UrKGIvP2w2YXR1bkFLU1hPNCs2N2VRVVA4Om8tQDBqO0YsZU5TRC1eZkdjRl83WF9mKDklRy1DKjJdYDRORS5vMUwvOWdZQVdgNlVCMm83MDxbXVA0XFVwX1RTOSJZIiM+XzZlRlA7TCg8X2BJKm47ZXA0QmNtQVRST2BfKj4+ck5GJCtVVS9kcUxtajxpT3FvbT42VyUhSU07aVFNUSxBK1pTRltLS0lZI0gyQzxhKllPdEVnUjglP0FTXiJjYGVrVFgrcT5HKGkhVmlcRGBsME5dJXMqSnBjVFZqaT5yLldtVTZoIjUlcUZrSm9TcFFUSWVLN2VfbyNVLyVBWiw8UiVTVz4vI1A9azpmVWRiYWlSNFYvVEVMNzlhQiciMChBdW4lWjdqP2xCLlhdVHQsSjY3SDBwX2UzNk0wUVtsOGUuOmhlUiE1UmdYM0MvO2cpW2xSLEZoOHE4V1NXWkhEXW5tUmMsMl9eTFg8WT5dYFhbbzhmYlliL1ZtYmVXVS4oajomUFYkQkYqZ25ndT5STWkmdCNIcypwYU5MN0ZnV0AzailnPUJBcj5fR2NtLzMnKVsuMnUoKDwwLDlHWUhSNWI3NE5KQzEuPCNOKFEjdWpZWEEsV29QN0osRUZ0RiFLblclJzExZktLUkhkTCkqQE5pN04rYmxmXjdaZXRtbSU1bzFHVkMjSC4/ZDVBYF8+RGBnI0pmSDdUbjMyQklnVipnb0VGJ09lMFY+QzxCJU8vXFAzUW86ZWg6YjxlbStlVCQ4aGFzKTgtZ3M1c1ZBJTc4Il9GWW8zMCwoLTBvUio+WEQmYlhOO09lQDBvcWBWYSojMSNVJ0lbUD4zNlsoPmRlW1BpM0JHaD11WWtLWko5REoxYSxMTSg2TEtJT2RSSkJTOVNpakI6ZTlxQVZyKkVgLkRnNk44UyQuTG9iQTkybXFGQFFSbUA1J0hiTkJQKVgkYk1ZRUk2bzMyYWJeN1YsRmdAam44TDxuNS5yZjw3dDZyNWY2XkppdDZPWzkuPWdMdXUpUXAlKkQuYDQmW3BdVyJySUc8OUVfZjJrZWs/MGkmYEcmPSlaRlVsakZPZD9VRltkbjo7PCQ1KyZYc2U1NDNPc0JLcjtvVlhgbjlhcS47LzZGRk9WKGtvRU91IUZUbT5mKX4+ZW5kc3RyZWFtCmVuZG9iagp4cmVmCjAgMTAKMDAwMDAwMDAwMCA2NTUzNSBmIAowMDAwMDAwMDYxIDAwMDAwIG4gCjAwMDAwMDAxMTIgMDAwMDAgbiAKMDAwMDAwMDIxOSAwMDAwMCBuIAowMDAwMDAwMzMxIDAwMDAwIG4gCjAwMDAwMDA0NDYgMDAwMDAgbiAKMDAwMDAwMDY0OSAwMDAwMCBuIAowMDAwMDAwNzE3IDAwMDAwIG4gCjAwMDAwMDA5NzggMDAwMDAgbiAKMDAwMDAwMTAzNyAwMDAwMCBuIAp0cmFpbGVyCjw8Ci9JRCAKWzxjYmJiNWRhMzgxZmYwYzE0NjFmMzJlZjYxODE5MTFlZj48Y2JiYjVkYTM4MWZmMGMxNDYxZjMyZWY2MTgxOTExZWY+XQolIFJlcG9ydExhYiBnZW5lcmF0ZWQgUERGIGRvY3VtZW50IC0tIGRpZ2VzdCAob3BlbnNvdXJjZSkKCi9JbmZvIDcgMCBSCi9Sb290IDYgMCBSCi9TaXplIDEwCj4+CnN0YXJ0eHJlZgoyMjA3CiUlRU9GCg==";

const MOCK_EXAM_TIMETABLE_DOCUMENTS = [
  {
    id: 1,
    title: "Year 4 Semester I Exam Timetable — 2025/26",
    year: 4,
    semester: 1,
    file_path: Y4S1_TIMETABLE_PDF,
    original_name: "Y4S1_Exam_Timetable.pdf",
    uploaded_at: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000).toISOString(),
  },
];

const MOCK_EXAM_TIMETABLE_PLAN = [
  { code: "PST 41201", name: "Research Methodology and Scientific Communication", date: "2026-07-14", start: "09:00", end: "11:00", venue: "New Science Hall" },
  { code: "PST 41227", name: "Web Services", date: "2026-07-15", start: "09:00", end: "11:00", venue: "IT Lab 2" },
  { code: "PST 41228", name: "Computer System Security", date: "2026-07-16", start: "09:00", end: "11:00", venue: "New Science Hall" },
  { code: "PST 41229", name: "Advanced Computer Networks", date: "2026-07-17", start: "09:00", end: "11:00", venue: "IT Lab 1" },
  { code: "PST 41232", name: "Cloud Computing", date: "2026-07-18", start: "09:00", end: "11:00", venue: "New Science Hall" },
  { code: "PST 41230", name: "Internet of Things (IoT)", date: "2026-07-21", start: "14:00", end: "16:00", venue: "IT Lab 2" },
  { code: "PST 41231", name: "Natural Language Processing", date: "2026-07-22", start: "14:00", end: "16:00", venue: "New Science Hall" },
  { code: "PST 41233", name: "Business Process Management Systems", date: "2026-07-23", start: "14:00", end: "16:00", venue: "IT Lab 1" },
];
const MOCK_EXAM_TIMETABLE = MOCK_EXAM_TIMETABLE_PLAN.map(({ code, name, date, start, end, venue }, i) => ({
  id: i + 1,
  code,
  course_name: name,
  year: 4,
  semester: 1,
  exam_date: date,
  start_time: start,
  end_time: end,
  venue,
}));

const MOCK_SETTINGS = {
  semester_registration_fee: "300",
  semester_registration_late_fee: "500",
  semester_registration_deadline: "2025-07-15",
  medical_exam_fee: "25",
  repeat_exam_fee: "25",
};

function isOffline() {
  return !!localStorage.getItem(OFFLINE_ROLE_KEY);
}

// Generic JSON request. Throws an Error with a readable .message on failure,
// unless a `fallback` was given AND the failure was a network error (backend
// unreachable) — in that case the fallback is returned instead so the UI can
// keep working in offline demo mode.
async function request(path, { method = "GET", body, isForm = false } = {}, fallback) {
  const headers = {};
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  if (!isForm && body !== undefined) headers["Content-Type"] = "application/json";

  let res;
  try {
    res = await fetch(`${API_BASE}${path}`, {
      method,
      headers,
      body: body === undefined ? undefined : isForm ? body : JSON.stringify(body),
    });
  } catch (err) {
    if (fallback !== undefined) return typeof fallback === "function" ? fallback() : fallback;
    throw new Error("Can't reach the server. Is the backend running?");
  }

  const contentType = res.headers.get("content-type") || "";
  const isJson = contentType.includes("application/json");
  const data = isJson ? await res.json().catch(() => null) : null;

  if (!res.ok) {
    const detail = data && data.error ? `: ${data.error}` : "";
    throw new Error(((data && data.message) || `Request failed (${res.status})`) + detail);
  }
  return data;
}

// Downloads a binary/file response (e.g. .xlsx) and triggers a browser download.
async function download(path, filename) {
  const headers = {};
  const token = getToken();
  if (token) headers.Authorization = `Bearer ${token}`;
  const res = await fetch(`${API_BASE}${path}`, { headers });
  if (!res.ok) {
    const data = await res.json().catch(() => null);
    throw new Error((data && data.message) || `Download failed (${res.status})`);
  }
  const blob = await res.blob();
  const url = window.URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  window.URL.revokeObjectURL(url);
}

export const api = {
  // ── Auth ──
  login: async (username, password, role) => {
    try {
      return await request("/auth/login", { method: "POST", body: { username, password, role } });
    } catch (err) {
      // Backend unreachable OR erroring — sign in with demo data instead of
      // blocking the user out. (Scoped to login only; other endpoints still
      // report real errors.)
      localStorage.setItem(OFFLINE_ROLE_KEY, role);
      return { token: `offline-${role}`, user: { ...MOCK_USERS[role], username } };
    }
  },
  registerStudent: (payload) => request("/auth/register/student", { method: "POST", body: payload }, { message: "Registered in offline demo mode (not saved)." }),
  sendOtp: (email) => request("/auth/send-otp", { method: "POST", body: { email } }, { message: "Offline demo mode — OTP step skipped." }),
  verifyOtp: (email, otp) => request("/auth/verify-otp", { method: "POST", body: { email, otp } }, { message: "Offline demo mode — OTP step skipped." }),
  me: () => request("/auth/me", {}, () => {
    const role = localStorage.getItem(OFFLINE_ROLE_KEY);
    if (!role || !MOCK_USERS[role]) throw new Error("No offline session found.");
    return MOCK_USERS[role];
  }),

  // ── Courses ──
  courses: (year, semester, combination) => {
    const params = new URLSearchParams();
    if (year) params.set("year", year);
    if (semester) params.set("semester", semester);
    if (combination) params.set("combination", combination);
    const qs = params.toString();
    // Fall back to the FULL catalogue (all years/semesters/combinations —
    // see MOCK_COURSE_CATALOG above) so subject browsing works everywhere:
    // Course Registration for the student's current year, and Exam
    // Application's Medical / Repeat flow for any past year & semester.
    return request(`/courses${qs ? `?${qs}` : ""}`, {}, () =>
      MOCK_COURSE_CATALOG
        .filter(c => (!year || c.year === Number(year)) && (!semester || c.semester === Number(semester)))
        .map(c => ({
          ...c,
          is_elective: combination
            ? c.compulsory_for !== "ALL" && !(c.compulsory_for || "").split(",").includes(combination) && (c.elective_for || "").split(",").includes(combination)
            : false,
        }))
    );
  },

  // ── Attendance ──
  myAttendance: () => request("/attendance/me", {}, MOCK_ATTENDANCE),

  // ── Results ──
  myResults: () => request("/results/me", {}, MOCK_RESULTS),
  downloadMyResults: (filters = {}) => {
    const { year, semester, code } = filters;
    const params = new URLSearchParams();
    if (year) params.set("year", year);
    if (semester) params.set("semester", semester);
    if (code) params.set("code", code);
    const qs = params.toString();
    const nameParts = ["my-results"];
    if (year) nameParts.push(`Y${year}`);
    if (semester) nameParts.push(`S${semester}`);
    if (code) nameParts.push(String(code).replace(/\s+/g, ""));
    return download(`/results/download${qs ? `?${qs}` : ""}`, `${nameParts.join("-")}.xlsx`);
  },

  // ── Semester Registration ──
  mySemRegs: () => request("/semreg/me", {}, MOCK_SEMREGS),
  createSemReg: (payload) => request("/semreg", { method: "POST", body: payload }, { message: "Saved locally (offline demo mode — not persisted).", offline: true }),

  // ── Exam Applications ──
  myExamApps: () => request("/exams/me", {}, []),
  createExamApp: (formData) => request("/exams", { method: "POST", body: formData, isForm: true }, { message: "Saved locally (offline demo mode — not persisted).", offline: true }),

  // ── Payments (card or bank slip) ──
  createPayment: (payload, isForm = false) => request("/payments", { method: "POST", body: payload, isForm }, { message: "Saved locally (offline demo mode — not persisted).", offline: true }),
  myPayments: () => request("/payments/me", {}, []),

  // ── Notices ──
  notices: () => request("/notices", {}, MOCK_NOTICES),

  // ── Wellbeing ──
  submitCheckin: (payload) => request("/wellbeing", { method: "POST", body: payload }, { message: "Recorded locally (offline demo mode — not persisted)." }),
  myCheckins: () => request("/wellbeing/me", {}, []),

  // ── Settings ──
  settings: () => request("/settings", {}, MOCK_SETTINGS),
  updateSettings: (settings) => request("/settings", { method: "PUT", body: { settings } }, { message: "Offline demo mode — settings not saved." }),

  // ── Lecturer ──
  myClasses: () => request("/admin/lecturer/classes", {}, MOCK_COURSES.map(c => ({ ...c, course_id: c.id, academic_year: "2025/26" }))),
  courseRoster: (courseId, date) => request(`/attendance/course/${courseId}${date ? `?date=${date}` : ""}`, {}, []),
  courseResults: (courseId) => request(`/results/course/${courseId}`, {}, []),
  markAttendance: (payload) => request("/attendance/mark", { method: "POST", body: payload }, { message: "Offline demo mode — attendance not saved." }),
  enterResults: (payload) => request("/results/enter", { method: "POST", body: payload }, { message: "Offline demo mode — results not saved." }),
  uploadResultsSheet: (formData) => request("/results/upload", { method: "POST", body: formData, isForm: true }, { message: "Offline demo mode — sheet not processed." }),
  downloadResultsTemplate: (courseId, filename) => download(`/results/template/${courseId}`, filename),
  allSemRegs: () => request("/semreg", {}, []),
  allExamApps: () => request("/exams", {}, []),
  updateExamStatus: (id, status) => request(`/exams/${id}/status`, { method: "PUT", body: { status } }, { message: "Offline demo mode — status not saved." }),
  updateSemRegStatus: (id, status) => request(`/semreg/${id}/status`, { method: "PUT", body: { status } }, { message: "Offline demo mode — status not saved." }),
  adminCreateSemReg: (payload) => request("/semreg/admin", { method: "POST", body: payload }, { message: "Offline demo mode — registration not saved." }),
  editSemReg: (id, courseIds) => request(`/semreg/${id}`, { method: "PUT", body: { courseIds } }, { message: "Offline demo mode — registration not saved." }),
  createNotice: (payload) => request("/notices", { method: "POST", body: payload }, { message: "Offline demo mode — notice not saved." }),
  wellbeingReports: () => request("/wellbeing/reports", {}, []),

  // ── Assignments ──
  myAssignments: () => request("/assignments/me", {}, MOCK_ASSIGNMENTS),
  createAssignment: (payload) => request("/assignments", { method: "POST", body: payload }, { message: "Offline demo mode — assignment not saved." }),
  courseAssignments: (courseId) => request(`/assignments/course/${courseId}`, {}, []),
  submitAssignment: (id, formData) => request(`/assignments/${id}/submit`, { method: "POST", body: formData, isForm: true }, { message: "Offline demo mode — submission not saved." }),

  myMaterials: () => request("/materials/me", {}, MOCK_MATERIALS),
  uploadMaterial: (formData) => request("/materials", { method: "POST", body: formData, isForm: true }, { message: "Offline demo mode — material not saved." }),
  courseMaterials: (courseId) => request(`/materials/course/${courseId}`, {}, []),
  deleteMaterial: (id) => request(`/materials/${id}`, { method: "DELETE" }, { message: "Offline demo mode — not deleted." }),

  // ── Exam Timetable ──
  myExamTimetable: () => request("/exam-timetable/me", {}, MOCK_EXAM_TIMETABLE),
  allExamTimetable: (year, semester) => {
    const params = new URLSearchParams();
    if (year) params.set("year", year);
    if (semester) params.set("semester", semester);
    const qs = params.toString();
    return request(`/exam-timetable${qs ? `?${qs}` : ""}`, {}, []);
  },
  createExamTimetableEntry: (payload) => request("/exam-timetable", { method: "POST", body: payload }, { message: "Offline demo mode — entry not saved." }),
  updateExamTimetableEntry: (id, payload) => request(`/exam-timetable/${id}`, { method: "PUT", body: payload }, { message: "Offline demo mode — entry not saved." }),
  deleteExamTimetableEntry: (id) => request(`/exam-timetable/${id}`, { method: "DELETE" }, { message: "Offline demo mode — entry not deleted." }),

  // Exam timetable published as a single uploaded document (PDF/image).
  examTimetableDocuments: (year, semester) => {
    const params = new URLSearchParams();
    if (year) params.set("year", year);
    if (semester) params.set("semester", semester);
    const qs = params.toString();
    return request(`/exam-timetable/documents${qs ? `?${qs}` : ""}`, {}, () =>
      MOCK_EXAM_TIMETABLE_DOCUMENTS.filter(d =>
        (!year || String(d.year) === String(year)) && (!semester || String(d.semester) === String(semester))
      )
    );
  },
  uploadExamTimetableDocument: (formData) => request("/exam-timetable/documents", { method: "POST", body: formData, isForm: true }, { message: "Offline demo mode — document not saved." }),
  deleteExamTimetableDocument: (id) => request(`/exam-timetable/documents/${id}`, { method: "DELETE" }, { message: "Offline demo mode — document not deleted." }),

  // ── Admin ──
  adminDashboard: () => request("/admin/dashboard", {}, {
    totalStudents: 0, pendingRegs: 0, pendingPayments: 0, openCounseling: 0,
    totalLecturers: 0, totalCourses: 0, totalBatches: 0, activeSemesters: 0,
    attendancePct: 0, passRate: 0,
    recentActivity: [],
  }),
  allStudents: () => request("/admin/students", {}, []),
  pendingRegistrations: () => request("/admin/students/pending", {}, []),
  activateStudent: (userId) => request(`/admin/students/${userId}/activate`, { method: "PUT" }, { message: "Offline demo mode — not saved." }),
  suspendStudent: (userId) => request(`/admin/students/${userId}/suspend`, { method: "PUT" }, { message: "Offline demo mode — not saved." }),
  createLecturer: (payload) => request("/admin/lecturers", { method: "POST", body: payload }, { message: "Offline demo mode — not saved." }),
  attendanceReports: () => request("/attendance/reports", {}, []),
  resultsOverview: () => request("/results/overview", {}, []),
  allPayments: () => request("/payments", {}, []),
  verifyPayment: (id, status) => request(`/payments/${id}/verify`, { method: "PUT", body: { status } }, { message: "Offline demo mode — not saved." }),
  allCounseling: () => request("/wellbeing/counseling", {}, []),
  updateCounseling: (id, payload) => request(`/wellbeing/counseling/${id}`, { method: "PUT", body: payload }, { message: "Offline demo mode — not saved." }),

  isOffline,
};

export default api;
